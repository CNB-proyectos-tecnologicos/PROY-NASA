"""Pruebas de humo reproducibles, NO validación clínica.
Ejecutar desde esta carpeta: python test_modelos_referencia.py
"""
from pathlib import Path
import sys, unittest, math
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / '01_originales'))
import modelos_riesgo_clinico_v03 as m

class Smoke(unittest.TestCase):
    def test_ckdepi(self):
        x=m.ckdepi2021(edad=50,creatinina_mg_dl=1.1,sexo_modelo='M')
        self.assertTrue(1 < x < 140)
    def test_prevent_no_imputa_tabaquismo(self):
        with self.assertRaises(m.NoCalculable):
            m.prevent_10y_base(edad=50,sexo_modelo='F',pas_mmhg=160,colesterol_total_mg_dl=240,hdl_mg_dl=55,
               egfr=90,imc=35,diabetes_confirmada=False,fuma_actual=None,toma_estatina=False,toma_antihipertensivos=True,ecv_previa=False)
    def test_prevent_valor_publicado(self):
        x=m.prevent_10y_base(edad=50,sexo_modelo='F',pas_mmhg=160,colesterol_total_mg_dl=240,hdl_mg_dl=55,
               egfr=90,imc=35,diabetes_confirmada=False,fuma_actual=False,toma_estatina=False,toma_antihipertensivos=True,ecv_previa=False)
        self.assertAlmostEqual(x['riesgo_cvd_10y_pct'],5.4273897789,places=5)
        self.assertAlmostEqual(x['riesgo_ascvd_10y_pct'],3.6375631585,places=5)
    def test_kfre(self):
        x=m.kfre4(edad=65,sexo_modelo='M',egfr=35,acr_mg_g=600,erc_g3_g5_confirmada=True)
        self.assertAlmostEqual(x['riesgo_2_anios_pct'],4.1513327257,places=5)
        self.assertAlmostEqual(x['riesgo_5_anios_pct'],15.1410905165,places=5)
    def test_kfre_no_reemplaza_cronicidad(self):
        with self.assertRaises(m.NoCalculable):
            m.kfre4(edad=65,sexo_modelo='M',egfr=35,acr_mg_g=600,erc_g3_g5_confirmada=False)
    def test_fib4_no_enfermedad_aguda(self):
        with self.assertRaises(m.NoCalculable):
            m.fib4(edad=55,ast_u_l=50,alt_u_l=40,plaquetas_10e9_l=220,enfermedad_aguda=True)
    def test_af_exige_confirmacion(self):
        with self.assertRaises(m.NoCalculable):
            m.cha2ds2_va(fa_confirmada=False,edad=76,insuficiencia_cardiaca=True,hipertension=True,diabetes=False,ictus_ait_embolia_previa=False,enfermedad_vascular=False)
    def test_finitud_en_predictores(self):
        with self.assertRaises(m.NoCalculable):
            m.ckdepi2021(edad=50,creatinina_mg_dl=float('nan'),sexo_modelo='M')

if __name__=='__main__':unittest.main(verbosity=2)
