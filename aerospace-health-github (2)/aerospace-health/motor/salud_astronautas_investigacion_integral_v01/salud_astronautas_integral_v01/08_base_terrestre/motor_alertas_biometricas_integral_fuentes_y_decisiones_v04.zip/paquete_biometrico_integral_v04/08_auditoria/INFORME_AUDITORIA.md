# Auditoría automática de consistencia (no equivalente a revisión médica)

Fecha 2026-11-14.

- Catálogo v02: **128** reglas; v03: **512**.
- Fuente heredadas v03: **61** IDs, **49** URLs distintas (existen alias y duplicados).
- Número de dominios: **24**.
- UMBrales vinculados según etiquetado heredado: **287**.
- Derivadas sin validar: **185**.
- Experimentales sin validar: **40**.
- Referencia de extracto revisado temáticamente en anexo: **437 de 512**; restantes **75** tienen sólo referencia heredada sin extracto; asociación NO valida cada regla.
- Se verificó que las IDs de las 512 reglas son únicas: **True**.
- Sin referencia ID heredada en tabla fuentes: **0**.

## Indicadores de revisión automática

| Indicador | Conteo | Interpretación |
|---|---:|---|
| `VENTANA_GENERICA_NO_OPERATIVA` | 384 | Inspección manual y test específico antes de activación. |
| `REGLA_DERIVADA_SIN_VALIDACION` | 185 | Inspección manual y test específico antes de activación. |
| `COMPROBAR_DISPOSITIVO_PA_Y_EMBARAZO` | 58 | Inspección manual y test específico antes de activación. |
| `EXPERIMENTAL_DESACTIVADA` | 40 | Inspección manual y test específico antes de activación. |
| `COMPROBAR_ECG_PARA_DIAGNOSTICO_DE_FA` | 23 | Inspección manual y test específico antes de activación. |
| `UMBRAL_GUIA_APARENTE_PUNTAJE_DE_FACTORES` | 21 | Inspección manual y test específico antes de activación. |
| `COMPROBAR_VALIDACION_OXIMETRO_ESTUDIO_SAOS` | 19 | Inspección manual y test específico antes de activación. |
| `FALTA_SOSPECHA_INFECCION_PARA_ALGORITMO_DE_SEPSIS` | 18 | Inspección manual y test específico antes de activación. |
| `PROTOCOLO_LOCAL_2017_NO_GUIDELINE_ACTUAL` | 2 | Inspección manual y test específico antes de activación. |

**Importante:** indicadores superpuestos. No deben sumarse los conteos. Un valor bajo de «discordancias de URL» solamente comprueba igualdad entre dos campos del mismo catálogo; NO comprueba que la web contenga realmente el criterio citado. Las pruebas automatizadas tampoco sustituyen revisión clínica.

## Hallazgos de riesgo a corregir antes de ejecución real

1. **Ventanas temporales genéricas:** las reglas v03 incluyen ventanas como «según la condición», no deterministas. Antes de compilar, cada regla necesita ventana exacta (duración, número de lecturas, límites de huecos, unidad y reloj).
2. **Atribución excesiva a guías:** etiqueta `UMBRAL_GUIA` puede referirse sólo al valor base, no a la combinación multivariada o prioridad automatizada. Se exige cita individual de apartado de guía.
3. **No se dispone de cohortes locales:** probabilidades PREVENT/KFRE sin evaluación mexicana; los demás cortes no son probabilidades y carecen de sensibilidad/especificidad de su implementación como sistema.
4. **FIB-4 edad 65:** código heredado `>=65` vs fuente que expresa `>65`; la discrepancia fronteriza necesita dictamen.
5. **Proveniencia de fuentes:** se conservan guías antiguas, obras duplicadas, registros secundarios; el anexo de 30 pasajes revisados no implica 61 verificaciones exhaustivas.
6. **Código demo vs reglas JSON:** el demo implementa sólo un subconjunto y no carga las 512 reglas de forma programática.
7. **Métodos obligatorios iniciales:** «PA continua» sólo se interpreta diagnósticamente si es una modalidad clínicamente validada para el uso indicado, algo que no se infiere de tener una serie temporal.
8. **Interpretación de A1c y hemoglobina:** aplicar exclusiones fisiológicas, gestacionales, analíticas y de población antes de emitir criterio.

## Cómo subsanar

Revisión de fuente de nivel regla (`rule_id`, criterio textual, página/sección, configuración del sensor, validador clínico, fecha y firma) -> DSL ejecutable -> pruebas unitarias (valores antes, igual, después del umbral) -> evaluación prospectiva -> aprobación regulatoria -> activación gradual.
