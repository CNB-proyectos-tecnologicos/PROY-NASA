import json, csv, os
from collections import Counter
from artifact_tool import Workbook, SpreadsheetFile
OUT='/mnt/data'
S={
'ADA26':'https://diabetesjournals.org/care/article/49/Supplement_1/S27/163926/2-Diagnosis-and-Classification-of-Diabetes',
'ADA_GLY26':'https://doi.org/10.2337/dc26-s006',
'ADA_HOSP26':'https://doi.org/10.2337/dc26-s016',
'AHA_BP25':'https://www.jacc.org/doi/10.1016/j.jacc.2025.05.007',
'ESC_BP24':'https://academic.oup.com/eurheartj/article/45/38/3912/7741010',
'ESC_AF24':'https://academic.oup.com/eurheartj/article/45/36/3314/7738779',
'ESC_PAD24':'https://academic.oup.com/eurheartj/article/45/36/3538/7738955',
'ESC_HF21':'https://academic.oup.com/eurheartj/article/42/36/3599/6358045',
'ESC_HF26':'https://academic.oup.com/eurheartj/article/47/38/5346/8766302',
'ACC_LIP26':'https://www.jacc.org/doi/10.1016/j.jacc.2025.11.016',
'KDIGO_CKD24':'https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf',
'NICE_AKI':'https://www.nice.org.uk/guidance/ng148/chapter/Recommendations',
'NICE_SEPSIS':'https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk',
'AASM_OSA':'https://aasm.org/resources/clinicalguidelines/diagnostic-testing-osa.pdf',
'ATS_O2':'https://academic.oup.com/ajrccm/article/202/10/e121/8495596',
'WHO_HB24':'https://www.ncbi.nlm.nih.gov/books/NBK602185/table/ch5.tab2/',
'WHO_HBSEV24':'https://www.ncbi.nlm.nih.gov/books/NBK602183/table/fm-ch1.tab2/',
'CDC_BMI24':'https://www.cdc.gov/bmi/adult-calculator/bmi-categories.html',
'NICE_WHTR':'https://www.nice.org.uk/guidance/ng246/chapter/Identifying-and-assessing-overweight-obesity-and-central-adiposity',
'AASLD_MASLD':'https://pubmed.ncbi.nlm.nih.gov/38445559/',
'NICE_B12':'https://www.nice.org.uk/guidance/ng239/chapter/Recommendations',
'AGA_FERR':'https://gastro.org/clinical-guidance/gastrointestinal-evaluation-of-iron-deficiency-anemia/',
'AABB_PLT25':'https://pubmed.ncbi.nlm.nih.gov/40440268/',
'UKKA_K23':'https://www.ukkidney.org/sites/renal.org/files/FINAL%20VERSION%20-%20UKKA%20CLINICAL%20PRACTICE%20GUIDELINE%20-%20MANAGEMENT%20OF%20HYPERKALAEMIA%20IN%20ADULTS%20-%20191223.pdf',
'ENDO_NA':'https://academic.oup.com/ejendo/article/170/3/G1/6668028',
'ATA_TFT':'https://www.thyroid.org/thyroid-function-tests/',
'PCOS23':'https://pmc.ncbi.nlm.nih.gov/articles/PMC10505534/',
'ACOG_BP':'https://www.acog.org/womens-health/faqs/preeclampsia-and-high-blood-pressure-during-pregnancy',
'ADA_GDM26':'https://diabetesjournals.org/care/article/49/Supplement_1/S27/163926/2-Diagnosis-and-Classification-of-Diabetes',
'PRONAM_MX':'https://ccinshae.salud.gob.mx/investigacion/protocolos-nacionales-atencion-medica/',
'IDSA_NEUTRO':'https://www.cancercare.mb.ca/export/sites/default/For-Health-Professionals/.galleries/files/treatment-guidelines-rro-files/practice-guidelines/supportive-care/CCMB-Neutropenia-Protocol-and-Algorithms-2017.pdf',
}
RULES=[]
def add(domain,condition,severity,kind,available,required,criterion,period,action,confirmation,source,evidence='GUIA',notes='Adultos; no emitir diagnóstico sin confirmación clínica; comprobar calidad de medición.',population='Adultos >=18 años'):
    rid=f'R{len(RULES)+1:03d}'
    RULES.append(dict(id=rid,dominio=domain,condicion=condition,severidad=severity,tipo_inferencia=kind,disponibilidad=available,variables_necesarias=required,criterio_SI=criterion,ventana=period,resultado_ENTONCES=action,prueba_confirmatoria=confirmation,estado_evidencia=evidence,fuente_id=source,fuente_url=S.get(source,''),poblacion=population,limitaciones=notes))

# Severidad: CRITICA (evaluacion inmediata) URGENTE (pronta) CONSULTA CRIBADO SEGUIMIENTO.
# Disponibilidad: BASE / OPCIONAL / BASE+OPCIONAL / CONTEXTO_ADICIONAL (no garantizado).
# Calificacion EVIDENCIA: GUIA = criterio explícito, DERIVADA = extrapolación razonable validacion, EXPERIMENTAL = heuristica, NO_DISPONIBLE = abstencion.

# ANTROPOMETRIA
add('Antropometría','Bajo peso','CONSULTA','CRIBADO','BASE','imc, edad','IMC < 18.5 kg/m²','Medición actual y reconfirmación','Evaluar estado nutricional y causas clínicas','Evaluación nutricional', 'CDC_BMI24',notes='IMC de adulto; no aplicar a menores ni a personas embarazadas sin adaptación.')
add('Antropometría','Sobrepeso','SEGUIMIENTO','CRIBADO','BASE','imc, edad','25 <= IMC < 30 kg/m²','Actual','Revisar riesgo cardiometabólico y perímetro abdominal','Evaluación clínica','CDC_BMI24')
add('Antropometría','Obesidad clase I','CONSULTA','CRIBADO','BASE','imc, edad','30 <= IMC < 35 kg/m²','Actual','Evaluación de comorbilidades','Evaluación clínica','CDC_BMI24')
add('Antropometría','Obesidad clase II','CONSULTA','CRIBADO','BASE','imc, edad','35 <= IMC < 40 kg/m²','Actual','Evaluación integral de riesgo','Evaluación clínica','CDC_BMI24')
add('Antropometría','Obesidad clase III','CONSULTA','CRIBADO','BASE','imc, edad','IMC >= 40 kg/m²','Actual','Evaluación especializada','Evaluación clínica','CDC_BMI24')
add('Antropometría','Adiposidad central aumentada','CONSULTA','CRIBADO','BASE','cintura_cm, estatura_cm, imc','0.50 <= cintura/estatura < 0.60 y IMC <35','Medición actual','Revisar riesgo de diabetes y cardiovascular','Antropometría estandarizada','NICE_WHTR',notes='Medición de cintura estandarizada, NO aplicar clasificación de NICE si IMC>=35.')
add('Antropometría','Adiposidad central alta','CONSULTA','CRIBADO','BASE','cintura_cm, estatura_cm, imc','cintura/estatura >=0.60 y IMC <35','Medición actual','Evaluación cardiometabólica','Antropometría estandarizada','NICE_WHTR',notes='NICE aplica este esquema a IMC <35; no inferir etiología.')
add('Antropometría','Cambios ponderales progresivos','SEGUIMIENTO','SEGUIMIENTO','BASE','peso_kg, historial_peso','Cambio de peso relativo >=5% en 3-6 meses','Meses','Verificar intencionalidad, hidratación, alimentación y posibles causas','Entrevista y exploración','CDC_BMI24','EXPERIMENTAL',notes='Delta propuesto para monitorización, no criterio específico de una enfermedad.')
add('Antropometría','Ganancia rápida de peso en IC conocida','CONSULTA','VIGILANCIA','BASE','peso_kg, insuficiencia_cardiaca_previa','Insuficiencia cardiaca conocida y aumento >2 kg en 3 días','3 días','Contactar al equipo de insuficiencia cardiaca; valorar congestión','Valoración clínica y peso estandarizado','ESC_HF21',notes='Umbral de autocuidado en IC conocida, no criterio de diagnóstico de IC.')
add('Antropometría','Pérdida rápida de peso con taquicardia','CONSULTA','PATRON','BASE','peso_kg, fc_reposo, presion','Peso cae >2% en 72 h y FC basal aumenta persistentemente','72 horas','Valorar pérdida de volumen u otras causas','Evaluación clínica; química sanguínea si procede','NICE_SEPSIS','EXPERIMENTAL',notes='Umbral combinado no validado; variación por hidratación y balanza.')

# VITALES, SENSORES, INFECCION
add('Temperatura','Fiebre medida clínicamente','CONSULTA','OBSERVACION','BASE','temperatura, sitio_sensor','Temperatura clínica >=38.0 °C','Repetir si procede','Investigar causa y contexto','Termómetro clínico validado','NICE_SEPSIS',notes='Umbral no transferible a temperatura de muñeca/piel; no significa infección bacteriana.')
add('Temperatura','Temperatura muy elevada','URGENTE','OBSERVACION','BASE','temperatura, sitio_sensor','Temperatura clínica >=40 °C','Confirmación inmediata','Valoración médica pronta; revisar exposición al calor e infección','Termometría clínica','NICE_SEPSIS','DERIVADA',notes='No diagnostica golpe de calor sin contexto y alteración neurológica.')
add('Temperatura','Hipotermia','CRITICA','OBSERVACION','BASE','temperatura, sitio_sensor','Temperatura central confirmada <35 °C','Inmediato','Evaluación médica urgente','Temperatura central adecuada','NICE_SEPSIS','DERIVADA',notes='No aplicar a estimaciones cutáneas; posibles causas diversas.')
add('Temperatura','Hipotermia relativa en sospecha infecciosa','URGENTE','PATRON','BASE','temp_timpanica, sospecha_infeccion','Tª timpánica <36 °C y sospecha clínica de infección','Medición actual','Evaluación de posible deterioro séptico','Valoración presencial','NICE_SEPSIS',notes='Sin variable sospecha de infección no se puede etiquetar sepsis.')
add('Cardiovascular agudo','Hipotensión potencialmente grave','URGENTE','OBSERVACION','BASE','pa_sistolica_validada','PAS <=90 mmHg en medición validada','Repetición inmediata según seguridad','Evaluación de perfusión y causas, particularmente si nueva','Presión por manguito y exploración','NICE_SEPSIS',notes='Criterio alto riesgo dentro de sospecha de sepsis; fuera de ese contexto es señal no específica.')
add('Cardiovascular agudo','Caída brusca de presión basal','URGENTE','PATRON','BASE','pa_sistolica_validada, pas_baseline','PAS disminuye >40 mmHg frente a habitual, con medición validada','Comparación basal y actual','Valoración de deterioro circulatorio','Manguito validado y evaluación','NICE_SEPSIS',notes='Es criterio de alto riesgo en sospecha de sepsis; no identifica causa.')
add('Cardiovascular agudo','Taquicardia marcada','URGENTE','OBSERVACION','BASE','fc_reposo, calidad_fc','FC >130 lpm en reposo, sostenida y confirmada','Repetir/confirmar','Evaluación clínica y ECG','ECG si disponible','NICE_SEPSIS',notes='Umbral de alto riesgo en sepsis sospechada, pero aislado no diagnostica infección.')
add('Cardiovascular agudo','Taquicardia en reposo','CONSULTA','PATRON','BASE','fc_reposo, actividad','FC de reposo >100 lpm en medidas repetidas','Dos o más periodos en reposo','Evaluar fiebre, anemia, deshidratación, arritmia, fármacos','ECG y consulta','ESC_AF24','DERIVADA',notes='Corte descriptivo de taquicardia; no especificidad etiológica.')
add('Cardiovascular agudo','Bradicardia de vigilancia','CONSULTA','PATRON','BASE','fc_reposo, edad, fc_baseline','FC en reposo <50 lpm y desviación relevante del patrón habitual','Varias mediciones','Comprobar atleta/sueño/fármacos y evaluar si corresponde','ECG','ESC_AF24','DERIVADA',notes='Sin síntomas no indica por sí misma trastorno o urgencia.')
add('Cardiovascular agudo','Bradicardia muy marcada','URGENTE','PATRON','BASE','fc_reposo, contexto','FC de reposo <40 lpm confirmada y no habitual','Repetir','Evaluación médica rápida','ECG','ESC_AF24','DERIVADA',notes='Gravedad depende de perfusión, síntomas, bloqueo, tratamiento y sueño.')
add('Respiratorio','Hipoxemia importante','URGENTE','OBSERVACION','BASE','spo2, calidad_spo2','SpO2 <=88% en reposo y señal fiable, confirmada','Persistente o reconfirmada','Valoración médica pronta/urgente según estado','Oximetría clínica; gasometría si procede','ATS_O2',notes='ATS umbral de hipoxemia crónica grave en enfermedad pulmonar; altura y condiciones modifican interpretación; no equiparar a hipoxemia aguda ni aplicar a señal sin calidad.')
add('Respiratorio','Desaturación nueva moderada','CONSULTA','PATRON','BASE','spo2, spo2_baseline','SpO2 89–92% nueva frente a basal y repetida','Repetir en reposo','Evaluar ventilación, enfermedad pulmonar y artefactos','Oxímetro validado','ATS_O2','DERIVADA',notes='No universal: altitud, EPOC y precisión del sensor; no diagnostica patología concreta.')
add('Respiratorio','Desaturaciones nocturnas cíclicas','CRIBADO','PATRON','BASE','spo2_nocturna, calidad_spo2','Desaturaciones relativas nocturnas de >=3–4 puntos repetidas y buena señal','>=3 noches','Considerar estudio del sueño si contexto compatible','PSG o HSAT técnicamente adecuado','AASM_OSA','EXPERIMENTAL',notes='Sin sueño/respiración no calcular AHI ni diagnosticar OSA; desaturación es heurística de priorización.')
add('Respiratorio','Sospecha de apnea obstructiva del sueño','CRIBADO','RIESGO','BASE','imc, presion_nocturna, spo2_nocturna','Obesidad/centralidad + PA nocturna elevada + desaturaciones nocturnas repetidas','Varias noches','Solicitar evaluación por medicina del sueño','PSG o HSAT validado','AASM_OSA','EXPERIMENTAL',notes='Regla de cribado no validada; faltan ronquido, somnolencia y frecuencia respiratoria.')
add('Deterioro sistémico','Deterioro multivariable','URGENTE','PATRON','BASE','temperatura, fc_reposo, pa_sistolica, spo2','Fiebre o hipotermia relativa + FC en ascenso + PAS en descenso ± SpO2 en descenso','Horas','Priorizar revisión presencial, sin etiquetar sepsis','Evaluación clínica, lactato y panel según sospecha','NICE_SEPSIS','EXPERIMENTAL',notes='Evidencia para variables individuales, no para fórmula multivariable exacta.')
add('Deterioro sistémico','Infección sistémica posible con hipotensión','URGENTE','PATRON','BASE','temperatura, pa_sistolica_validada, fc_reposo','Tª clínica >=38 + PAS <=90 y/o FC >130 en reposo','Mediciones confirmadas','Valoración clínica urgente; posibles causas múltiples','Evaluación presencial','NICE_SEPSIS','DERIVADA',notes='No etiquetar sepsis sin sospecha infecciosa/disfunción orgánica; evitar score NEWS2 parcial.')

# PRESION/ARRITMIAS/RIESGO CV
add('Presión arterial','Hipertensión estadio 1 AHA/ACC','CONSULTA','CRIBADO','BASE','pa_sistolica_validada, pa_diastolica_validada','PAS 130–139 O PAD 80–89 (promedio válido)','Series validadas repetidas','Revisar y confirmar hipertensión según protocolo US','HBPM/ABPM con manguito validado','AHA_BP25',notes='AHA/ACC EEUU, NO clasificación universal; cuffless no válido para diagnóstico.')
add('Presión arterial','Hipertensión estadio 2 AHA/ACC','CONSULTA','CRIBADO','BASE','pa_sistolica_validada, pa_diastolica_validada','PAS >=140 O PAD >=90, sin alcanzar corte de urgencia','Series validadas repetidas','Solicitar evaluación de HTA','HBPM/ABPM validada','AHA_BP25')
add('Presión arterial','Hipertensión ESC en consulta','CONSULTA','CRIBADO','BASE','pa_consulta_validada','PAS consulta >=140 O PAD consulta >=90','Repetida','Evaluación según protocolo europeo/MX','Medición clínica y ABPM/HBPM','ESC_BP24',notes='El tipo de medición debe ser consulta, no muestra continua arbitraria.')
add('Presión arterial','Hipertensión ESC domiciliaria/diurna','CONSULTA','CRIBADO','BASE','pa_domiciliaria_validada','Media HBPM o ABPM diurna >=135/85 mmHg (PAS o PAD)','Mediciones protocolizadas','Revisar HTA','HBPM/ABPM validada','ESC_BP24')
add('Presión arterial','Hipertensión ESC 24 horas','CONSULTA','CRIBADO','BASE','pa_24h_validada','Media ABPM 24 h >=130/80 mmHg (PAS o PAD)','24 horas','Revisar HTA','ABPM de manguito','ESC_BP24')
add('Presión arterial','Hipertensión ESC nocturna','CONSULTA','CRIBADO','BASE','pa_noche_validada','Media ABPM noche >=120/70 mmHg (PAS o PAD)','Noche validada','Revisar patrón de HTA','ABPM validada','ESC_BP24')
add('Presión arterial','PA severamente elevada','URGENTE','OBSERVACION','BASE','pa_sistolica_validada, pa_diastolica_validada','PAS >180 O PAD >120, confirmada adecuadamente','Inmediato tras repetir','Evaluación pronta; solicitar signos/síntomas de daño de órgano','Exploración clínica y evaluación de órgano blanco','AHA_BP25',notes='No equivale a emergencia hipertensiva sin daño agudo de órgano blanco; severidad de síntomas determina emergencia.')
add('Presión arterial','Sospecha de hipotensión ortostática','CONSULTA','CRIBADO','CONTEXTO_ADICIONAL','pa_supina_y_de_pie, instante_postura','Caída de PAS >=20 O PAD >=10 mmHg en 3 min tras ponerse de pie','Prueba postural 3 min','Evaluar ortostatismo y etiología','Prueba ortostática validada','ESC_BP24','DERIVADA',notes='Postura/transición no obligatorias: regla inactiva si no existen.')
add('Presión arterial','Patrón no-dipper','SEGUIMIENTO','PATRON','BASE','abpm_dia, abpm_noche','Caída media nocturna de PAS <10% respecto a día','ABPM día+noche','Considerar revisión de riesgo HTA/OSA','ABPM validada','ESC_BP24','DERIVADA',notes='Umbral fenotípico, no diagnóstico etiológico; cuffless/horario sueño infiable.')
add('Ritmo cardiaco','Irregularidad PPG sugestiva de FA','CRIBADO','SOSPECHA','BASE','irregularidad_ppg, calidad_ppg','Episodios recurrentes de irregularidad por algoritmo PPG validado','Múltiples episodios','Obtener trazado ECG','ECG de una derivación o 12 derivaciones','ESC_AF24',notes='No imponer 30 segundos a episodios PPG; 30 s corresponde a trazado ECG diagnóstico en contexto apropiado.')
add('Ritmo cardiaco','Fibrilación auricular por ECG','CONSULTA','CRITERIO_ECG','OPCIONAL','ecg_interpretado','ECG documenta FA y es interpretado por profesional competente','ECG episodio','Activar valoración de anticoagulación/riesgo ictus','Revisión clínica del ECG','ESC_AF24',notes='No derivable únicamente de FC, HRV o PPG.')
add('Ritmo cardiaco','Palpitación posible por irregularidad y FC elevada','CONSULTA','SOSPECHA','BASE','ppg_ritmo, fc_reposo','Irregularidad PPG + FC reposo >100 en episodios repetidos','Episodios','Confirmar posible taquiarritmia','ECG/Holter','ESC_AF24','EXPERIMENTAL',notes='No permite identificar tipo de arritmia.')
add('Cardiovascular preventivo','Evaluar riesgo de evento ASCVD','CRIBADO','SCORE','BASE+OPCIONAL','edad, sexo_modelo, PAS, colesterol_total, HDL, diabetes, etc','Variables PREVENT completas y población de aplicación apropiada','Evaluación periódica','Calcular score PREVENT exacto sin imputaciones silenciosas','Perfil lipídico y anamnesis pertinente','ACC_LIP26',notes='No inventar probabilidad; comparar jurisdicción y validez local.')
add('Cardiovascular preventivo','ASCVD previa: prevención secundaria','CONSULTA','ANTECEDENTE','BASE','infarto_ictus_PAD_conocido','Antecedente de enfermedad aterosclerótica establecido','Actual y seguimiento','Activar ruta prevención secundaria; no aplicar score de riesgo primario','Evaluación especializada','ACC_LIP26',notes='No inferir medicación actual.')
add('Vascular periférico','Enfermedad arterial periférica posible','CONSULTA','CRITERIO_PRUEBA','OPCIONAL','indice_tobillo_brazo','ABI <=0.90 en prueba validada','Prueba actual','Valoración vascular','Revisión Doppler/ABI','ESC_PAD24',notes='PA de brazo sola no permite ABI; sin tobillo/PI no inferir PAD.')
add('Vascular periférico','Arterias no compresibles','CONSULTA','CRITERIO_PRUEBA','OPCIONAL','indice_tobillo_brazo','ABI >1.40','Prueba actual','Considerar índice dedo-brazo y evaluación vascular','TBI','ESC_PAD24')
add('Cardiovascular preventivo','Riesgo alto de ictus en FA conocida','CONSULTA','RIESGO','BASE','FA_confirmada, HTA, diabetes, edad, ictus_previo','FA confirmada + antecedentes vasculares o edad avanzada','Actual','Valorar riesgo embólico mediante score completo y prevención','Evaluación cardiológica','ESC_AF24','DERIVADA',notes='No diagnosticar ictus ni estimar CHA2DS2-VA incompleto.')

# GLUCOSA METABOLISMO
add('Glucosa','Prediabetes por HbA1c','CONSULTA','CRITERIO_LAB','OPCIONAL','hba1c_pct','5.7 <= HbA1c <= 6.4 %','Laboratorio actual','Intervención preventiva y seguimiento','HbA1c laboratorio validado','ADA26')
add('Glucosa','Prediabetes por ayuno','CONSULTA','CRITERIO_LAB','OPCIONAL','glucosa_plasma_ayuno','100 <= glucosa plasmática ayuno <=125 mg/dL','Ayuno >=8 h','Evaluación de prediabetes','Repetición/otro laboratorio según criterio','ADA26')
add('Glucosa','Prediabetes por OGTT','CONSULTA','CRITERIO_LAB','OPCIONAL','ogtt_2h','140 <= OGTT plasma 2h <=199 mg/dL','2 horas después 75 g','Evaluación de prediabetes','OGTT estandarizado','ADA26')
add('Glucosa','Posible diabetes por HbA1c','CONSULTA','CRITERIO_LAB','OPCIONAL','hba1c_pct','HbA1c >=6.5 %','Prueba actual','Confirmar diagnóstico, salvo hiperglucemia inequívoca','Segunda prueba alterada','ADA26')
add('Glucosa','Posible diabetes por glucosa ayuno','CONSULTA','CRITERIO_LAB','OPCIONAL','glucosa_plasma_ayuno','Glucosa plasmática ayuno >=126 mg/dL','Ayuno >=8h','Confirmar diagnóstico','Repetir laboratorio / otra prueba','ADA26')
add('Glucosa','Posible diabetes por OGTT','CONSULTA','CRITERIO_LAB','OPCIONAL','ogtt_2h','OGTT plasma 2h >=200 mg/dL','2h tras 75 g','Confirmación y evaluación','Laboratorio validado','ADA26')
add('Glucosa','Glucosa al azar muy elevada','CONSULTA','SOSPECHA','OPCIONAL','glucosa_plasma_aleatoria','Glucosa plasmática al azar >=200 mg/dL sin síntomas documentados','Prueba actual','Preguntar síntomas; confirmar diabetes o descartar crisis','Clínica + laboratorio','ADA26',notes='No diagnosticar sin síntomas clásicos o crisis inequívoca.')
add('Glucosa','Hiperglucemia recurrente CGM','SEGUIMIENTO','PATRON','BASE','cgm, calidad_cgm','Lecturas CGM >=180 mg/dL repetidas, sin diagnóstico previo','>=10–14 días','Considerar conversación clínica y pruebas plasmáticas, como exploración no validada','HbA1c/FPG/OGTT','ADA26','EXPERIMENTAL',notes='ADA 2026 expresa evidencia insuficiente para usar CGM como CRIBADO o DIAGNÓSTICO de diabetes; esta regla no es recomendación clínica establecida.')
add('Glucosa','Hipoglucemia nivel 1 por CGM','URGENTE','OBSERVACION','BASE','cgm, calidad_cgm','CGM <70 y >=54 mg/dL en diabetes tratada y lectura creíble','Repetición inmediata/algoritmo de sensor','Advertir descenso de glucosa y seguir plan individual de manejo','Capilar si lectura discordante','ADA_GLY26',notes='Cortes ADA en diabetes; CGM puede mostrar falsos bajos por compresión; acción depende de síntomas y tratamiento.')
add('Glucosa','Hipoglucemia nivel 2 por CGM','CRITICA','OBSERVACION','BASE','cgm, calidad_cgm','CGM <54 mg/dL y señal creíble en diabetes','Inmediato','Aviso de acción inmediata conforme plan individual; confirmar capilar sin retrasar cuidados necesarios','Glucosa capilar/plasmática','ADA_GLY26',notes='Riesgo importante, especialmente con insulina/sulfonilureas; no extrapolar sin contexto.')
add('Glucosa','Exceso de tiempo bajo rango','CONSULTA','VIGILANCIA','BASE','cgm_tbr, cgm_cobertura, diabetes_conocida','Diabetes conocida, cobertura >=70% en 14d y TBR <70 mg/dL >4%','14 días','Revisión de terapia y patrones hipoglucémicos','Consulta de diabetes','ADA_GLY26')
add('Glucosa','Exceso de hipoglucemia profunda','URGENTE','VIGILANCIA','BASE','cgm_tbr54, cgm_cobertura, diabetes_conocida','Diabetes conocida, cobertura >=70% en 14d y TBR <54 mg/dL >1%','14 días','Revisión clínica prioritaria de seguridad','Consulta de diabetes','ADA_GLY26')
add('Glucosa','Posible cetoacidosis diabética (DKA)','CRITICA','CRITERIO_LAB','BASE+OPCIONAL','diabetes_previa/glucosa_plasma, betahidroxibutirato, pH/bicarbonato','(diabetes conocida O glucosa plasma >=200) Y BHB >=3 mmol/L Y (pH<7.3 O HCO3<18)','Mismo episodio agudo','Emergencia hospitalaria','Pruebas de cetonas/acidosis y evaluación urgente','ADA_HOSP26',notes='Sin cetonas y acidosis no se puede detectar DKA; DKA euglucémica existe.')
add('Glucosa','Posible estado hiperosmolar HHS','CRITICA','CRITERIO_LAB','OPCIONAL','glucosa_plasma, osmolaridad, BHB, pH/bicarbonato','Glucosa plasma >=600 + osmolalidad efectiva >300 o total >320 + sin cetosis/acidosis significativa','Mismo episodio agudo','Emergencia hospitalaria','Panel clínico y osmolaridad','ADA_HOSP26',notes='Requiere todos los criterios; CGM por sí solo no suficiente.')
add('Glucosa','Cetonemia marcada con diabetes','URGENTE','PATRON','BASE+OPCIONAL','BHB, diabetes_previa','BHB >=3 mmol/L en persona con diabetes, aun si CGM normal','Actual','Valoración médica inmediata de acidosis','pH, HCO3, electrolitos','ADA_HOSP26',notes='Es señal de alto riesgo, no DKA confirmada sin acidosis.')
add('Glucosa','Revisión de riesgo por diabetes gestacional previa','CRIBADO','ANTECEDENTE','BASE','diabetes_gestacional_previa, fecha_ultimo_cribado','Antecedente DM gestacional y cribado no realizado hace >=1–3 años','Anual-trienal','Solicitar cribado periódico de diabetes','FPG/HbA1c/OGTT según contexto','ADA_GDM26',notes='La historia de diabetes gestacional debe estar registrada; la fase del ciclo no equivale al dato.')
add('Glucosa','Cribado DM tipo 2 por edad','CRIBADO','RIESGO','BASE','edad, diagnostico_dm','Edad >=35 años sin diabetes conocida y sin cribado documentado','Periódico','Proponer prueba validada de diabetes','FPG o HbA1c','ADA26',notes='Incluir excepciones para menores con factores de riesgo y periodicidad según resultados.')

# METABOLICO, LIPIDOS, HIGADO
add('Metabolismo','Síndrome metabólico posible','CONSULTA','CRITERIO_LAB','BASE+OPCIONAL','cintura, TG, HDL, PA, glucosa_ayuno','Al menos 3/5: cintura umbral poblacional, TG>=150, HDL bajo, PA>=130/85, FPG>=100','Mediciones contemporáneas','Valorar riesgo metabólico','Perfil lipídico + FPG','ACC_LIP26','DERIVADA',notes='Cintura 102/88 cm histórica no universal; parametrizar por población; no usar CGM en lugar de FPG.')
add('Lípidos','LDL muy elevado','CONSULTA','CRITERIO_LAB','OPCIONAL','ldl_mgdl','LDL >=190 mg/dL','Panel actual','Evaluar hipercolesterolemia severa, familiar y causas secundarias','Perfil lipídico/consulta','ACC_LIP26')
add('Lípidos','LDL moderadamente elevado y riesgo familiar','CRIBADO','RIESGO','BASE+OPCIONAL','ldl_mgdl, enfermedad_cv_familiar','LDL >=160 mg/dL y antecedente familiar de ASCVD precoz','Panel actual','Evaluar prevención lipídica intensificada','Historia familiar verificada','ACC_LIP26',notes='El antecedente familiar no está garantizado en los datos base.')
add('Lípidos','Hipertrigliceridemia leve/moderada','CONSULTA','CRITERIO_LAB','OPCIONAL','tg_mgdl','TG en ayuno >=150 y <500 mg/dL','Panel actual','Investigar causas y riesgo cardiovascular','Perfil lipídico','ACC_LIP26')
add('Lípidos','Hipertrigliceridemia severa','URGENTE','CRITERIO_LAB','OPCIONAL','tg_mgdl','TG >=500 y <1000 mg/dL','Panel actual','Evaluación pronta por aumento de riesgo de pancreatitis','Repetir/valorar perfil y causas','ACC_LIP26',notes='No diagnostica pancreatitis sin síntomas/laboratorio específico.')
add('Lípidos','Hipertrigliceridemia extrema','URGENTE','CRITERIO_LAB','OPCIONAL','tg_mgdl','TG >=1000 mg/dL','Panel actual','Evaluación clínica prioritaria por mayor riesgo de pancreatitis','Consulta médica','ACC_LIP26')
add('Lípidos','HDL bajo','SEGUIMIENTO','CRITERIO_LAB','OPCIONAL','hdl_mgdl, sexo_clinico','HDL <40 mg/dL (varón) o <50 (mujer)','Panel actual','Evaluar factores cardiometabólicos','Perfil lipídico','ACC_LIP26','DERIVADA',notes='Marcador de riesgo metabólico; no entidad diagnóstica aislada.')
add('Hígado','Fibrosis avanzada improbable por FIB-4','SEGUIMIENTO','SCORE','OPCIONAL','edad, ast, alt, plaquetas','FIB-4 <1.3 con edad 35–65 y contexto MASLD','Laboratorio reciente','Reevaluación periódica si persiste riesgo','FIB-4 + contexto clínico','AASLD_MASLD',notes='No descarta toda enfermedad hepática; no usar durante enfermedad aguda.')
add('Hígado','FIB-4 indeterminado/alto (35–65)','CONSULTA','SCORE','OPCIONAL','edad, ast, alt, plaquetas','Edad 35–65 y FIB-4 >=1.3','Laboratorio reciente','Solicitar elastografía o prueba secundaria','VCTE/ELF','AASLD_MASLD',notes='El score precisa biometría hepática y plaquetas; riesgo no diagnóstico de cirrosis.')
add('Hígado','FIB-4 elevado en mayores','CONSULTA','SCORE','OPCIONAL','edad, ast, alt, plaquetas','Edad >65 y FIB-4 >2.0','Laboratorio reciente','Evaluación secundaria de fibrosis','VCTE/ELF','AASLD_MASLD')
add('Hígado','FIB-4 muy alto','CONSULTA','SCORE','OPCIONAL','edad, ast, alt, plaquetas','FIB-4 >2.67, edad válida para interpretación','Laboratorio reciente','Considerar valoración hepatológica','VCTE/ELF y especialista','AASLD_MASLD')
add('Hígado','Enzimas hepáticas persistentes elevadas','CONSULTA','PATRON','OPCIONAL','alt, ast, limite_superior_lab','ALT o AST sobre LSN laboratorio durante >6 meses','>=6 meses','Evaluación de causas hepatocelulares','Perfil hepático y evaluación clínica','AASLD_MASLD',notes='Enzimas elevadas no equivalen a MASLD ni cirrosis.')
add('Hígado','Riesgo de MASLD asociado a metabolismo','CRIBADO','RIESGO','BASE','obesidad, diabetes, hipertension','Obesidad o DM2 + otros factores metabólicos','Seguimiento','Evaluación hepatometabólica; definir necesidad de laboratorio','ALT, AST, plaquetas y luego FIB-4','AASLD_MASLD','DERIVADA',notes='No implica diagnóstico de esteatosis sin imagen/contexto.')

# RIÑON
add('Riñón','ERC por eGFR persistentemente bajo','CONSULTA','CRITERIO_LAB','OPCIONAL','egfr, fecha_egfr','eGFR <60 mL/min/1.73m² persistente >=3 meses','>=3 meses','Valorar ERC y clasificar KDIGO','eGFR CKD-EPI sin raza + ACR','KDIGO_CKD24')
add('Riñón','Albuminuria persistente','CONSULTA','CRITERIO_LAB','OPCIONAL','acr_urinaria','ACR >=30 mg/g persistente >=3 meses','>=3 meses','Valorar daño renal y riesgo','ACR primera orina / evolución','KDIGO_CKD24')
add('Riñón','Albuminuria alta','CONSULTA','CRITERIO_LAB','OPCIONAL','acr_urinaria','ACR >300 mg/g','Actual, confirmar','Evaluación nefrológica y riesgo cardiovascular','Repetir ACR','KDIGO_CKD24')
add('Riñón','Deterioro renal importante','URGENTE','CRITERIO_LAB','OPCIONAL','egfr','eGFR <30 mL/min/1.73m² en resultado nuevo','Laboratorio actual','Valoración pronta; distinguir crónico vs agudo','Creatinina seriada, ACR, clínica','KDIGO_CKD24',notes='No equiparar automáticamente a fracaso renal agudo.')
add('Riñón','Lesión renal aguda: incremento absoluto','URGENTE','CRITERIO_LAB','OPCIONAL','creatinina_serie','Creatinina sube >=0.3 mg/dL en <=48h','48h','Evaluar AKI rápidamente','Repetición e investigación clínica','NICE_AKI')
add('Riñón','Lesión renal aguda: incremento relativo','URGENTE','CRITERIO_LAB','OPCIONAL','creatinina_serie','Creatinina >=1.5x basal en <=7 días','7 días','Evaluar AKI rápidamente','Repetición e investigación clínica','NICE_AKI')
add('Riñón','Oliguria','URGENTE','CRITERIO_PRUEBA','CONTEXTO_ADICIONAL','volumen_orina, peso','Diuresis <0.5 mL/kg/h durante >=6 h','>=6h','Evaluar AKI/obstrucción/hipovolemia','Diuresis y creatinina','NICE_AKI',notes='Volumen urinario no es dato obligatorio.')
add('Riñón','Riesgo renal en diabetes/hipertensión','CRIBADO','RIESGO','BASE','DM_conocida, HTA_conocida','Diabetes o HTA previa con función renal no evaluada','Periódico','Proponer ACR/eGFR','Creatinina, ACR','KDIGO_CKD24',notes='No inferir ERC si no hay laboratorio.')

# HEMATOLOGIA
add('Hematología','Anemia adulto varón','CONSULTA','CRITERIO_LAB','OPCIONAL','hb_gdl, sexo_clinico','Hb <13.0 g/dL en varón adulto','Laboratorio actual','Evaluar anemia y causas','BH con índices y hierro','WHO_HB24',notes='Ajustar altitud/tabaquismo y grupos poblacionales según OMS.')
add('Hematología','Anemia mujer no embarazada','CONSULTA','CRITERIO_LAB','OPCIONAL','hb_gdl, embarazo','Hb <12.0 g/dL en mujer no embarazada','Laboratorio actual','Evaluar anemia y causas','BH/ferropenia','WHO_HB24')
add('Hematología','Anemia severa en no embarazada','URGENTE','CRITERIO_LAB','OPCIONAL','hb_gdl, embarazo','Hb <8.0 g/dL en adulto no embarazado','Laboratorio actual','Valoración médica prioritaria','BH, signos clínicos, causas','WHO_HBSEV24',notes='Severidad terapéutica depende de síntomas, rapidez y contexto; no ordenar transfusión automáticamente.')
add('Hematología','Anemia gestacional primer trimestre','CONSULTA','CRITERIO_LAB','OPCIONAL','hb_gdl, trimestre','Embarazo 1er trimestre y Hb <11.0 g/dL','Actual','Evaluación obstétrica/nutricional','BH y hierro','WHO_HB24')
add('Hematología','Anemia gestacional segundo trimestre','CONSULTA','CRITERIO_LAB','OPCIONAL','hb_gdl, trimestre','Embarazo 2º trimestre y Hb <10.5 g/dL','Actual','Evaluación obstétrica','BH y hierro','WHO_HB24')
add('Hematología','Anemia gestacional tercer trimestre','CONSULTA','CRITERIO_LAB','OPCIONAL','hb_gdl, trimestre','Embarazo 3er trimestre y Hb <11.0 g/dL','Actual','Evaluación obstétrica','BH y hierro','WHO_HB24')
add('Hematología','Anemia microcítica','CONSULTA','PATRON','OPCIONAL','hb_gdl, vcm_fl','Anemia confirmada y VCM <80 fL','Misma BH','Solicitar ferritina y estudio de hierro','Perfil férrico','WHO_HB24','DERIVADA',notes='No equivale a ferropenia; considerar hemoglobinopatías.')
add('Hematología','Anemia macrocítica','CONSULTA','PATRON','OPCIONAL','hb_gdl, vcm_fl','Anemia confirmada y VCM >100 fL','Misma BH','Estudiar B12, folato, tiroides, hígado y fármacos','B12, folato, TSH','WHO_HB24','DERIVADA')
add('Hematología','Caída acelerada de Hb','URGENTE','PATRON','OPCIONAL','hb_gdl_serie','Disminución significativa de Hb en análisis consecutivos','Días-semanas','Valoración según magnitud y síntomas','Repetir BH/estudio hemorragia','WHO_HB24','EXPERIMENTAL',notes='No existe delta único clínicamente universal para todos los contextos.')
add('Hematología','Neutropenia severa','CONSULTA','CRITERIO_LAB','OPCIONAL','anc_celul_uL','Recuento absoluto de neutrófilos ANC <500/µL','BH actual','Evaluación prioritaria del riesgo infeccioso','BH y evaluación clínica','IDSA_NEUTRO',notes='Contexto de quimioterapia/inmunodeficiencia afecta urgencia.')
add('Hematología','Neutropenia febril','CRITICA','PATRON','BASE+OPCIONAL','anc, temperatura_clinica','ANC <500/µL + fiebre oral >=38.3 °C una vez O >=38 °C >=1h','Mismo episodio','Urgencia hospitalaria por neutropenia febril','Evaluación clínica inmediata','IDSA_NEUTRO',notes='Definición en contexto oncológico; fiebre puede faltar, especialmente inmunosupresión.')
add('Hematología','Plaquetopenia notable','CONSULTA','CRITERIO_LAB','OPCIONAL','plaquetas_uL','Plaquetas <50,000/µL','BH actual','Valorar riesgo hemorrágico y causa','BH repetida y frotis','AABB_PLT25','DERIVADA',notes='No existe umbral de transfusión universal; depende de procedimiento, sangrado y contexto.')
add('Hematología','Plaquetas extremadamente bajas','URGENTE','CRITERIO_LAB','OPCIONAL','plaquetas_uL','Plaquetas <10,000/µL','BH actual','Valoración hospitalaria urgente de sangrado y etiología','Repetición si pseudotrombocitopenia','AABB_PLT25',notes='El umbral de transfusión publicado depende de población; no automatizar indicación transfusional.')
add('Hematología','Leucocitosis','CONSULTA','CRITERIO_LAB','OPCIONAL','leucocitos_uL','Leucocitos >11,000/µL','BH actual','Investigar causas según contexto','BH diferencial, clínica','WHO_HB24','EXPERIMENTAL',notes='Corte de uso frecuente, no diagnóstico etiológico ni procedente de la guía OMS citada, fuente contextual solamente.')
add('Hematología','Leucopenia','CONSULTA','CRITERIO_LAB','OPCIONAL','leucocitos_uL','Leucocitos <4,000/µL','BH actual','Revisar diferencial, fármacos, infecciones','Repetición BH diferencial','WHO_HB24','EXPERIMENTAL',notes='Límite del laboratorio prevalece; OMS de anemia no guía leucopenia; no etiquetar inmunodeficiencia.')
add('Hematología','Ferropenia en contexto de anemia','CONSULTA','CRITERIO_LAB','OPCIONAL','anemia, ferritina','Anemia + ferritina <45 ng/mL','Mismo episodio','Investigar ferropenia y etiología','Perfil férrico, clínica','AGA_FERR',notes='AGA recomienda corte 45 ng/mL en anemia; puede falsamente elevarse con inflamación.')
add('Hematología','Deficiencia B12 muy probable','CONSULTA','CRITERIO_LAB','OPCIONAL','b12_total_ngL','B12 total <180 ng/L (133 pmol/L)','Laboratorio actual','Evaluar y tratar según criterio clínico','Interpretar ensayo; confirmar si procede','NICE_B12')
add('Hematología','B12 indeterminada','CONSULTA','CRITERIO_LAB','OPCIONAL','b12_total_ngL','B12 total 180–350 ng/L','Laboratorio actual','Considerar ácido metilmalónico según clínica','MMA y laboratorio','NICE_B12',notes='No diagnosticar deficiencia únicamente con resultado indeterminado.')

# ELECTROLITOS
add('Electrolitos','Hiponatremia leve','CONSULTA','CRITERIO_LAB','OPCIONAL','sodio_mmolL','Na 130–134 mmol/L','Actual','Investigar según síntomas/tiempo/volemia','Repetir sodio; clínica','ENDO_NA')
add('Electrolitos','Hiponatremia moderada','URGENTE','CRITERIO_LAB','OPCIONAL','sodio_mmolL','Na 125–129 mmol/L','Actual','Valoración clínica pronta','Confirmar sodio y osmolalidad','ENDO_NA')
add('Electrolitos','Hiponatremia profunda','URGENTE','CRITERIO_LAB','OPCIONAL','sodio_mmolL','Na <125 mmol/L','Actual','Evaluación urgente según síntomas','Sodio, osmolalidad, evaluación neurológica','ENDO_NA',notes='No determinar infusión ni tasa de corrección desde algoritmo; daño por corrección rápida.')
add('Electrolitos','Hipercalemia leve','CONSULTA','CRITERIO_LAB','OPCIONAL','potasio_mmolL','K 5.5–5.9 mmol/L','Actual','Revisar causas, función renal y hemólisis','Repetir K y creatinina','UKKA_K23')
add('Electrolitos','Hipercalemia moderada','URGENTE','CRITERIO_LAB','OPCIONAL','potasio_mmolL','K 6.0–6.4 mmol/L','Actual','Evaluación prioritaria, especialmente AKI/enfermedad aguda','ECG y confirmación si procede','UKKA_K23')
add('Electrolitos','Hipercalemia grave','CRITICA','CRITERIO_LAB','OPCIONAL','potasio_mmolL','K >=6.5 mmol/L','Actual','Evaluación hospitalaria urgente','ECG y laboratorio','UKKA_K23')
add('Electrolitos','Hipocalemia por laboratorio','CONSULTA','CRITERIO_LAB','OPCIONAL','potasio_mmolL','K <3.5 mmol/L','Actual','Revisar causas y ECG según contexto','Repetir K, Mg, ECG si grave','UKKA_K23','DERIVADA',notes='Rangos del laboratorio y contexto determinan gravedad.')
add('Electrolitos','Hipocalemia profunda','URGENTE','CRITERIO_LAB','OPCIONAL','potasio_mmolL','K <2.5 mmol/L','Actual','Evaluación urgente por riesgo de arritmias','ECG, K, Mg','UKKA_K23','DERIVADA',notes='Umbral práctico; la fuente citada aborda hipercalemia, requiere validación con protocolo de hipocalemia local.')

# ENDOCRINO Y REPRO
add('Tiroides','Hipotiroidismo primario bioquímico','CONSULTA','CRITERIO_LAB','OPCIONAL','TSH, FT4, intervalos_lab','TSH elevada y FT4 bajo el rango','Misma extracción','Consulta endocrinológica/clínica','TSH/FT4 y clínica','ATA_TFT')
add('Tiroides','Hipertiroidismo bioquímico','CONSULTA','CRITERIO_LAB','OPCIONAL','TSH, FT4, T3, intervalos_lab','TSH baja y FT4 o T3 elevados','Misma extracción','Evaluar hipertiroidismo y riesgo de arritmia','TFT e investigación etiológica','ATA_TFT')
add('Tiroides','TSH elevada FT4 normal','CONSULTA','CRITERIO_LAB','OPCIONAL','TSH, FT4','TSH sobre LSN y FT4 normal, persistente','Repetición laboratorio','Evaluar hipotiroidismo subclínico','TSH repetida, anticuerpos según clínica','ATA_TFT')
add('Tiroides','TSH suprimida FT4 normal','CONSULTA','CRITERIO_LAB','OPCIONAL','TSH, FT4','TSH bajo LIN y FT4 normal','Repetición laboratorio','Evaluar hipertiroidismo subclínico/T3','TSH, FT4, T3','ATA_TFT')
add('Reproductivo','Irregularidad menstrual','CONSULTA','PATRON','CONTEXTO_ADICIONAL','longitud_ciclos, años_postmenarquia','Ciclos <21 o >35 días o <8 ciclos/año (>=3 años posmenarquia)','Múltiples ciclos','Evaluar disfunción ovulatoria, posible SOP y causas','Historial menstrual y valoración','PCOS23',notes='Fase de ovulación aislada NO permite inferir duración de ciclos; requiere registro longitudinal.')
add('Reproductivo','Amenorrea prolongada no explicada','CONSULTA','PATRON','CONTEXTO_ADICIONAL','fecha_ultima_regla, embarazo','Ausencia de ciclo >90 días en contexto aplicable, embarazo descartado','>90 días','Revisión de causas endocrinas y reproductivas','Prueba embarazo, TSH, prolactina etc.','PCOS23',notes='Embarazo/anticonceptivos/menopausia/situaciones especiales deben conocerse.')
add('Reproductivo','SOP a evaluar con hiperandrogenismo','CONSULTA','SOSPECHA','OPCIONAL','irregularidad_menstrual, testosterona','Disfunción ovulatoria + hiperandrogenismo bioquímico comprobado','Múltiples ciclos y laboratorio','Evaluación de SOP y descarte de otras causas','Clínica y pruebas específicas','PCOS23',notes='No se diagnostica con temperatura/fase sola; AMH no es prueba única.')
add('Embarazo','Hipertensión obstétrica','URGENTE','CRITERIO_CLINICO','CONTEXTO_ADICIONAL','embarazo_confirmado, semana_gestacional, pa_validada','Embarazo confirmado >=20 sem y PAS >=140 o PAD >=90 confirmada en 2 mediciones separadas >=4h','>=4h','Valoración obstétrica pronta','Evaluación obstétrica','ACOG_BP',notes='No asumir embarazo por fase ovulatoria.')
add('Embarazo','Hipertensión severa obstétrica','CRITICA','CRITERIO_CLINICO','CONTEXTO_ADICIONAL','embarazo_confirmado, pa_validada','Embarazo confirmado y PAS >=160 O PAD >=110','Confirmación en intervalo corto','Evaluación obstétrica inmediata','Valoración obstétrica','ACOG_BP')
add('Embarazo','Sospecha de preeclampsia por proteinuria','URGENTE','SOSPECHA','OPCIONAL','embarazo, sem_gest, pa_validada, proteina_orina','Embarazo >=20 sem con HTA nueva + proteinuria >=300 mg/24h o proteína/creatinina >=0.3','Actual','Evaluación obstétrica urgente','Pruebas de órgano blanco','ACOG_BP')
add('Embarazo','Posibles datos de preeclampsia con daño de órgano','CRITICA','SOSPECHA','OPCIONAL','embarazo, pa_validada, plaquetas, creatinina, ALT/AST','Embarazo >=20 sem con HTA + plaquetas <100k o creatinina >1.1 o >=2x basal, o enzimas hepáticas >=2x LSN','Actual','Evaluación obstétrica inmediata','Pruebas obstétricas y clínica','ACOG_BP')
add('Embarazo','Cribado diabetes gestacional','CRIBADO','RIESGO','CONTEXTO_ADICIONAL','embarazo, semanas_gestacion','Embarazo 24–28 semanas y sin cribado documentado','24–28 semanas','Solicitar cribado según protocolo obstétrico','OGTT en laboratorio','ADA_GDM26')
add('Embarazo','GDM por OGTT 75g','CONSULTA','CRITERIO_LAB','OPCIONAL','embarazo, OGTT_0, OGTT_1, OGTT_2','Embarazo: ayuno >=92 o 1h >=180 o 2h >=153 mg/dL según estrategia de un paso','Mismo OGTT','Valoración obstétrica de diabetes gestacional','OGTT laboratorio','ADA_GDM26',notes='Estrategia específica, otra estrategia de dos pasos usa criterios diferentes.')

# MULTIVARIABLE Y SUPRESIONES/ABSTENCION
add('Seguridad lógica','No interpretar PA cuffless como diagnóstica','SEGUIMIENTO','ABSTENCION','BASE','tipo_sensor_PA','Si PA procede de estimación cuffless sin validación diagnóstica','Cada medición','Permitir observación exploratoria; desactivar decisiones diagnósticas basadas en PA','Manguito validado/ABPM','AHA_BP25','GUIA',notes='Regla de seguridad transversal, prioritaria a cualquier umbral de PA.')
add('Seguridad lógica','No interpretar CGM como diagnóstico diabetes','SEGUIMIENTO','ABSTENCION','BASE','tipo_glucosa','Si fuente es CGM intersticial y no hay analítica confirmatoria','Cada evento','Abstener diagnóstico diabetes/prediabetes','HbA1c/FPG/OGTT laboratorio','ADA26','GUIA')
add('Seguridad lógica','No diagnosticar FA sin ECG','SEGUIMIENTO','ABSTENCION','BASE','tipo_registro_ritmo','Irregularidad PPG sin registro ECG','Cada episodio','Clasificar como sospecha, recomendar ECG','ECG interpretado','ESC_AF24','GUIA')
add('Seguridad lógica','No calcular NEWS2 incompleto','SEGUIMIENTO','ABSTENCION','BASE','RR, consciencia, oxigeno_suplementario, SpO2, FC, PA, temperatura','Falta cualquier componente requerido del NEWS2','Cada evento','Abstenerse de presentar score como NEWS2','NEWS2 con variables completas','NICE_SEPSIS','GUIA')
add('Seguridad lógica','No diagnosticar infarto ni ictus con biometría base','SEGUIMIENTO','ABSTENCION','BASE','sin_ECG_troponinas_neurologia','Solo FC, SpO2, PA, glucosa y antropometría sin signos clínicos','Cada evento','Sin detector específico; informar limitación y permitir alertas generales','ECG/troponina/exploración neurológica','ESC_AF24','DERIVADA')
add('Seguridad lógica','Pedir embarazo antes de reglas obstétricas','SEGUIMIENTO','ABSTENCION','CONTEXTO_ADICIONAL','estado_embarazo','Embarazo desconocido','Cada intento','No activar diagnósticos gestacionales ni aplicar rangos fisiológicos de embarazo','Prueba de embarazo/registro','ACOG_BP','GUIA')
add('Seguridad lógica','No diagnosticar anemia sin BH','SEGUIMIENTO','ABSTENCION','BASE','hemoglobina','Hemoglobina no disponible','Cada intento','Anemia=DESCONOCIDA; posible solicitud BH según contexto','Biometría hemática','WHO_HB24','GUIA')
add('Seguridad lógica','No calcular FIB4 sin plaquetas/AST/ALT','SEGUIMIENTO','ABSTENCION','OPCIONAL','edad, AST, ALT, plaquetas','Faltan variables o paciente acutamente enfermo','Cada intento','Desactivar FIB4 y sugerir laboratorio si procede','Perfil hepático y BH','AASLD_MASLD','GUIA')

# 20 antecedentes y 20 secuelas
HIST=[
('Diabetes mellitus tipo 1','Activar ruta de seguridad CGM; priorizar hipoglucemia y cetonas'),
('Diabetes mellitus tipo 2','Activar vigilancia de glucosa, eGFR/ACR, lípidos y cardiovascular'),
('Hipertensión arterial','Revisar control con dispositivo validado, no tamizaje inicial'),
('Enfermedad coronaria/infarto','Prevención cardiovascular secundaria'),
('Insuficiencia cardíaca','Priorizar aumentos rápidos de peso, FC y cambios respiratorios'),
('Fibrilación auricular','Evaluar carga y riesgo tromboembólico con historial completo'),
('Taquicardia supraventricular previa','Incrementar prioridad de evaluación ECG ante episodios'),
('Ictus o AIT','Prevención vascular secundaria; priorizar FA/PA'),
('Enfermedad arterial periférica','Riesgo aterosclerótico elevado; vigilancia vascular'),
('Enfermedad renal crónica','Vigilar potasio, creatinina, PA y albuminuria'),
('Lesión renal aguda previa','Mayor atención a aumentos de creatinina'),
('Apnea obstructiva del sueño','Interpretar desaturaciones con ruta de seguimiento'),
('EPOC','Usar saturación basal personalizada y plan de oxígeno'),
('Asma grave','Priorizar cambios de SpO2 en contexto respiratorio'),
('Cirrosis/MASLD conocida','Vigilar función hepática, renal, plaquetas y fibrosis'),
('Hipotiroidismo','Interpretar TSH/FT4, peso y FC con contexto'),
('Hipertiroidismo','Mayor sospecha clínica en taquicardia/FA'),
('SOP','Mayor vigilancia metabólica y menstrual'),
('Diabetes gestacional previa','Cribado posterior periódico de DM'),
('Enfermedad oncológica con tratamiento inmunosupresor','Fiebre+ANC bajo puede ser emergencia')]
SEQUELAE=[
('Hemiparesia postictus','Evitar modelos de actividad física sin ajuste'),
('Afasia residual','No confiar exclusivamente en reporte de síntomas'),
('Amputación de extremidad','Interpretar IMC y antropometría mediante ajuste'),
('Marcapasos implantado','FC basal depende de programación'),
('Desfibrilador implantable','Interpretar arritmias con revisión dispositivo'),
('Válvula cardíaca protésica','Priorizar evaluación clínica cardiovascular'),
('Trasplante renal','Vigilancia específica de función renal'),
('Riñón único','Enfatizar tendencia eGFR/ACR'),
('Diálisis crónica','Peso interdialítico/electrolitos requieren reglas individuales'),
('Neuropatía autonómica','Ajustar interpretación FC/PA ortostáticas'),
('Neuropatía periférica diabética','No inferir ausencia de lesión por ausencia de dolor'),
('Retinopatía diabética avanzada','Riesgo microvascular establecido'),
('Secuela pulmonar post-tuberculosis','Individualizar SpO2 basal'),
('Fibrosis pulmonar','Desaturaciones tienen relevancia contextual'),
('Traqueostomía permanente','Protocolo respiratorio especializado'),
('Esplenectomía','Bajo umbral para evaluar fiebre clínicamente'),
('Cirrosis con hipertensión portal','Plaquetas, renal y sangrado cobran prioridad'),
('Menopausia quirúrgica','No usar fase ovulatoria como variable activa'),
('Ooforectomía','Interpretación hormonal y ciclos individualizada'),
('Antecedente obstétrico de alto riesgo con secuela','Ruta cardiovascular/obstétrica individualizada')]

VARIABLES=[]
def var(name,unit,origin,period,quality,mandatory,notes):
    VARIABLES.append(dict(variable=name,unidad=unit,origen=origin,frecuencia=period,validacion=quality,estatus=mandatory,observaciones=notes))
for t in [
('edad','años','Registro','Actualización anual','Fecha nacimiento fiable','BASE','Mayoría reglas adultas; pediatricas requieren modelo aparte'),
('estatura_cm','cm','Medición antropométrica','Anual','Protocolo antropométrico','BASE','Altura útil IMC y cintura/estatura'),
('peso_kg','kg','Báscula','Diaria-semanal','Misma báscula/hora','BASE','No atribuir cambios rápidos a grasa'),
('imc','kg/m²','Derivada peso/talla','Por pesaje','Metadatos talla/peso','DERIVADA','No aplicar a embarazo sin ajustes'),
('cintura_cm','cm','Cinta métrica','Mensual','Localización anatómica precisa','BASE','Medidas corporales disponibles deben especificar cuáles'),
('cadera_cm','cm','Cinta métrica','Mensual','Protocolo','BASE','Para razón cintura-cadera'),
('temperatura','°C','Termómetro o wearable','Continua','Distinguir piel, timpánica, oral, central','BASE','No intercambiar cortes de temperatura cutánea y central'),
('fc_reposo','lpm','PPG/ECG','Continua','Excluir movimiento e intervalos con arrastre de señal','BASE','Guardar contexto actividad/sueño'),
('hrv_rmssd','ms','PPG/ECG','Nocturna','Algoritmo compatible por dispositivo','BASE','No es detector específico de enfermedad'),
('irregularidad_ppg','booleano','PPG validada','Continuo','Alertas de irregularidad, no trazado ECG','BASE','FA requiere confirmación ECG'),
('pa_sistolica','mmHg','Manguito/ABPM/cuffless','Continua/repetida','Validación por tecnología y momento','BASE','Cuffless NO sirve para diagnóstico'),
('pa_diastolica','mmHg','Manguito/ABPM/cuffless','Continua/repetida','Validación por tecnología y momento','BASE','Guardar postura, hora y dispositivo'),
('cgm','mg/dL','Glucosa intersticial','1–5 min','Cobertura/calibración/compresión','BASE','No valida diagnóstico diabetes'),
('spo2','%','Oxímetro','Continua/nocturna','Perfusión, movimiento, tono de piel, altitud','BASE','No extrapolar directamente a gasometría'),
('fase_ovulatoria','categoría','Autorreporte o algoritmo','Ciclo','Confirmación de fecha/fase','BASE_SEGUN_CORRESPONDA','Fase aislada NO es duración de ciclo'),
('origen_etnico','autodeclaración','Registro','Estático','No biología sustitutiva','BASE','Auditoría de equidad; evitar usar para eGFR'),
('sexo_clinico','categoría','Registro clínico','Según cambios','Datos aplicables a cortes Hb/reproducción','CONTEXTO_ADICIONAL','No inferir automáticamente del origen/ciclo'),
('embarazo','booleano/semana','Registro clínico/prueba','Según estado','Confirmado/documentado','CONTEXTO_ADICIONAL','No inferir de ovulación'),
('actividad','estado','Acelerómetro/registro','Continua','Modelo de actividad','CONTEXTO_ADICIONAL','No está garantizada'),
('ecg','trazado','Dispositivo ECG','Episódico','Trazado interpretable por clínico','OPCIONAL','PPG no reemplaza ECG'),
('hba1c_pct','%','Laboratorio','3–12 meses','Ensayo NGSP; interferencias','OPCIONAL','Criterio diagnósticos diabetes'),
('glucosa_plasma_ayuno','mg/dL','Laboratorio','Según indicación','Ayuno >=8h','OPCIONAL','No CGM'),
('ogtt_2h','mg/dL','Laboratorio','Según indicación','75g y timing adecuados','OPCIONAL','Cribado DM/GDM'),
('tg_mgdl','mg/dL','Laboratorio','Anual/según riesgo','Ayuno según indicación','OPCIONAL','Riesgo pancreatitis >=500'),
('ldl_mgdl','mg/dL','Laboratorio','Anual/según riesgo','Método/reportado','OPCIONAL','ASCVD'),
('hdl_mgdl','mg/dL','Laboratorio','Anual','Confiabilidad laboratorio','OPCIONAL','Metabolismo'),
('ast','U/L','Laboratorio','Episódica','Rango local','OPCIONAL','FIB4'),
('alt','U/L','Laboratorio','Episódica','Rango local','OPCIONAL','FIB4'),
('plaquetas_uL','por µL','Biometría hemática','Episódica','BH; descartar agregación','OPCIONAL','FIB4 y hematología'),
('hemoglobina','g/dL','Biometría hemática','Episódica','Altitud, embarazo, laboratorio','OPCIONAL','Anemia'),
('vcm','fL','Biometría hemática','Episódica','BH','OPCIONAL','Micro/macrocytosis'),
('neutrofilos_absolutos','por µL','Biometría hemática','Episódica','Diferencial','OPCIONAL','Neutropenia febril'),
('creatinina','mg/dL','Laboratorio','Episódica','Serie temporal/protocolo','OPCIONAL','AKI y eGFR'),
('egfr','mL/min/1.73m²','Derivada CKD-EPI sin raza','Por laboratorio','Ecuación y edad/sexo aplicables','DERIVADA','No incluir raza en CKD-EPI'),
('acr_orina','mg/g','Laboratorio','Episódica','Confirmar persistencia','OPCIONAL','ERC'),
('sodio','mmol/L','Laboratorio','Episódica','Rangos/estado clínico','OPCIONAL','Hiponatremia'),
('potasio','mmol/L','Laboratorio','Episódica','Comprobar hemólisis','OPCIONAL','Arritmias'),
('b12_total','ng/L','Laboratorio','Episódica','Assay y laboratorio','OPCIONAL','No generalizar rangos a todos los ensayos'),
('ferritina','ng/mL','Laboratorio','Episódica','Inflamación distorsiona','OPCIONAL','Hierro'),
('tsh','mIU/L','Laboratorio','Episódica','Referencia por ensayo/embarazo','OPCIONAL','Tiroides'),
('ft4','ng/dL o pmol/L','Laboratorio','Episódica','Unidades y método','OPCIONAL','Tiroides'),
('testosterona','unidad ensayo','Laboratorio','Episódica','LC-MS/MS preferido en rango bajo','OPCIONAL','SOP'),
('beta_hidroxibutirato','mmol/L','Lab/POCT','Aguda','Método estandarizado','OPCIONAL','DKA'),
('bicarbonato','mmol/L','Laboratorio','Aguda','Sangre venosa/gasometría','OPCIONAL','DKA'),
('ph','adimensional','Gasometría','Aguda','Calidad muestra','OPCIONAL','DKA'),
('antecedentes_personales','códigos','Historia clínica','Permanente','Codificación + fecha','BASE','Desconocido no equivale a negativo'),
('secuelas_permanentes','códigos','Historia clínica','Permanente','Especificación de severidad','BASE','Modificadores contextuales'),
('antecedentes_familiares','códigos','Historia clínica','Estático','Parentesco/edad evento','CONTEXTO_ADICIONAL','No garantizados'),
]: var(*t)

# Make clinical design notes
README=[
['Motor de alertas biométricas — catálogo v0.2','Revisión de trabajo | 14 nov 2026'],
['Propósito','Reglas de cribado/alertas preventivas para prototipo; NO son órdenes médicas ni software clínico validado.'],
['Interpretación','Corte numérico solo habilitado cuando tipo de sensor, población y ventana corresponden a la fuente.'],
['Disponibilidad BASE','Edad, talla, peso, temperatura, mediciones corporales, FC, PA, CGM, SpO2, etnicidad autodeclarada, fase menstrual cuando corresponda.'],
['Disponibilidad OPCIONAL','BH, lípidos, química clínica, hormonas, ECG, pruebas clínicas.'],
['CONTEXTO_ADICIONAL','Variable NO garantizada (p. ej., embarazo, actividad, postura, diuresis, síntomas, duración del ciclo). La regla se abstiene sin ella.'],
['Evidencia GUIA','Criterio respaldado por guía en población/condición indicada, NO sensibilidad validada del motor.'],
['Evidencia DERIVADA','Regla estructurada a partir de guías, pero el patrón compuesto no ha sido validado como alerta.'],
['Evidencia EXPERIMENTAL','Heurística de investigación; deshabilitar para notificación a pacientes hasta validación.'],
['Tipo ABSTENCION','Regla de seguridad de la interpretación; impide afirmaciones sin datos válidos.'],
['Severidades','CRITICA: evaluación inmediata; URGENTE: evaluación pronta; CONSULTA: evaluación programada; CRIBADO: prueba formal; SEGUIMIENTO: tendencia/observación.'],
['Control de datos','Faltante=UNKNOWN, no NEGATIVE. Calidad baja -> abstención/repetir; usar metadatos unidad, tipo sensor, sitio, timestamp y validación.'],
['Población','Por defecto adultos >=18; IMC CDC se define para 20+; gestación/menores requieren rutas distintas.'],
['Advertencia clínica','Ni infarto, ictus, sepsis, OSA, anemia ni diabetes se diagnostican con los sensores base.'],
['Calidad y regulación','Validación clínica prospectiva, auditoría de equidad, revisión médica y regulatoria para México antes de despliegue.'],
['Fuentes','Fuentes es matriz de URLs directas. La columna fuente_id enlaza catálogo y fuentes.'],
]

# Save JSON and CSV before workbook
bundle=dict(meta={'version':'0.2','fecha':'2026-11-14','finalidad':'investigacion no diagnostica','n_reglas':len(RULES),'alertas_no_validadas':'experimental_off_by_default'},reglas=RULES,variables=VARIABLES,antecedentes=[dict(enfermedad=a,efecto=b) for a,b in HIST],secuelas=[dict(secuela=a,efecto=b) for a,b in SEQUELAE],fuentes=[dict(id=k,url=v) for k,v in S.items()])
with open(f'{OUT}/motor_alertas_catalogo_v02.json','w',encoding='utf-8') as f: json.dump(bundle,f,ensure_ascii=False,indent=2)
with open(f'{OUT}/motor_alertas_reglas_v02.csv','w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(RULES[0])); w.writeheader();w.writerows(RULES)

# XLSX via artifact_tool
wb=Workbook.create()
def tab(name, headers, rows, widths=None, color='#174A59'):
    sh=wb.worksheets.add(name)
    m=[list(headers)]+[list(x) for x in rows]
    cols=len(headers)
    sh.get_range_by_indexes(0,0,len(m),cols).values=m
    sh.freeze_panes.freeze_rows(1)
    try: sh.get_range_by_indexes(0,0,1,cols).format={'fill':color,'font':{'bold':True,'color':'#FFFFFF'},'row_height':32,'wrap_text':True,'vertical_alignment':'center'}
    except Exception as exc: print('header style issue',name,exc)
    try: sh.get_range_by_indexes(1,0,len(rows),cols).format.row_height=26
    except Exception: pass
    for idx in range(cols):
        width=widths[idx] if widths else 24
        sh.get_range_by_indexes(0,idx,len(m),1).format.column_width=width
    return sh
rheaders=['ID','DOMINIO','CONDICIÓN','SEVERIDAD','TIPO','DISPONIBILIDAD','VARIABLES','SI (LÓGICA CLÍNICA)','VENTANA','ENTONCES (ACCIÓN)','CONFIRMACIÓN','EVIDENCIA','FUENTE ID','POBLACIÓN','LIMITACIONES','FUENTE URL']
rr=[ [r[x] for x in ['id','dominio','condicion','severidad','tipo_inferencia','disponibilidad','variables_necesarias','criterio_SI','ventana','resultado_ENTONCES','prueba_confirmatoria','estado_evidencia','fuente_id','poblacion','limitaciones','fuente_url']] for r in RULES]
sh=tab('Reglas',rheaders,rr,[10,25,36,15,17,21,37,75,24,64,40,16,19,22,73,52]);
# Readme summary
x=tab('Inicio',['CONCEPTO','DETALLE'],README,[43,100], '#0F766E')
varsh=tab('Diccionario',list(VARIABLES[0].keys()),[[r[k] for k in VARIABLES[0]] for r in VARIABLES],[31,21,32,28,50,24,80],'#375A49')
a=tab('Antecedentes',['N','ENFERMEDAD PREVIA','CAMBIO EN ALERTAS'],[[i+1,x,y] for i,(x,y) in enumerate(HIST)],[8,45,92],'#713D54')
b=tab('Secuelas',['N','SECUELA/ESTADO PERMANENTE','CAMBIO EN INTERPRETACIÓN'],[[i+1,x,y] for i,(x,y) in enumerate(SEQUELAE)],[8,48,88],'#713D54')
f=tab('Fuentes',['ID','URL'],[[k,v] for k,v in S.items()],[25,110],'#3C525F')
counts=Counter(r['dominio'] for r in RULES)
meta=tab('Cobertura',['DOMINIO','N REGLAS','CONSIDERACIÓN'],[[k,v,'Criterios diagnósticos requieren prueba confirmatoria; reglas EXPERIMENTAL apagadas.'] for k,v in sorted(counts.items())]+[['TOTAL',len(RULES),'20 enfermedades previas, 20 secuelas permanentes.']],[32,17,92],'#365078')
try:
    sh.get_range('D2:D'+str(len(RULES)+1)).conditional_formats.add_custom('=$D2="CRITICA"',{'fill':'#FEE2E2','font':{'color':'#991B1B','bold':True}})
    sh.get_range('L2:L'+str(len(RULES)+1)).conditional_formats.add_custom('=$L2="EXPERIMENTAL"',{'fill':'#FEF3C7'})
except Exception as exc: print('conditional style issue',exc)
path=f'{OUT}/catalogo_alertas_biometricas_v02.xlsx'
SpreadsheetFile.export_xlsx(wb).save(path)
assert len(RULES)>95, len(RULES)
assert len(HIST)==20 and len(SEQUELAE)==20
print('REGLAS',len(RULES),'VARIABLES',len(VARIABLES),'DOMINIOS',len(counts),'FUENTES',len(S))
print('EVIDENCIA',Counter(r['estado_evidencia'] for r in RULES))
print('SEVERIDAD',Counter(r['severidad'] for r in RULES))
print('ARTIFACTS',os.path.getsize(path),os.path.getsize(f'{OUT}/motor_alertas_catalogo_v02.json'))
try: print('INSPECT',wb.inspect({'kind':'table','range':'Reglas!A1:F5','include':'values','table_max_rows':5,'table_max_cols':6}).ndjson[:1000])
except Exception as exc: print('inspect issue',exc)
