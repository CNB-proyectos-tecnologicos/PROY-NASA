"""Amplía catálogo v02 con reglas fuente-referenciadas, calibración honesta y modelos cuantitativos."""
import json,csv,math,os,collections,datetime,random
from pathlib import Path
from artifact_tool import Workbook, SpreadsheetFile
OUT=Path('/mnt/data'); base=json.loads((OUT/'motor_alertas_catalogo_v02.json').read_text())
S={x['id']:x['url'] for x in base['fuentes']}
S.update({
'ADA_DX26':'https://pmc.ncbi.nlm.nih.gov/articles/PMC12690183/',
'ADA_GLY26':'https://doi.org/10.2337/dc26-s006',
'AHA_PREVENT':'https://professional.heart.org/en/guidelines-and-statements/prevent-calculator',
'ACC_LIP26':'https://www.jacc.org/doi/10.1016/j.jacc.2025.11.016',
'NICE_BP25':'https://www.ahajournals.org/doi/10.1161/CIR.0000000000001356',
'KDIGO24':'https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf',
'KFRE_TANGRI16':'https://jamanetwork.com/journals/jama/fullarticle/2481005',
'KFRE_RECAL':'https://renalcarematters.com/guides/calc-kfre',
'KFRE_BMJ':'https://bmjopen.bmj.com/content/14/1/e076217',
'NIDDK_EGFR':'https://www.niddk.nih.gov/research-funding/research-programs/kidney-clinical-research-epidemiology/laboratory/glomerular-filtration-rate-equations/adults',
'NICE_AKI':'https://www.nice.org.uk/guidance/ng148/chapter/Recommendations',
'NICE_SEPSIS':'https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk',
'AHA_CUFFLESS':'https://professional.heart.org/en/science-news/cuffless-devices-for-the-measurement-of-blood-pressure/top-things-to-know',
'ACC_PAD24':'https://www.jacc.org/doi/10.1016/j.jacc.2024.02.013',
'WHO_HB24':'https://www.ncbi.nlm.nih.gov/books/NBK602183/table/fm-ch1.tab2/',
'AGA_IRON20':'https://gastro.org/clinical-guidance/gastrointestinal-evaluation-of-iron-deficiency-anemia/',
'NICE_B12_24':'https://www.nice.org.uk/guidance/ng239/chapter/recommendations',
'NICE_TSH':'https://www.nice.org.uk/guidance/ng145/chapter/recommendations',
'UKKA_K26':'https://guidelines.ukkidney.org/hyperkalaemia/',
'ACOG_PREE':'https://www.acog.org/womens-health/faqs/preeclampsia-and-high-blood-pressure-during-pregnancy',
'PCOS_GUIDE23':'https://academic.oup.com/jcem/article/108/10/2447/7242360',
'AASM_SLEEPMED':'https://aasm.org/resources/clinicalguidelines/diagnostic-testing-osa.pdf',
'ESC_SCORE':'https://www.escardio.org/guidelines/practice-tools/cvd-prevention-toolbox/score2-and-score2-op-calculators/',
'ACG_FIB4':'https://pmc.ncbi.nlm.nih.gov/articles/PMC10735173/',
'AASLD_FIB4':'https://pmc.ncbi.nlm.nih.gov/articles/PMC10735173/',
'ADA_GLY24':'https://pmc.ncbi.nlm.nih.gov/articles/PMC10725808/',
'ISPAD_CGM24':'https://pmc.ncbi.nlm.nih.gov/articles/PMC11854985/',
'FDA_SPO2':'https://www.fda.gov/medical-devices/products-and-medical-procedures/pulse-oximeters',
'NICE_OBESITY':'https://www.nice.org.uk/guidance/ng246/chapter/Identifying-and-assessing-overweight-obesity-and-central-adiposity',
'WHO_BMI':'https://www.cdc.gov/bmi/adult-calculator/bmi-categories.html',
'IDSA_FN':'https://www.idsociety.org/practice-guideline/neutropenic-patients-with-cancer/',
'ESC_AF':'https://academic.oup.com/eurheartj/article/45/36/3314/7738779',
'ATS_OXYGEN':'https://academic.oup.com/ajrccm/article/202/10/e121/8495596',
})
# v03 ficha: dominio|condicion|criterio SI verificable|variables requeridas|severidad|fuente|clasificacion [G corte en guía, D extrapolación, E exploratoria]|cuantificación
# En reglas D/E, corte explícito es para investigación, NO validación clínica de esa regla.
B='''
Calidad de datos|Presión sin manguito, no diagnóstica|PA obtenida por estimación cuffless sin validación ni calibración documentada|pa_modo_dispositivo|SEGUIMIENTO|AHA_CUFFLESS|G|NINGUNA
Calidad de datos|Oximetría sin señal fiable|SpO2 sin índice de perfusión/calidad o con movimiento durante el episodio|spo2_calidad;movimiento|SEGUIMIENTO|FDA_SPO2|D|NINGUNA
Calidad de datos|Oximetría discordante|SpO2 cambia ≥5 pp en <30 s sin correlación clínica o señal estable|spo2;spo2_calidad|SEGUIMIENTO|FDA_SPO2|E|DELTA_PP
Calidad de datos|Glucosa CGM no diagnóstica|Paciente sin diabetes: pretensión de etiquetar diabetes por datos CGM exclusivamente|cgm;diabetes_previa|SEGUIMIENTO|ADA_DX26|G|NINGUNA
Calidad de datos|Falta ventana basal de FC|Serie FC histórica <7 días útiles para calcular cambio relativo personalizado|fc_serie;calidad_fc|SEGUIMIENTO|ESC_AF|E|PORCENTAJE_COBERTURA
Calidad de datos|Falta ventana basal PA|Registro PA basal <7 días protocolizados o dispositivo no validado|pa_serie;pa_validada|SEGUIMIENTO|AHA_CUFFLESS|D|PORCENTAJE_COBERTURA
Calidad de datos|Cobertura CGM insuficiente|CGM <70% del tiempo registrado durante 14 días|cgm_14d;cgm_cobertura|SEGUIMIENTO|ISPAD_CGM24|G|PORCENTAJE_COBERTURA
Calidad de datos|Falta sitio de temperatura|Temperatura anormal pero sin método ni sitio de medición|temperatura;tipo_termometro|SEGUIMIENTO|NICE_SEPSIS|D|NINGUNA
Calidad de datos|Posible seudohipercalemia|K sérico elevado y muestra hemolizada|potasio;indice_hemolisis|SEGUIMIENTO|UKKA_K26|D|NINGUNA
Calidad de datos|ALT/AST de diferente extracción|AST y ALT pertenecen a muestras de distinta fecha: evitar FIB-4|ast;alt;fecha_muestra|SEGUIMIENTO|AASLD_FIB4|D|NINGUNA
Calidad de datos|Dos creatininas incomparables|Creatininas proceden de laboratorios/métodos no comparables o unidades sin unificar|creatinina;unidad_creatinina;laboratorio|SEGUIMIENTO|NIDDK_EGFR|D|NINGUNA
Calidad de datos|HbA1c con interferencias posibles|HbA1c discordante respecto de glucosa plasmática o anemia/hemoglobinopatía|hba1c;hemoglobina;hemoglobinopatia|CONSULTA|ADA_DX26|D|NINGUNA
Calidad de datos|Estado de embarazo desconocido|Regla no embarazada requiere exclusión de embarazo y no existe dato|embarazo_estado|SEGUIMIENTO|ACOG_PREE|D|NINGUNA
Calidad de datos|Fase ovulatoria inferida, no medida|Fase menstrual derivada de calendario sin documentación de ovulación|fase_ciclo;origen_fase|SEGUIMIENTO|PCOS_GUIDE23|D|NINGUNA
Calidad de datos|Unidades no verificadas|Umbral depende de mmol/L vs mg/dL o ng/mL vs nmol/L y unidad ausente|laboratorio_unidad|SEGUIMIENTO|NICE_B12_24|D|NINGUNA
Calidad de datos|Antecedente familiar no disponible|Algoritmo exige familia de primer grado pero historial no registra ese dato|antecedente_familiar|SEGUIMIENTO|ADA_DX26|D|NINGUNA
Calidad de datos|Medicaciones no disponibles|PREVENT exige estatinas y tratamiento antihipertensivo pero no se han recopilado|medicacion_estatinas;medicacion_hipertension|SEGUIMIENTO|AHA_PREVENT|G|NINGUNA
Calidad de datos|Tabaquismo no disponible|PREVENT requiere tabaquismo actual y no está registrado|fuma_actual|SEGUIMIENTO|AHA_PREVENT|G|NINGUNA
Calidad de datos|Sexo de fórmula no disponible|Modelo clínico requiere sexo de coeficientes y no se puede inferir a partir del origen étnico|sexo_modelo|SEGUIMIENTO|AHA_PREVENT|D|NINGUNA
Calidad de datos|Riesgo explícitamente no calibrado|Estimación fuera de población o región de desarrollo/validación|region_modelo;poblacion_modelo|SEGUIMIENTO|KFRE_TANGRI16|D|NINGUNA
Calidad de datos|No confundir porcentaje de umbral con riesgo|Cociente medida/umbral no se debe rotular probabilidad de enfermedad|ratio_umbral|SEGUIMIENTO|KDIGO24|D|NINGUNA
Calidad de datos|Datos biométricos fuera de edad adulta|Edad <18 años con reglas marcadas sólo para adultos|edad|SEGUIMIENTO|ADA_DX26|G|NINGUNA
Calidad de datos|No calcular NEWS2 incompleto|No se dispone de frecuencia respiratoria, conciencia o aporte de oxígeno para NEWS2 íntegro|fr;conciencia;oxigenoterapia|SEGUIMIENTO|NICE_SEPSIS|D|NINGUNA
Calidad de datos|No calcular STOP-Bang incompleto|Faltan ronquido, cansancio, apneas presenciadas y/o cuello medido|ronquido;somnolencia;apnea_observada;cuello_cm|SEGUIMIENTO|AASM_SLEEPMED|D|NINGUNA
Calidad de datos|No diagnosticar FA por PPG|Irregularidad PPG sin ECG|ppg_irregular;ecg_fa_confirmada|SEGUIMIENTO|ESC_AF|G|NINGUNA
Calidad de datos|No inferir sepsis de signos aislados|FC alta y T elevada sin sospecha de infección ni signos clínicos suficientes|fc;temperatura;infeccion_sospechada|SEGUIMIENTO|NICE_SEPSIS|G|NINGUNA
Calidad de datos|Ventana menstrual inadecuada|Biomarcador hormonal interpretado sin día de ciclo o anticoncepción conocida|fase_ciclo;hormona;anticonceptivos|SEGUIMIENTO|PCOS_GUIDE23|D|NINGUNA
Calidad de datos|FC sin etiqueta de reposo|FC elevada registrada durante ejercicio y clasificada como FC de reposo|fc;actividad|SEGUIMIENTO|ESC_AF|D|NINGUNA
Calidad de datos|PA sin protocolo|Media de PA incluye mediciones durante movimiento o con manguito mal ajustado|pa;calidad_pa|SEGUIMIENTO|AHA_CUFFLESS|G|NINGUNA
Calidad de datos|SpO2 modificada por altitud|Comparación SpO2 con umbral de nivel mar sin considerar residencia/altura|spo2;altitud_m|SEGUIMIENTO|ATS_OXYGEN|D|NINGUNA
Antropometría|Bajo peso con pérdida reciente|IMC <18.5 y pérdida involuntaria reportada ≥5% en 6 meses|imc;peso_historial;intencionalidad|CONSULTA|WHO_BMI|D|PORCENTAJE_CAMBIO
Antropometría|Obesidad abdominal central moderada|0.50 ≤ cintura/altura <0.60 y IMC <35, adulto|cintura_cm;altura_cm;imc|CONSULTA|NICE_OBESITY|G|COCIENTE
Antropometría|Obesidad abdominal central muy elevada|cintura/altura ≥0.60 y IMC <35, adulto|cintura_cm;altura_cm;imc|CONSULTA|NICE_OBESITY|G|COCIENTE
Antropometría|Cintura/altura saludable|cintura/altura <0.50 en adulto, interpretar con BMI y contexto|cintura_cm;altura_cm|SEGUIMIENTO|NICE_OBESITY|G|COCIENTE
Antropometría|Obesidad clase 1 con HTA corroborada|30≤IMC<35 y HTA confirmada por manguito|imc;hipertension_confirmada|CONSULTA|AHA_BP25|D|NUM_FACTORES
Antropometría|Obesidad clase 2 con prediabetes|35≤IMC<40 y HbA1c 5.7–6.4%|imc;hba1c|CONSULTA|ADA_DX26|D|NUM_FACTORES
Antropometría|Obesidad clase 3 con diabetes conocida|IMC≥40 y diabetes establecida en historia clínica|imc;diabetes_previa|CONSULTA|ADA_DX26|D|NUM_FACTORES
Antropometría|Delgadez con anemia|IMC<18.5 y hemoglobina bajo criterio OMS por sexo/gestación|imc;hb;sexo_modelo|CONSULTA|WHO_HB24|D|NUM_FACTORES
Antropometría|Pérdida de peso sostenida lenta|Pérdida no intencional ≥5% del peso previo durante 6–12 meses|peso_historial;intencionalidad|CONSULTA|WHO_BMI|D|PORCENTAJE_CAMBIO
Antropometría|Incremento de cintura|Cintura aumenta ≥5 cm en 6 meses medidos mismo método|cintura_historial|SEGUIMIENTO|NICE_OBESITY|E|DELTA_CM
Antropometría|Elevación de IMC persistente|IMC≥30 en al menos 2 mediciones separadas≥30 días|imc_historial|CONSULTA|WHO_BMI|D|PORCENTAJE_TIEMPO
Antropometría|Peso en aumento con HTA|Aumento ≥5% peso en 6 meses y PAS promedio ≥140 validada|peso_historial;pas_validada|CONSULTA|AHA_BP25|E|NUM_FACTORES
Antropometría|Peso en caída con hiperglucemia|Pérdida no intencional ≥5% en 6 meses y glucosa plasmática ayuno≥126|peso_historial;glucosa_plasmatica_ayuno|CONSULTA|ADA_DX26|D|NUM_FACTORES
Antropometría|Peso en caída con TSH suprimida|Pérdida involuntaria y TSH <0.1 con FT4 alta para el laboratorio|peso_historial;tsh;ft4|CONSULTA|NICE_TSH|D|NUM_FACTORES
Antropometría|Aumento peso y TSH alta|Aumento ≥5% y TSH sobre rango del laboratorio con FT4 baja|peso_historial;tsh;ft4|CONSULTA|NICE_TSH|D|NUM_FACTORES
Antropometría|Riesgo cardiometabólico combinatorio 3 factores|Cintura/altura≥0.5 + PA≥130/80 validada + HbA1c≥5.7%|cintura_cm;altura_cm;pas_validada;pad_validada;hba1c|CONSULTA|ADA_DX26|E|NUM_FACTORES
Antropometría|Riesgo cardiometabólico combinatorio 4 factores|Regla anterior + TG≥150 mg/dL o HDL bajo según sexo|cintura_cm;altura_cm;pa_validada;hba1c;tg;hdl|CONSULTA|ACC_LIP26|E|NUM_FACTORES
Antropometría|Aumento rápido peso con IC previa|IC conocida y +2 kg dentro de 3 días, báscula comparable|peso_historial;ic_previa|CONSULTA|ESC_HF21|D|DELTA_KG
Antropometría|Caída ponderal y presión|Peso disminuye≥3% en 7 días y PAS basal baja≥15 mmHg|peso_historial;pas_historial|CONSULTA|NICE_SEPSIS|E|NUM_FACTORES
Antropometría|Peso bajo y ferritina baja|IMC<18.5 y ferritina<45 ng/mL con anemia|imc;ferritina;hb|CONSULTA|AGA_IRON20|D|NUM_FACTORES
Presión arterial|HTA aislada sistólica según ESC|PAS consulta≥140 y PAD<90; ≥2 ocasiones validadas|pas_consulta;pad_consulta|CONSULTA|ESC_BP24|G|MMHG
Presión arterial|HTA aislada diastólica|PAS consulta<140 y PAD≥90; ≥2 ocasiones validadas|pas_consulta;pad_consulta|CONSULTA|ESC_BP24|G|MMHG
Presión arterial|PA elevada ACC/AHA|120≤PAS≤129 y PAD<80, promedio de≥2 visitas|pas_consulta;pad_consulta|SEGUIMIENTO|AHA_BP25|G|MMHG
Presión arterial|PA normal ACC/AHA|PAS<120 y PAD<80 promedio válido|pas_consulta;pad_consulta|SEGUIMIENTO|AHA_BP25|G|MMHG
Presión arterial|HTA estadio 1 ACC/AHA persistente|PAS130–139 o PAD80–89; promedio≥2 lecturas≥2 visitas|pas_consulta;pad_consulta|CONSULTA|AHA_BP25|G|MMHG
Presión arterial|HTA estadio 2 ACC/AHA persistente|PAS≥140 o PAD≥90; promedio≥2 lecturas≥2 visitas|pas_consulta;pad_consulta|CONSULTA|AHA_BP25|G|MMHG
Presión arterial|Criterio HTA HBPM|Promedio domiciliario ≥135 PAS o ≥85 PAD en protocolo validado|pas_hbpm;pad_hbpm|CONSULTA|ESC_BP24|G|MMHG
Presión arterial|Criterio HTA ABPM 24h|Promedio 24h ≥130 PAS o ≥80 PAD; ABPM de manguito validado|pas_abpm24;pad_abpm24|CONSULTA|ESC_BP24|G|MMHG
Presión arterial|Criterio HTA nocturna ABPM|Promedio nocturno ≥120 PAS o ≥70 PAD; sueño identificado|pas_abpm_noche;pad_abpm_noche;sueño_segmentado|CONSULTA|ESC_BP24|G|MMHG
Presión arterial|Criterio HTA diurna ABPM|Promedio diurno ≥135 PAS o ≥85 PAD; ABPM validado|pas_abpm_dia;pad_abpm_dia|CONSULTA|ESC_BP24|G|MMHG
Presión arterial|Hipertensión de bata blanca posible|PA consulta≥140/90 y media domiciliaria<135/85 validada|pa_consulta;pa_hbpm|CONSULTA|ESC_BP24|D|DELTA_MMHG
Presión arterial|HTA enmascarada posible|PA consulta<140/90 y media domiciliaria≥135/85 validada|pa_consulta;pa_hbpm|CONSULTA|ESC_BP24|D|DELTA_MMHG
Presión arterial|Sistólica extremadamente elevada|PAS≥180 mmHg en manguito validado, reconfirmar inmediatamente|pas_validada|URGENTE|AHA_BP25|G|MMHG
Presión arterial|Diastólica extremadamente elevada|PAD≥120 mmHg en manguito validado, reconfirmar inmediatamente|pad_validada|URGENTE|AHA_BP25|G|MMHG
Presión arterial|Sistólica baja persistente|PAS≤90 validada en repetición inmediata, nueva o fuera de basal|pas_validada;pas_baseline|URGENTE|NICE_SEPSIS|D|MMHG
Presión arterial|Hipotensión relativa infección|PAS actual >40 mmHg inferior a basal con infección sospechada|pas_validada;pas_baseline;infeccion_sospechada|URGENTE|NICE_SEPSIS|G|DELTA_MMHG
Presión arterial|PA sistólica 91–100 en infección|Infección sospechada y PAS entre 91 y 100 mmHg|pas_validada;infeccion_sospechada|URGENTE|NICE_SEPSIS|G|MMHG
Presión arterial|FC mayor 130 ante infección|Infección sospechada y FC reposo>130, confirmada|fc_reposo;infeccion_sospechada|URGENTE|NICE_SEPSIS|G|BPM
Presión arterial|Caída ortostática sistólica|PAS baja≥20 mmHg en los primeros 3 min de bipedestación validada|pas_supina;pas_de_pie;postura_hora|CONSULTA|ESC_BP24|D|DELTA_MMHG
Presión arterial|Caída ortostática diastólica|PAD baja≥10 mmHg en primeros 3 min tras bipedestación validada|pad_supina;pad_de_pie;postura_hora|CONSULTA|ESC_BP24|D|DELTA_MMHG
Presión arterial|Exceso variabilidad intraindividual|SD de PAS diaria >percentil95 cohorte validada local, sin umbral universal|serie_pas;cohorte_local|SEGUIMIENTO|AHA_BP25|E|SD_MMHG
Presión arterial|Pérdida dipping nocturno|Descenso nocturno relativo PAS<10% (diurna vs nocturna ABPM)|pas_abpm_dia;pas_abpm_noche|CONSULTA|ESC_BP24|D|PORCENTAJE_DESCENSO
Presión arterial|Reverse dipping|PAS media nocturna >PAS media diurna en ABPM validada|pas_abpm_dia;pas_abpm_noche|CONSULTA|ESC_BP24|D|PORCENTAJE_DESCENSO
Presión arterial|Dipping extremo|Descenso PAS nocturna≥20% ABPM; interpretación clínica individual|pas_abpm_dia;pas_abpm_noche|SEGUIMIENTO|ESC_BP24|D|PORCENTAJE_DESCENSO
Presión arterial|HTA + diabetes conocida|Media PA≥130/80 validada y diabetes establecida|pa_validada;diabetes_previa|CONSULTA|AHA_BP25|G|NUM_FACTORES
Presión arterial|HTA + nefropatía|Media PA≥130/80 validada y ERC conocida|pa_validada;erc_previa|CONSULTA|AHA_BP25|G|NUM_FACTORES
Presión arterial|HTA + ictus anterior|Media PA≥130/80 validada e ictus previo|pa_validada;ictus_previo|CONSULTA|AHA_BP25|G|NUM_FACTORES
Presión arterial|HTA + PREVENT≥7.5%|PA media≥130/80 y PREVENT-CVD10≥7.5% correctamente calculado|pa_validada;prevent_10y|CONSULTA|AHA_BP25|G|PROBABILIDAD_10_ANOS
Presión arterial|Hipertensión resistente potencial|HTA persistente y ≥3 antihipertensivos incluyendo diurético documentado|pa_validada;medicacion_hipertension|CONSULTA|AHA_BP25|D|NUM_FARMACOS
Presión arterial|HTA y potasio bajo|HTA validada e hipopotasemia<3.5 mmol/L; considerar hiperaldosteronismo|pa_validada;potasio|CONSULTA|AHA_BP25|D|NUM_FACTORES
Presión arterial|PA elevada nueva respecto basal|ΔPAS media semanal ≥20 mmHg comparando semanas de medición equivalente|pas_semana;pas_baseline|SEGUIMIENTO|AHA_BP25|E|DELTA_MMHG
Ritmo cardiaco|FC reposo elevada persistente|FC>100 lpm en ≥3 segmentos de reposo corroborados|fc_serie;actividad|CONSULTA|ESC_AF|D|BPM
Ritmo cardiaco|FC reposo 120 persistente|FC≥120 lpm en reposo sostenida y confirmada; valorar contexto|fc_reposo;actividad|URGENTE|NICE_SEPSIS|D|BPM
Ritmo cardiaco|FC 130 + sospecha infección|FC>130 lpm y sospecha de infección; criterio NICE alto riesgo|fc_reposo;infeccion_sospechada|URGENTE|NICE_SEPSIS|G|BPM
Ritmo cardiaco|FC nocturna 40–50 basal estable|FC nocturna 40–50 sin nueva desviación; no alertar sola|fc_nocturna;fc_baseline|SEGUIMIENTO|ESC_AF|D|BPM
Ritmo cardiaco|Bradicardia marcada nueva|FC<40 reposo corroborada y no habitual; verificar sensor y perfusión|fc_reposo;fc_baseline|URGENTE|ESC_AF|D|BPM
Ritmo cardiaco|Respuesta febril FC desproporcionada|FC reposo>110 y T≥38 clínica; priorizar evaluación etiológica|fc_reposo;temperatura_clinica|CONSULTA|NICE_SEPSIS|E|NUM_FACTORES
Ritmo cardiaco|FC aumenta frente basal|FC descanso mediana 7d +≥15 lpm respecto 30d, ≥3 días|fc_7d;fc_30d|SEGUIMIENTO|ESC_AF|E|DELTA_BPM
Ritmo cardiaco|FC nocturna aumenta >20%|FC nocturna≥1.2× mediana de 30 noches, ≥3 noches sin fiebre documentada|fc_nocturna;fc_nocturna_baseline|SEGUIMIENTO|ESC_AF|E|PORCENTAJE_CAMBIO
Ritmo cardiaco|Pulso irregular PPG repetido|≥2 avisos PPG de irregularidad con calidad aceptable en 7 días|ppg_eventos;ppg_calidad|CONSULTA|ESC_AF|D|NUM_EVENTOS
Ritmo cardiaco|FA ECG documentada|ECG de episodio interpretado y confirmado como FA por profesional|ecg_interpretado|CONSULTA|ESC_AF|G|CONFIRMACION_ECG
Ritmo cardiaco|FA + CHA2DS2-VA 0|FA ECG confirmada y CHA2DS2-VA=0 en datos completos|fa_confirmada;chads_va_datos|SEGUIMIENTO|ESC_AF|G|PUNTUACION
Ritmo cardiaco|FA + CHA2DS2-VA 1|FA ECG confirmada y CHA2DS2-VA=1 en datos completos|fa_confirmada;chads_va_datos|CONSULTA|ESC_AF|G|PUNTUACION
Ritmo cardiaco|FA + CHA2DS2-VA≥2|FA ECG confirmada y CHA2DS2-VA≥2 en datos completos|fa_confirmada;chads_va_datos|CONSULTA|ESC_AF|G|PUNTUACION
Ritmo cardiaco|ECG con FC auricular irregular|ECG de episodio sugiere FA: exigir valoración profesional para diagnóstico|ecg_onda|CONSULTA|ESC_AF|D|CONFIRMACION_ECG
Ritmo cardiaco|Descenso HRV personal persistente|RMSSD nocturno cae≥30% vs 30 noches durante≥3 noches, sensor comparable|hrv_rmssd_serie;calidad_hrv|SEGUIMIENTO|ESC_AF|E|PORCENTAJE_CAMBIO
Ritmo cardiaco|HRV baja y FC alta|HRV RMSSD ≤0.7× basal y FC nocturna≥1.15× basal≥3 noches|hrv_rmssd;fc_nocturna|SEGUIMIENTO|ESC_AF|E|NUM_FACTORES
Ritmo cardiaco|Pico FC sobre sensor|FC>180 de pulsera sin ECG, exigir verificación no etiquetar TSV|fc_ppg;calidad_ppg|CONSULTA|ESC_AF|D|BPM
Ritmo cardiaco|FC elevada y TSH baja|FC reposo>100 + TSH<0.1 mUI/L confirmado|fc_reposo;tsh|CONSULTA|NICE_TSH|D|NUM_FACTORES
Ritmo cardiaco|FC elevada y anemia|FC reposo>100 + Hb bajo umbral OMS|fc_reposo;hb;sexo_modelo|CONSULTA|WHO_HB24|D|NUM_FACTORES
Ritmo cardiaco|FC elevada y hipoxemia|FC reposo>110 + SpO2<90 clínica repetida|fc_reposo;spo2_clinica|URGENTE|ATS_OXYGEN|D|NUM_FACTORES
Cardiovascular|PREVENT 10 años disponible|30≤edad≤79 sin ECV y todos predictores obligatorios completos|edad;sexo_modelo;pa_validada;colesterol_total;hdl;egfr;diabetes_previa;fuma_actual;medicacion_estatinas;medicacion_hipertension|CRIBADO|AHA_PREVENT|G|PROBABILIDAD_10_ANOS
Cardiovascular|PREVENT no calculable por tabaquismo|Ausencia de fuma_actual aunque todos los demás datos completos|fuma_actual|SEGUIMIENTO|AHA_PREVENT|G|NINGUNA
Cardiovascular|PREVENT no calculable por medicación|Falta uso estatinas y/o antihipertensivos declarado|medicacion_estatinas;medicacion_hipertension|SEGUIMIENTO|AHA_PREVENT|G|NINGUNA
Cardiovascular|PREVENT no aplicable enfermedad previa|Infarto/ictus/PAD previa documentada; pasar prevención secundaria|ecv_previa|CONSULTA|AHA_PREVENT|G|NINGUNA
Cardiovascular|PREVENT fuera de edad|Edad <30 o >79 años: no extrapolar sin validación|edad|SEGUIMIENTO|AHA_PREVENT|G|NINGUNA
Cardiovascular|PREVENT 10y CVD≥7.5% + PA≥130|PREVENT-CVD10≥7.5% y PA promedio≥130/80: discutir tratamiento con clínico|prevent_cvd_10y;pa_validada|CONSULTA|AHA_BP25|G|PROBABILIDAD_10_ANOS
Cardiovascular|SCORE2 no calibrado para México|SCORE2 europeo en población mexicana sin validación regional|pais;poblacion_score|SEGUIMIENTO|ESC_SCORE|G|NINGUNA
Cardiovascular|ECV establecida con LDL alto|Infarto/ictus aterotrombótico/PAD previa y LDL≥70 mg/dL: consultar estrategia individual|ecv_previa;ldl|CONSULTA|ACC_LIP26|D|MG_DL
Cardiovascular|Insuficiencia cardiaca conocida + peso|IC previa y peso+2kg/3d en báscula comparable|ic_previa;peso_serie|CONSULTA|ESC_HF21|D|DELTA_KG
Cardiovascular|IC conocida + frecuencia elevada|IC previa y FC reposo mediana semanal ≥15% sobre basal, ≥3d|ic_previa;fc_baseline;fc_semana|CONSULTA|ESC_HF21|E|PORCENTAJE_CAMBIO
Cardiovascular|IC conocida + presión baja|IC previa y PAS≤90 medida validada y nueva|ic_previa;pas_validada|URGENTE|ESC_HF21|D|MMHG
Cardiovascular|IC conocida + desaturación|IC previa y SpO2 clínica ≤92% repetida diferente basal|ic_previa;spo2_clinica;spo2_baseline|URGENTE|ESC_HF21|D|NUM_FACTORES
Cardiovascular|ABI sospecha PAD|Índice tobillo-brazo≤0.90 en evaluación estandarizada|abi|CONSULTA|ACC_PAD24|G|COCIENTE
Cardiovascular|ABI limítrofe|0.91≤ABI≤0.99; correlacionar con síntomas/antecedentes si existen|abi|CONSULTA|ACC_PAD24|G|COCIENTE
Cardiovascular|ABI normal|1.00≤ABI≤1.40 en contexto clínico apropiado|abi|SEGUIMIENTO|ACC_PAD24|G|COCIENTE
Cardiovascular|ABI no compresible|ABI>1.40: utilizar índice dedo-brazo si PAD sospechada|abi|CONSULTA|ACC_PAD24|G|COCIENTE
Cardiovascular|EAP alto riesgo por diabetes|Diabetes establecida y edad≥65: considerar evaluación arterial si hallazgos o riesgo|diabetes_previa;edad|CRIBADO|ACC_PAD24|D|NUM_FACTORES
Cardiovascular|EAP alto riesgo con tabaquismo|Edad≥50 + tabaquismo actual o antecedente; si hay dato|edad;fuma_actual|CRIBADO|ACC_PAD24|D|NUM_FACTORES
Cardiovascular|Pérdida pulmonar y cardiovascular combinada|SpO2↓≥4pp vs basal + FC↑≥20% vs basal en reposo,≥10 min|spo2_baseline;spo2;fc_baseline;fc|URGENTE|ATS_OXYGEN|E|NUM_FACTORES
Glucosa|Hipoglucemia CGM nivel 1|54≤CGM<70 mg/dL por≥15 min y señal válida|cgm;calidad_cgm|CONSULTA|ADA_GLY26|D|MINUTOS_BAJO_RANGO
Glucosa|Hipoglucemia CGM nivel 2|CGM<54 mg/dL y señal válida: comprobar glucemia capilar si factible sin retrasar atención|cgm;calidad_cgm|URGENTE|ADA_GLY26|G|MINUTOS_BAJO_RANGO
Glucosa|Hipoglucemia nivel 3 clínica|Ayuda de tercera persona por alteración física/mental atribuible a hipoglucemia, independiente del valor|evento_ayuda_tercero;hipoglucemia_clinica|CRITICA|ADA_GLY26|G|NUM_EVENTOS
Glucosa|TBR bajo 70 elevado|Diabetes con CGM 14d≥70% cobertura y TBR<70≥4%|diabetes_previa;cgm_14d;cgm_cobertura|CONSULTA|ADA_GLY26|G|PORCENTAJE_TIEMPO
Glucosa|TBR bajo 54 elevado|Diabetes con CGM 14d≥70% cobertura y TBR<54≥1%|diabetes_previa;cgm_14d;cgm_cobertura|CONSULTA|ADA_GLY26|G|PORCENTAJE_TIEMPO
Glucosa|TIR 70–180 bajo|Diabetes no embarazada; CGM 14d cobertura≥70% y tiempo 70–180≤70%|diabetes_previa;embarazo_estado;cgm_14d;cgm_cobertura|CONSULTA|ADA_GLY26|G|PORCENTAJE_TIEMPO
Glucosa|TAR 181–250 elevado|Diabetes no embarazada; >25% tiempo CGM entre 181 y 250 mg/dL|diabetes_previa;cgm_14d;cgm_cobertura|CONSULTA|ADA_GLY24|G|PORCENTAJE_TIEMPO
Glucosa|TAR>250 elevado|Diabetes no embarazada; >5% tiempo CGM>250 mg/dL|diabetes_previa;cgm_14d;cgm_cobertura|CONSULTA|ADA_GLY24|G|PORCENTAJE_TIEMPO
Glucosa|Variabilidad CGM elevada|Diabetes; coeficiente de variación glucosa >36% en 14d válidos|diabetes_previa;cgm_14d;cgm_cobertura|CONSULTA|ADA_GLY24|G|COEF_VARIACION
Glucosa|Prediabetes A1c tramo inferior|HbA1c laboratorio 5.7–5.9% en no embarazadas|hba1c;embarazo_estado|CONSULTA|ADA_DX26|D|PORCENTAJE_A1C
Glucosa|Prediabetes A1c tramo intermedio|HbA1c laboratorio 6.0–6.2% en no embarazadas|hba1c;embarazo_estado|CONSULTA|ADA_DX26|D|PORCENTAJE_A1C
Glucosa|Prediabetes A1c tramo superior|HbA1c laboratorio 6.3–6.4% en no embarazadas|hba1c;embarazo_estado|CONSULTA|ADA_DX26|D|PORCENTAJE_A1C
Glucosa|Diabetes A1c criterio laboratorio|HbA1c laboratorio ≥6.5% y no embarazo; repetir si no hay hiperglucemia inequívoca|hba1c;embarazo_estado|CONSULTA|ADA_DX26|G|PORCENTAJE_A1C
Glucosa|Diabetes glucosa ayuno criterio|Plasma en ayuno ≥126 mg/dL, ≥8h y no embarazo; confirmación según ADA|glucosa_plasmatica_ayuno;ayuno_horas;embarazo_estado|CONSULTA|ADA_DX26|G|MG_DL
Glucosa|Prediabetes glucosa ayuno|100≤glucosa plasmática ayuno≤125 mg/dL; ≥8h no embarazada|glucosa_plasmatica_ayuno;ayuno_horas;embarazo_estado|CONSULTA|ADA_DX26|G|MG_DL
Glucosa|Intolerancia glucosa OGTT|OGTT 75g a 2h 140–199 mg/dL, plasma, no embarazo|ogtt_2h;embarazo_estado|CONSULTA|ADA_DX26|G|MG_DL
Glucosa|Criterio diabetes OGTT|OGTT 75g a 2h ≥200 mg/dL, plasma, no embarazo|ogtt_2h;embarazo_estado|CONSULTA|ADA_DX26|G|MG_DL
Glucosa|Diabetes al azar con síntomas|Glucosa plasmática aleatoria≥200 mg/dL + síntomas clásicos|glucosa_plasmatica_azar;sintomas_hiperglucemia|CONSULTA|ADA_DX26|G|MG_DL
Glucosa|Diabetes al azar sin síntomas|Glucosa plasmática aleatoria≥200 sin síntomas reportados; solicitar confirmación|glucosa_plasmatica_azar;sintomas_hiperglucemia|CONSULTA|ADA_DX26|D|MG_DL
Glucosa|A1c 6.5 confirmada dos veces|≥2 pruebas HbA1c laboratorio ≥6.5% en fechas distintas, sin interferencia significativa|hba1c_historial;embarazo_estado|CONSULTA|ADA_DX26|G|NUM_PRUEBAS
Glucosa|Discordancia A1c vs plasma|HbA1c por encima umbral diagnóstico y glucosa plasmática no concordante|hba1c;glucosa_plasmatica_ayuno|CONSULTA|ADA_DX26|D|NINGUNA
Glucosa|Hiperglucemia CGM sostenida no diagnóstica|CGM>180 mg/dL más de 25% de 14 días en no diagnosticado|cgm_14d;diabetes_previa|CRIBADO|ADA_DX26|E|PORCENTAJE_TIEMPO
Glucosa|Hiperglucemia CGM matutina no diagnóstica|Mediana CGM 06:00–09:00 >125 mg/dL ≥7 de 14 días en no diagnosticado|cgm_14d;diabetes_previa|CRIBADO|ADA_DX26|E|MG_DL
Glucosa|Glucosa nocturna baja recurrente|CGM <70 mg/dL durante≥15 min ≥3 noches/14, corroborar compresión|cgm_14d;cgm_calidad|CONSULTA|ADA_GLY26|E|NUM_EPISODIOS
Glucosa|Hipoglucemia repetida en diabetes|CGM <54 mg/dL ≥2 episodios/14d con señal validada|cgm_14d;diabetes_previa|CONSULTA|ADA_GLY26|D|NUM_EPISODIOS
Glucosa|Hiperglucemia con pérdida de peso|Glucosa plasmática ayuno≥126 y caída peso no intencional≥5%/6meses|glucosa_plasmatica_ayuno;peso_historial|CONSULTA|ADA_DX26|D|NUM_FACTORES
Glucosa|Hiperglucemia + eGFR bajo|Diabetes conocida + HbA1c fuera de objetivo individual + eGFR<60|diabetes_previa;hba1c;egfr|CONSULTA|KDIGO24|D|NUM_FACTORES
Glucosa|Hiperglucemia + albuminuria A2|Diabetes conocida + ACR urinario 30–300 mg/g persistente|diabetes_previa;acr_orina;acr_historial|CONSULTA|KDIGO24|G|MG_G
Glucosa|Hiperglucemia + albuminuria A3|Diabetes conocida + ACR urinario >300 mg/g persistente|diabetes_previa;acr_orina;acr_historial|CONSULTA|KDIGO24|G|MG_G
Glucosa|Control CGM especialmente conservador anciano|Edad≥65 diabetes y TBR<70 ≥1% (objetivos adaptables)|edad;diabetes_previa;cgm_14d|CONSULTA|ADA_GLY26|G|PORCENTAJE_TIEMPO
Glucosa|Tiempo CGM 14 días insuficiente|CGM activo <70% o menos de 14 días para perfil de patrón|cgm_serie;cgm_cobertura|SEGUIMIENTO|ISPAD_CGM24|G|PORCENTAJE_COBERTURA
Glucosa|GMI discrepante con A1c|Distancia absoluta GMI−HbA1c ≥0.5pp en control; verificar causas|gmi;hba1c|SEGUIMIENTO|ADA_GLY24|E|DELTA_PP
Glucosa|Diabetes previa y severa hipoglucemia histórica|Diabetes + antecedente nivel 3 requiere revisión plan aunque TIR actual adecuado|diabetes_previa;hipoglucemia_severa_previa|CONSULTA|ADA_GLY26|D|NUM_EVENTOS
Glucosa|Diabetes previa con enfermedad CV|Diabetes + ECV establecida: prevención secundaria cardiometabólica|diabetes_previa;ecv_previa|CONSULTA|ACC_LIP26|D|NUM_FACTORES
Glucosa|Diabetes con HbA1c >9|Diabetes conocida + HbA1c>9%: tratamiento y causas a revisar clínicamente|diabetes_previa;hba1c|CONSULTA|ADA_GLY26|D|PORCENTAJE_A1C
Glucosa|Prediabetes recurrente a 12 meses|HbA1c 5.7–6.4% en al menos dos mediciones separadas≥12 meses|hba1c_historial|CONSULTA|ADA_DX26|D|NUM_PRUEBAS
Lípidos|LDL colesterol muy alto|LDL-C ≥190 mg/dL en muestra validada; evaluar hipercolesterolemia familiar|ldl|CONSULTA|ACC_LIP26|G|MG_DL
Lípidos|LDL alto con diabetes|Diabetes establecida + LDL≥100 mg/dL; valorar plan por riesgo individual|ldl;diabetes_previa|CONSULTA|ACC_LIP26|D|NUM_FACTORES
Lípidos|LDL alto con ECV aterosclerótica previa|ECV documentada + LDL≥70 mg/dL; revisar objetivo aplicable|ldl;ecv_previa|CONSULTA|ACC_LIP26|D|MG_DL
Lípidos|Triglicéridos 150-499|TG 150–499 mg/dL persistentes en adulto|trigliceridos|CONSULTA|ACC_LIP26|G|MG_DL
Lípidos|Triglicéridos 500-999|TG 500–999 mg/dL: riesgo de pancreatitis aumenta|trigliceridos|CONSULTA|ACC_LIP26|G|MG_DL
Lípidos|Triglicéridos ≥1000|TG≥1000 mg/dL; evaluación pronta por riesgo importante pancreatitis|trigliceridos|URGENTE|ACC_LIP26|G|MG_DL
Lípidos|Colesterol no HDL derivable|No-HDL = colesterol total − HDL; reportar continuo|colesterol_total;hdl|SEGUIMIENTO|ACC_LIP26|G|MG_DL
Lípidos|No-HDL y TG elevados|TG≥150 y no-HDL elevado según objetivo individual calculado|trigliceridos;colesterol_no_hdl;objetivo_no_hdl|CONSULTA|ACC_LIP26|D|MG_DL
Lípidos|ApoB elevado en contexto TG alto|TG≥150 y apoB sobre objetivo individual establecido|trigliceridos;apoB;objetivo_apoB|CONSULTA|ACC_LIP26|D|MG_DL
Lípidos|TG alto con A1c diagnóstica|TG≥500 y HbA1c≥6.5%, sin confirmación de ambos no atribuir causa|trigliceridos;hba1c|CONSULTA|ACC_LIP26|D|NUM_FACTORES
Lípidos|TG alto con TSH elevada|TG≥150 y TSH superior referencia: investigar causa secundaria|trigliceridos;tsh|CONSULTA|ACC_LIP26|D|NUM_FACTORES
Lípidos|TG alto con ERC|TG≥150 y ERC conocida: seguimiento cardiovascular y renal|trigliceridos;erc_previa|CONSULTA|ACC_LIP26|D|NUM_FACTORES
Lípidos|Dislipidemia mixta|TG≥150 + LDL elevado según laboratorio/objetivo clínico|trigliceridos;ldl;objetivo_ldl|CONSULTA|ACC_LIP26|D|NUM_FACTORES
Lípidos|Perfil lipídico discordante|LDL calculado por Friedewald con TG≥400, solicitar método apropiado|trigliceridos;ldl_metodo|SEGUIMIENTO|ACC_LIP26|D|NINGUNA
Lípidos|LDL <55 para ECV alto riesgo|ECV muy alto riesgo y LDL≥55 según manejo intensivo individual|ldl;ecv_previa;estrato_riesgo|CONSULTA|ACC_LIP26|D|MG_DL
Lípidos|Cambio LDL a 3 meses|LDL aumenta ≥20% frente análisis comparables, verificar adherencia/causas|ldl_historial|SEGUIMIENTO|ACC_LIP26|E|PORCENTAJE_CAMBIO
Lípidos|Lipoproteína(a) alta|Lp(a)≥125 nmol/L o ≥50 mg/dL, no convertir unidades con factor fijo|lp_a;unidad_lp_a|CONSULTA|ACC_LIP26|D|UNIDAD_SEGUN_METODO
Lípidos|ApoB 130 y contexto|ApoB≥130 mg/dL en laboratorio confiable, valorar modificador riesgo|apoB|CONSULTA|ACC_LIP26|D|MG_DL
Lípidos|Elevación TG aislada transitoria|TG≥150 durante enfermedad aguda: repetir al recuperarse|trigliceridos;enfermedad_aguda|SEGUIMIENTO|ACC_LIP26|G|MG_DL
Lípidos|Dislipidemia sin perfil completo|Sólo colesterol total disponible: no calcular PREVENT ni LDL derivado|colesterol_total;hdl|SEGUIMIENTO|AHA_PREVENT|G|NINGUNA
Riñón|ERC G1 si daño persistente|eGFR≥90 y ACR≥30 persistente≥3 meses: ERC con daño renal|egfr;acr_orina;acr_historial|CONSULTA|KDIGO24|G|CGACAT
Riñón|ERC G2 si daño persistente|60≤eGFR<90 y ACR≥30 persistente≥3 meses|egfr;acr_orina;acr_historial|CONSULTA|KDIGO24|G|CGACAT
Riñón|ERC G3a potencial|45≤eGFR<60 persistente≥3 meses; investigar daño renal y causa|egfr_historial|CONSULTA|KDIGO24|G|CGACAT
Riñón|ERC G3b potencial|30≤eGFR<45 persistente≥3 meses|egfr_historial|CONSULTA|KDIGO24|G|CGACAT
Riñón|ERC G4 potencial|15≤eGFR<30 persistente≥3 meses|egfr_historial|CONSULTA|KDIGO24|G|CGACAT
Riñón|ERC G5 potencial|eGFR<15 persistente o alteración grave actual; atención especializada|egfr_historial|URGENTE|KDIGO24|G|CGACAT
Riñón|Albuminuria A1|ACR<30 mg/g, reportar categoría sin deducir ausencia ERC|acr_orina|SEGUIMIENTO|KDIGO24|G|CGACAT
Riñón|Albuminuria A2|30≤ACR≤300 mg/g, confirmar persistencia según contexto|acr_orina|CONSULTA|KDIGO24|G|CGACAT
Riñón|Albuminuria A3|ACR>300 mg/g, confirmar y derivar según riesgo|acr_orina|CONSULTA|KDIGO24|G|CGACAT
Riñón|eGFR cambia >20%|En ERC establecida eGFR varía >20% entre pruebas comparables|erc_previa;egfr_historial|CONSULTA|KDIGO24|G|PORCENTAJE_CAMBIO
Riñón|ACR se duplica|En ERC ACR urinario ≥2× valor anterior comparable|erc_previa;acr_historial|CONSULTA|KDIGO24|G|COCIENTE
Riñón|Descenso post fármaco >30%|Terapia hemodinámicamente activa iniciada y eGFR disminuye>30%|egfr_historial;medicacion_renal_fecha|CONSULTA|KDIGO24|G|PORCENTAJE_CAMBIO
Riñón|AKI por 0.3 mg/dL|Creatinina sérica aumenta≥0.3 mg/dL dentro de 48h|creatinina_historial|URGENTE|NICE_AKI|G|DELTA_MG_DL
Riñón|AKI por 1.5× creatinina|Creatinina sérica≥1.5× basal en ≤7d|creatinina_historial|URGENTE|NICE_AKI|G|COCIENTE
Riñón|AKI estadio2 por creatinina|Creatinina 2.0–2.9× basal dentro de 7 días|creatinina_historial|URGENTE|NICE_AKI|G|COCIENTE
Riñón|AKI estadio3 por creatinina|Creatinina≥3× basal o ≥4 mg/dL con incremento agudo según criterios|creatinina_historial|CRITICA|NICE_AKI|G|COCIENTE
Riñón|Oliguria AKI por diuresis|Volumen urinario<0.5 mL/kg/h durante>6h, dato opcional|diuresis_horas;peso_kg|URGENTE|NICE_AKI|G|ML_KG_H
Riñón|KFRE 2y calculable|ERC G3–G5 confirmada + edad/sexo/eGFR/ACR completos, modelo regional explícito|edad;sexo_modelo;egfr;acr_orina;erc_previa|CONSULTA|KFRE_TANGRI16|G|PROBABILIDAD_2_ANOS
Riñón|KFRE 5y calculable|ERC G3–G5 confirmada + edad/sexo/eGFR/ACR completos, modelo regional explícito|edad;sexo_modelo;egfr;acr_orina;erc_previa|CONSULTA|KFRE_TANGRI16|G|PROBABILIDAD_5_ANOS
Riñón|KFRE 5y ≥3%|KFRE 5 años≥3%: valorar derivación a nefrología según criterios KDIGO|kfre_5y|CONSULTA|KDIGO24|G|PROBABILIDAD_5_ANOS
Riñón|KFRE 5y ≥5%|KFRE 5 años≥5%: reforzar consideración de derivación|kfre_5y|CONSULTA|KDIGO24|G|PROBABILIDAD_5_ANOS
Riñón|KFRE 2y >10%|KFRE 2 años>10%: considerar equipo multidisciplinario|kfre_2y|CONSULTA|KDIGO24|G|PROBABILIDAD_2_ANOS
Riñón|KFRE 2y >40%|KFRE 2 años>40%: planificar preparación terapia sustitutiva renal|kfre_2y|CONSULTA|KDIGO24|G|PROBABILIDAD_2_ANOS
Riñón|KFRE inaplicable sin ERC G3–G5|eGFR≥60 o ERC G3–5 no confirmada: no usar KFRE estándar|egfr;erc_previa|SEGUIMIENTO|KDIGO24|G|NINGUNA
Riñón|Creatinina elevada descontextualizada|Creatinina fuera rango local sin tendencia: no concluir ERC|creatinina;edad;sexo_modelo|CONSULTA|NIDDK_EGFR|D|MG_DL
Riñón|CKD-EPI 2021 requiere sexo fórmula|Edad≥18, creatinina estandarizada y coeficiente sexo adecuado|edad;creatinina;sexo_modelo|SEGUIMIENTO|NIDDK_EGFR|G|ML_MIN_173
Riñón|Bicarbonato bajo en ERC|ERC conocida + bicarbonato plasmático<18 mmol/L|erc_previa;bicarbonato|CONSULTA|KDIGO24|G|MMOL_L
Riñón|ERC más hiperpotasemia moderada|ERC + K 6.0–6.4 mmol/L confirmado no hemolizado|erc_previa;potasio|URGENTE|UKKA_K26|G|MMOL_L
Riñón|ERC más hiperpotasemia grave|ERC + K≥6.5 mmol/L confirmado no hemolizado|erc_previa;potasio|CRITICA|UKKA_K26|G|MMOL_L
Riñón|Diabetes más albuminuria|Diabetes establecida y ACR≥30 mg/g persistente|diabetes_previa;acr_historial|CONSULTA|KDIGO24|G|MG_G
Riñón|HTA más albuminuria|HTA establecida y ACR≥30 mg/g persistente|hipertension_confirmada;acr_historial|CONSULTA|KDIGO24|D|MG_G
Riñón|Control renal por ERC sin analíticas|Antecedente ERC y sin eGFR/ACR en≥12 meses: recomendar pruebas|erc_previa;fecha_egfr;fecha_acr|CRIBADO|KDIGO24|G|MESES
Hígado|FIB-4 bajo riesgo adulto 35–64|Edad35–64, FIB-4<1.3 en contexto MASLD aplicable|edad;ast;alt;plaquetas|SEGUIMIENTO|AASLD_FIB4|G|PUNTUACION
Hígado|FIB-4 indeterminado adulto 35–64|Edad35–64, 1.3≤FIB-4≤2.67 en contexto MASLD|edad;ast;alt;plaquetas|CONSULTA|AASLD_FIB4|G|PUNTUACION
Hígado|FIB-4 alto adulto 35–64|Edad35–64, FIB-4>2.67 en contexto MASLD|edad;ast;alt;plaquetas|CONSULTA|AASLD_FIB4|G|PUNTUACION
Hígado|FIB-4 edad≥65 bajo 2.0|Edad≥65, FIB-4<2.0: límite ajustado baja probabilidad|edad;ast;alt;plaquetas|SEGUIMIENTO|AASLD_FIB4|G|PUNTUACION
Hígado|FIB-4 edad≥65 supera 2.0|Edad≥65, FIB-4≥2.0, considerar pruebas secundarias|edad;ast;alt;plaquetas|CONSULTA|AASLD_FIB4|G|PUNTUACION
Hígado|FIB-4 no aplicable en <35|Edad<35: FIB-4 no es confiable para estratificación habitual|edad;ast;alt;plaquetas|SEGUIMIENTO|AASLD_FIB4|G|NINGUNA
Hígado|FIB-4 en agudización no válido|Enfermedad aguda con AST/ALT alteradas, diferir cálculo MASLD|ast;alt;enfermedad_aguda|SEGUIMIENTO|AASLD_FIB4|G|NINGUNA
Hígado|MASLD riesgo metabólico sin laboratorio|Obesidad+diabetes; recomendar valoración hepática sin inferir fibrosis|imc;diabetes_previa|CRIBADO|AASLD_FIB4|D|NUM_FACTORES
Hígado|AST/ALT >2x límite local|AST o ALT >2× límite superior de referencia ajustado al laboratorio|ast;alt;limites_lab|CONSULTA|AASLD_FIB4|D|RELACION_ULN
Hígado|AST/ALT >5x límite local|AST o ALT >5× límite superior de referencia local|ast;alt;limites_lab|URGENTE|AASLD_FIB4|D|RELACION_ULN
Hígado|AST/ALT >10x límite local|AST o ALT >10× límite superior de referencia; pronta valoración etiológica|ast;alt;limites_lab|URGENTE|AASLD_FIB4|D|RELACION_ULN
Hígado|Bilirrubina elevada y enzimas|Bilirrubina total elevada y ALT/AST fuera de referencia; no establecer etiología|bilirrubina;ast;alt;limites_lab|CONSULTA|AASLD_FIB4|D|NUM_FACTORES
Hígado|Albúmina baja más INR alto|Albúmina baja y INR elevado en paciente con hepatopatía conocida|albumina;inr;hepatopatia_previa|URGENTE|AASLD_FIB4|D|NUM_FACTORES
Hígado|Plaquetopenia más FIB-4 alto|Plaquetas<150×10⁹/L + FIB-4>2.67 en persona elegible|plaquetas;fib4|CONSULTA|AASLD_FIB4|D|NUM_FACTORES
Hígado|Hepatopatía crónica sin vigilancia|Hepatopatía conocida y sin analítica hepática reciente|hepatopatia_previa;fecha_funcion_hepatica|CRIBADO|AASLD_FIB4|D|MESES
Hígado|Obesidad con ALT persistente|IMC≥30 + ALT sobre referencia en dos pruebas separadas≥3 meses|imc;alt_historial|CONSULTA|AASLD_FIB4|D|NUM_FACTORES
Hígado|Diabetes + FIB4≥1.3|Diabetes establecida y FIB4≥1.3 edad35–64: priorizar elastografía|diabetes_previa;fib4;edad|CONSULTA|AASLD_FIB4|G|PUNTUACION
Hígado|Diabetes + FIB4 baja repetir|Diabetes establecida y FIB4 baja: reevaluar cada 1–2 años si riesgo lo justifica|diabetes_previa;fib4;fecha_fib4|SEGUIMIENTO|AASLD_FIB4|G|MESES
Hígado|Divergencia plaquetas y AST|FIB4 cambia≥50% en 12 meses por cambio AST/ALT/plaquetas; revisar causas|fib4_historial|CONSULTA|AASLD_FIB4|E|PORCENTAJE_CAMBIO
Hígado|FIB4 no diagnóstico cirrosis|FIB4 elevado sin elastografía/biopsia no permite rotular cirrosis|fib4|SEGUIMIENTO|AASLD_FIB4|G|NINGUNA
Hematología|Anemia OMS mujer no embarazada|Mujer adulta no embarazada con Hb<12.0 g/dL|hb;sexo_modelo;embarazo_estado|CONSULTA|WHO_HB24|G|G_DL
Hematología|Anemia OMS varón|Varón adulto con Hb<13.0 g/dL|hb;sexo_modelo|CONSULTA|WHO_HB24|G|G_DL
Hematología|Anemia leve mujer OMS|Mujer 15-65 no gestante Hb 11.0–11.9 g/dL|hb;sexo_modelo;edad;embarazo_estado|CONSULTA|WHO_HB24|G|G_DL
Hematología|Anemia leve varón OMS|Varón 15-65 Hb 11.0–12.9 g/dL|hb;sexo_modelo;edad|CONSULTA|WHO_HB24|G|G_DL
Hematología|Anemia moderada OMS adultos|Hb 8.0–10.9 g/dL en 15–65 años no gestante|hb;edad;embarazo_estado|CONSULTA|WHO_HB24|G|G_DL
Hematología|Anemia grave OMS adultos|Hb<8.0 g/dL en 15–65 años no gestante; valorar urgencia clínica|hb;edad;embarazo_estado|URGENTE|WHO_HB24|G|G_DL
Hematología|Anemia embarazo 1T|Gestante primer trimestre Hb<11.0 g/dL|hb;embarazo_estado;trimestre|CONSULTA|WHO_HB24|G|G_DL
Hematología|Anemia embarazo 2T|Gestante segundo trimestre Hb<10.5 g/dL|hb;embarazo_estado;trimestre|CONSULTA|WHO_HB24|G|G_DL
Hematología|Anemia embarazo 3T|Gestante tercer trimestre Hb<11.0 g/dL|hb;embarazo_estado;trimestre|CONSULTA|WHO_HB24|G|G_DL
Hematología|Ferritina menor de 45 con anemia|Hb bajo umbral OMS y ferritina<45 ng/mL|hb;ferritina;sexo_modelo|CONSULTA|AGA_IRON20|G|NG_ML
Hematología|Ferritina <15 probable ferropenia|Ferritina<15 ng/mL, con o sin anemia; revisar inflamación|ferritina|CONSULTA|AGA_IRON20|D|NG_ML
Hematología|Anemia y sangrado GI potencial|Varón/posmenopáusica con anemia ferropénica confirmada|hb;ferritina;sexo_modelo;menopausia_estado|CONSULTA|AGA_IRON20|G|NUM_FACTORES
Hematología|Anemia con MCV bajo|Hb baja + VCM<80 fL: microcitosis, investigar hierro/hemoglobinopatías|hb;vcm|CONSULTA|AGA_IRON20|D|FL
Hematología|Anemia con MCV alto|Hb baja + VCM>100 fL: macrocitosis, investigar B12/folato/causas|hb;vcm|CONSULTA|NICE_B12_24|D|FL
Hematología|Macrocitosis con B12 baja|VCM>100 y B12 total<180 ng/L, según laboratorio|vcm;b12_total|CONSULTA|NICE_B12_24|D|NUM_FACTORES
Hematología|B12 muy probablemente baja|B12 total<180 ng/L en laboratorio, sin interferencias relevantes|b12_total|CONSULTA|NICE_B12_24|G|NG_L
Hematología|B12 indeterminada|B12 total 180–350 ng/L: solicitar MMA si indicado|b12_total|CONSULTA|NICE_B12_24|G|NG_L
Hematología|B12 menos probable|B12 total>350 ng/L: deficiencia menos probable, no excluye todos casos|b12_total|SEGUIMIENTO|NICE_B12_24|G|NG_L
Hematología|Pancitopenia|Hb bajo, plaquetas bajas y neutrófilos bajos según límites laboratorio|hb;plaquetas;neutrofilos;limites_lab|URGENTE|WHO_HB24|D|NUM_SERIES
Hematología|Bicitopenia|Dos de tres series sanguíneas fuera de rango en hemograma confirmado|hb;plaquetas;neutrofilos;limites_lab|CONSULTA|WHO_HB24|D|NUM_SERIES
Hematología|Leucocitos elevados|Leucocitos>11×10⁹/L en adulto, verificar rango local/causa|leucocitos|CONSULTA|IDSA_FN|D|X10E9_L
Hematología|Leucocitos bajos|Leucocitos<4×10⁹/L, verificar rango local/causa|leucocitos|CONSULTA|IDSA_FN|D|X10E9_L
Hematología|Neutropenia|Recuento absoluto neutrófilos <1.5×10⁹/L|neutrofilos|CONSULTA|IDSA_FN|D|X10E9_L
Hematología|Neutropenia grave|Recuento absoluto neutrófilos <0.5×10⁹/L|neutrofilos|URGENTE|IDSA_FN|G|X10E9_L
Hematología|Fiebre neutropénica|T≥38.3 una vez o ≥38.0 sostenida1h + ANC<0.5 o se prevé caída|temperatura_clinica;neutrofilos|CRITICA|IDSA_FN|G|NUM_FACTORES
Hematología|Trombocitopenia|Plaquetas <150×10⁹/L confirmadas; investigar etiología|plaquetas|CONSULTA|AABB_PLT25|D|X10E9_L
Hematología|Trombocitopenia severa|Plaquetas <50×10⁹/L confirmado; riesgo hemorragia depende de contexto|plaquetas|URGENTE|AABB_PLT25|D|X10E9_L
Hematología|Plaquetas muy bajas|Plaquetas <20×10⁹/L confirmadas: evaluación rápida|plaquetas|URGENTE|AABB_PLT25|D|X10E9_L
Hematología|Plaquetas críticas|Plaquetas <10×10⁹/L confirmadas: evaluación urgente|plaquetas|CRITICA|AABB_PLT25|D|X10E9_L
Hematología|Plaquetas altas persistentes|Plaquetas>450×10⁹/L persistentes en dos hemogramas|plaquetas_historial|CONSULTA|AABB_PLT25|D|X10E9_L
Hematología|Hemoglobina cae rápidamente|Hb cae ≥2 g/dL en ≤7d y muestras comparables|hb_historial|URGENTE|WHO_HB24|D|DELTA_G_DL
Hematología|Hb elevada por encima referencia|Hb > límite superior laboratorio ajustado por sexo/altura/estado|hb;sexo_modelo;altitud_m;limites_lab|CONSULTA|WHO_HB24|D|G_DL
Hematología|Anemia con taquicardia|Hb por debajo criterio OMS y FC reposo>100 lpm|hb;fc_reposo;sexo_modelo|CONSULTA|WHO_HB24|D|NUM_FACTORES
Hematología|Anemia con desaturación|Hb baja y SpO2 baja verificada: investigar factores independientes|hb;spo2_clinica|URGENTE|WHO_HB24|E|NUM_FACTORES
Hematología|B12 baja con neurosecuela|B12 total <180 ng/L con neuropatía registrada requiere evaluación pronta|b12_total;neuropatia_previa|CONSULTA|NICE_B12_24|G|NUM_FACTORES
Electrolitos|Hiperpotasemia leve|Potasio sérico 5.5–5.9 mmol/L no hemolizado|potasio;indice_hemolisis|CONSULTA|UKKA_K26|G|MMOL_L
Electrolitos|Hiperpotasemia moderada|Potasio 6.0–6.4 mmol/L no hemolizado, evaluación pronta|potasio;indice_hemolisis|URGENTE|UKKA_K26|G|MMOL_L
Electrolitos|Hiperpotasemia grave|Potasio ≥6.5 mmol/L no hemolizado, valoración hospitalaria urgente|potasio;indice_hemolisis|CRITICA|UKKA_K26|G|MMOL_L
Electrolitos|Potasiemia elevada y bradicardia|K≥6.0 no hemolizado + FC<50 nueva; ECG urgente|potasio;fc_reposo|CRITICA|UKKA_K26|D|NUM_FACTORES
Electrolitos|Potasiemia elevada con ERC|K≥5.5 y ERC conocida; ampliar evaluación y medicación|potasio;erc_previa|CONSULTA|UKKA_K26|G|NUM_FACTORES
Electrolitos|Potasio bajo|K<3.5 mmol/L no hemolizado; investigar causas|potasio|CONSULTA|UKKA_K26|D|MMOL_L
Electrolitos|Hipopotasemia moderada|K 2.5–2.9 mmol/L confirmado; evaluación pronta|potasio|URGENTE|UKKA_K26|D|MMOL_L
Electrolitos|Hipopotasemia grave|K<2.5 mmol/L: evaluación urgente y ECG|potasio|CRITICA|UKKA_K26|D|MMOL_L
Electrolitos|Hipopotasemia y taquicardia|K<3.0 y FC>100 reposo; verificar ritmo ECG|potasio;fc_reposo|URGENTE|UKKA_K26|D|NUM_FACTORES
Electrolitos|Hiponatremia|Na sérico<135 mmol/L, repetir/causa y revisar tonicidad|sodio|CONSULTA|ENDO_NA|G|MMOL_L
Electrolitos|Hiponatremia moderada|Na 125–129 mmol/L; revisión pronta según clínica|sodio|CONSULTA|ENDO_NA|G|MMOL_L
Electrolitos|Hiponatremia profunda|Na<125 mmol/L confirmado; evaluación urgente especialmente si aguda|sodio|URGENTE|ENDO_NA|G|MMOL_L
Electrolitos|Hipernatremia|Na>145 mmol/L; evaluar balance hídrico y causa|sodio|CONSULTA|ENDO_NA|D|MMOL_L
Electrolitos|Hipernatremia importante|Na≥160 mmol/L confirmado, evaluación urgente|sodio|CRITICA|ENDO_NA|D|MMOL_L
Electrolitos|Na corregido por hiperglucemia|Na medido bajo + glucosa plasmática elevada; calcular Na corregido con método especificado|sodio;glucosa_plasmatica_azar|SEGUIMIENTO|ENDO_NA|D|MMOL_L
Electrolitos|Calcio corregido no confiable|Albúmina baja y calcio total anormal; preferir calcio ionizado cuando proceda|calcio_total;albumina|CONSULTA|KDIGO24|D|NINGUNA
Electrolitos|Calcio ionizado bajo|Calcio ionizado debajo de referencia de laboratorio validada|calcio_ionizado;limites_lab|CONSULTA|KDIGO24|D|MMOL_L
Electrolitos|Calcio ionizado alto|Calcio ionizado sobre referencia del laboratorio validada|calcio_ionizado;limites_lab|CONSULTA|KDIGO24|D|MMOL_L
Electrolitos|Magnesio bajo|Mg por debajo del límite de referencia local, especialmente con K bajo|magnesio;limites_lab|CONSULTA|KDIGO24|D|MMOL_L
Electrolitos|Fósforo elevado/ERC|Fosfato sobre referencia y eGFR<60 persistente|fosfato;egfr_historial|CONSULTA|KDIGO24|D|NUM_FACTORES
Electrolitos|Bicarbonato <18 en ERC|ERC y HCO3<18 mmol/L; valorar acidosis metabólica|erc_previa;bicarbonato|CONSULTA|KDIGO24|G|MMOL_L
Electrolitos|Albúmina plasmática baja|Albúmina sérica por debajo límite laboratorio; causa multifactorial|albumina;limites_lab|CONSULTA|KDIGO24|D|G_DL
Electrolitos|Vitamina D deficiente según lab|25-OH vitamina D por debajo referencia clínica seleccionada; no umbral universal|vitamina_d;limites_lab|CONSULTA|KDIGO24|D|NG_ML
Electrolitos|Potasio no evaluable por hemólisis|K alto + índice de hemólisis incompatible, solicitar repetición apropiada|potasio;indice_hemolisis|SEGUIMIENTO|UKKA_K26|G|NINGUNA
Tiroides|TSH alta FT4 baja|TSH sobre referencia + FT4 por debajo del límite, patrón de hipotiroidismo primario|tsh;ft4;limites_lab|CONSULTA|NICE_TSH|G|NUM_FACTORES
Tiroides|TSH baja FT4 alta|TSH baja + FT4 sobre rango; patrón tirotoxicosis|tsh;ft4;limites_lab|CONSULTA|NICE_TSH|G|NUM_FACTORES
Tiroides|TSH alta FT4 normal|TSH alta + FT4 normal: patrón hipotiroidea subclínico|tsh;ft4;limites_lab|CONSULTA|NICE_TSH|G|NUM_FACTORES
Tiroides|TSH baja FT4 normal|TSH baja + FT4 normal, valorar FT3|tsh;ft4;limites_lab|CONSULTA|NICE_TSH|G|NUM_FACTORES
Tiroides|TSH≥10 persistente|TSH≥10 mUI/L en dos extracciones separadas≥3 meses, FT4 normal|tsh_historial;ft4|CONSULTA|NICE_TSH|G|MUI_L
Tiroides|TSH suprimida persistente|TSH<0.1 mUI/L en dos extracciones≥3 meses con contexto clínico|tsh_historial|CONSULTA|NICE_TSH|G|MUI_L
Tiroides|Sospecha tiroides central|FT4 bajo y TSH inapropiadamente normal/baja: valorar hipófisis|ft4;tsh;limites_lab|CONSULTA|NICE_TSH|D|NUM_FACTORES
Tiroides|TSH alterada con biotina|Uso de biotina y TSH/FT4 discordantes: verificar interferencia|tsh;ft4;biotina_consumo|SEGUIMIENTO|NICE_TSH|G|NINGUNA
Tiroides|TSH bajo y FC rápida|TSH<0.1 + FC reposo≥100; ECG/FT4/FT3 si procede|tsh;fc_reposo|CONSULTA|NICE_TSH|D|NUM_FACTORES
Tiroides|TSH elevada y LDL alto|TSH sobre rango + LDL elevado; considerar trastorno secundario|tsh;ldl|CONSULTA|NICE_TSH|D|NUM_FACTORES
Tiroides|Hipotiroidismo conocido sin control|Antecedente hipotiroidismo y TSH sin control tras cambios de terapia|hipotiroidismo_previo;medicacion_tiroides;fecha_tsh|CRIBADO|NICE_TSH|G|MESES
Tiroides|Hipertiroidismo conocido y FA|Hipertiroidismo previo + ECG con FA confirmada|hipertiroidismo_previo;fa_confirmada|CONSULTA|ESC_AF|D|NUM_FACTORES
Reproductivo|SOP - disfunción ovulatoria e hiperandrogenismo|Adulto: irregularidad menstrual documentada + hiperandrogenismo clínico o bioquímico; excluir otras causas|ciclo_historial;hiperandrogenismo|CONSULTA|PCOS_GUIDE23|G|CRITERIOS_2_DE_3
Reproductivo|SOP - disfunción ovulatoria y ovario poliquístico|Adulto: irregularidad menstrual + US/AMH válida de morfología poliquística|ciclo_historial;eco_ovario_o_amh|CONSULTA|PCOS_GUIDE23|G|CRITERIOS_2_DE_3
Reproductivo|SOP - hiperandrogenismo y ovario poliquístico|Adulto: hiperandrogenismo + US/AMH apropiado; excluir otras causas|hiperandrogenismo;eco_ovario_o_amh|CONSULTA|PCOS_GUIDE23|G|CRITERIOS_2_DE_3
Reproductivo|No diagnosticar SOP por LH/FSH|Relación LH/FSH alterada sola no diagnostica SOP|lh;fsh|SEGUIMIENTO|PCOS_GUIDE23|G|NINGUNA
Reproductivo|SOP con prediabetes|SOP establecida + HbA1c 5.7–6.4%, recomendar cribado metabólico|sop_previa;hba1c|CONSULTA|PCOS_GUIDE23|D|NUM_FACTORES
Reproductivo|SOP con hipertensión|SOP conocida + PA≥130/80 confirmada, evaluar riesgo|sop_previa;pa_validada|CONSULTA|PCOS_GUIDE23|D|NUM_FACTORES
Reproductivo|Amenorrea prolongada probable anovulación|Intervalo entre menstruaciones>90 días documentado, sin embarazo y no perimenopausia|ciclo_historial;embarazo_estado;edad|CONSULTA|PCOS_GUIDE23|G|DIAS
Reproductivo|Ciclos irregulares post menarquia tardía|≥3 años tras menarquia, ciclos<21 o>35 días o <8 ciclos/año|edad_menarquia;ciclo_historial|CONSULTA|PCOS_GUIDE23|G|DIAS
Reproductivo|Ciclo cercano al evento ovulatorio no medido|Fase ovulatoria calendario sin prueba LH/progesterona: no afirmar ovulación|fase_ciclo;test_ovulacion|SEGUIMIENTO|PCOS_GUIDE23|D|NINGUNA
Reproductivo|Progesterona mal temporizada|Progesterona baja sin fecha relativa a ovulación, evitar inferir anovulación|progesterona;fase_ciclo|SEGUIMIENTO|PCOS_GUIDE23|D|NINGUNA
Reproductivo|Hiperandrogenismo bioquímico|Testosterona libre/total >rango específico del ensayo y fase, valorar etiología|testosterona;sexo_modelo;limites_lab|CONSULTA|PCOS_GUIDE23|G|RELACION_ULN
Reproductivo|Amenorrea y TSH alterada|Amenorrea y TSH fuera rango: descartar causa tiroidea, embarazo|ciclo_historial;tsh;embarazo_estado|CONSULTA|NICE_TSH|D|NUM_FACTORES
Reproductivo|Amenorrea y prolactina elevada|Amenorrea + prolactina sobre límite del método, excluir causas|ciclo_historial;prolactina;limites_lab|CONSULTA|PCOS_GUIDE23|D|NUM_FACTORES
Reproductivo|Hiperandrogenismo de rápida aparición|Andrógenos elevados marcadamente vs basal en semanas, investigar causas no SOP|testosterona_historial;tiempo_inicio|CONSULTA|PCOS_GUIDE23|D|PORCENTAJE_CAMBIO
Reproductivo|Sangrado menstrual y anemia|Sangrado abundante documentado + Hb bajo umbral OMS|sangrado_menstrual;hb|CONSULTA|WHO_HB24|D|NUM_FACTORES
Reproductivo|Embarazo no establecido|Fase ovulatoria no permite concluir embarazo, solicitar prueba si relevante|fase_ciclo;embarazo_estado|SEGUIMIENTO|ACOG_PREE|G|NINGUNA
Embarazo|Hipertensión gestacional posible|Gestación≥20 semanas, nueva PA≥140/90 confirmada según protocolo|embarazo_confirmado;semanas_gestacion;pa_validada|URGENTE|ACOG_PREE|G|MMHG
Embarazo|Hipertensión gestacional grave PAS|Gestación≥20 semanas + PAS≥160 confirmada brevemente|embarazo_confirmado;semanas_gestacion;pas_validada|CRITICA|ACOG_PREE|G|MMHG
Embarazo|Hipertensión gestacional grave PAD|Gestación≥20 semanas + PAD≥110 confirmada brevemente|embarazo_confirmado;semanas_gestacion;pad_validada|CRITICA|ACOG_PREE|G|MMHG
Embarazo|Sospecha preeclampsia proteína|Gestación≥20 sem PA≥140/90 y proteína/creatinina orina≥0.3|embarazo_confirmado;semanas_gestacion;pa_validada;proteina_creatinina_orina|URGENTE|ACOG_PREE|G|NUM_FACTORES
Embarazo|Sospecha preeclampsia plaquetas|Gestación≥20 sem PA nueva≥140/90 y plaquetas<100×10⁹/L|embarazo_confirmado;semanas_gestacion;pa_validada;plaquetas|URGENTE|ACOG_PREE|G|NUM_FACTORES
Embarazo|Sospecha preeclampsia renal|Gestación≥20 sem HTA nueva + creatinina>1.1 mg/dL o doble basal|embarazo_confirmado;semanas_gestacion;pa_validada;creatinina_historial|URGENTE|ACOG_PREE|G|NUM_FACTORES
Embarazo|Sospecha preeclampsia hepática|Gestación≥20 sem HTA nueva + transaminasas>2× límite referencia|embarazo_confirmado;semanas_gestacion;pa_validada;ast;alt;limites_lab|URGENTE|ACOG_PREE|G|NUM_FACTORES
Embarazo|Anemia gestante 1T|Primer trimestre y Hb<11.0 g/dL|embarazo_confirmado;trimestre;hb|CONSULTA|WHO_HB24|G|G_DL
Embarazo|Anemia gestante 2T|Segundo trimestre y Hb<10.5 g/dL|embarazo_confirmado;trimestre;hb|CONSULTA|WHO_HB24|G|G_DL
Embarazo|Anemia gestante 3T|Tercer trimestre y Hb<11.0 g/dL|embarazo_confirmado;trimestre;hb|CONSULTA|WHO_HB24|G|G_DL
Embarazo|No aplicar umbrales no gestante|Embarazo confirmado: desactivar rangos HbA1c/IMC/CGM adultos no embarazados cuando no aplican|embarazo_confirmado|SEGUIMIENTO|ACOG_PREE|G|NINGUNA
Embarazo|Gestación y FC en sepsis|Sospecha infección gestante con FC100–130: NICE distingue umbrales|embarazo_confirmado;infeccion_sospechada;fc_reposo|URGENTE|NICE_SEPSIS|D|BPM
Infecciones|Fiebre clínica|T≥38.0°C medida en sitio válido y adulto; evaluar etiología no necesariamente bacteriana|temperatura_clinica|CONSULTA|NICE_SEPSIS|D|CELSIUS
Infecciones|Fiebre ≥39.0|T≥39.0°C medida clínicamente y persistente, priorizar evaluación contexto|temperatura_clinica|CONSULTA|NICE_SEPSIS|D|CELSIUS
Infecciones|Fiebre ≥40.0|T≥40.0°C confirmada, valoración pronta por diversas causas|temperatura_clinica|URGENTE|NICE_SEPSIS|D|CELSIUS
Infecciones|Temperatura central baja|T central <35°C confirmada, evaluar emergencia hipotermia|temperatura_central|CRITICA|NICE_SEPSIS|D|CELSIUS
Infecciones|Infección sospechada y PAS≤90|Sospecha clínica infección + PAS≤90 mmHg validada|infeccion_sospechada;pas_validada|URGENTE|NICE_SEPSIS|G|NUM_FACTORES
Infecciones|Infección sospechada y PAS 91–100|Sospecha clínica infección + PAS91–100|infeccion_sospechada;pas_validada|URGENTE|NICE_SEPSIS|G|NUM_FACTORES
Infecciones|Infección sospechada y FC>130|Sospecha infección + FC>130 en reposo corroborada|infeccion_sospechada;fc_reposo|URGENTE|NICE_SEPSIS|G|NUM_FACTORES
Infecciones|Infección sospechada y FC91–130|Sospecha infección + FC91–130 no gestante, valorar conjunto|infeccion_sospechada;fc_reposo;embarazo_estado|CONSULTA|NICE_SEPSIS|G|NUM_FACTORES
Infecciones|Infección sospechada y T<36 timpánica|Sospecha infección + T timpánica<36°C|infeccion_sospechada;temp_timpanica|URGENTE|NICE_SEPSIS|G|NUM_FACTORES
Infecciones|Fiebre neutropénica en cáncer|T≥38.3 una vez o≥38.0 durante 1h y ANC<0.5|temperatura_clinica;neutrofilos;cancer_previo|CRITICA|IDSA_FN|G|NUM_FACTORES
Infecciones|Fiebre + hipotensión + FC alta|T≥38, PAS≤90, FC>100; priorizar deterioro, no etiquetar sepsis|temperatura_clinica;pas_validada;fc_reposo|URGENTE|NICE_SEPSIS|D|NUM_FACTORES
Infecciones|Fiebre + desaturación|T≥38 y SpO2≤92 clínica confirmada, revisar infección respiratoria/otras causas|temperatura_clinica;spo2_clinica|URGENTE|NICE_SEPSIS|D|NUM_FACTORES
Infecciones|Fiebre + leucocitosis|T≥38 con leucocitos>11×10⁹/L, no afirmar bacteria por sí sola|temperatura_clinica;leucocitos|CONSULTA|NICE_SEPSIS|D|NUM_FACTORES
Infecciones|Fiebre + leucopenia|T≥38 con leucocitos<4×10⁹/L, valoración etiológica|temperatura_clinica;leucocitos|CONSULTA|NICE_SEPSIS|D|NUM_FACTORES
Infecciones|Alerta fiebre fuera de línea basal|T clínica cambia≥1°C respecto basal individual ≥2 días, no diagnóstico|temperatura_clinica_baseline;temperatura_clinica|SEGUIMIENTO|NICE_SEPSIS|E|DELTA_C
Infecciones|No clasificar infección por CRP|CRP elevada sola no identifica infección bacteriana ni sepsis|proteina_c_reactiva|SEGUIMIENTO|NICE_SEPSIS|D|NINGUNA
Infecciones|Sospecha de infección con función renal alterada|Infección sospechada + AKI por criterio de creatinina en 48h|infeccion_sospechada;creatinina_historial|URGENTE|NICE_SEPSIS|D|NUM_FACTORES
Infecciones|Fiebre y anticoagulación conocida|Fiebre en anticoagulado + descenso Hb≥2 g/dL/7d, evaluar posible sangrado|temperatura_clinica;anticoagulacion;hb_historial|URGENTE|WHO_HB24|E|NUM_FACTORES
Respiratorio|Hipoxemia grave crónica ATS|EPOC/ILD estable y SpO2≤88% crónica verificada en reposo a nivel relevante|spo2_clinica;patologia_pulmonar_previa|CONSULTA|ATS_OXYGEN|G|PORCENTAJE_SPO2
Respiratorio|SpO2 baja nueva 89–92|SpO2 89–92% clínica nueva vs basal, confirmar y evaluar altura/EPOC|spo2_clinica;spo2_baseline;altitud_m|CONSULTA|ATS_OXYGEN|D|PORCENTAJE_SPO2
Respiratorio|SpO2≤88 nueva|SpO2≤88% clínica confirmada y nueva, valoración pronta|spo2_clinica;spo2_baseline|URGENTE|ATS_OXYGEN|D|PORCENTAJE_SPO2
Respiratorio|SpO2 nocturna fluctuante|Desaturaciones ≥4 pp repetidas durante 3 noches, señal validada: solicitar estudio sueño si clínicamente apropiado|spo2_nocturna;spo2_calidad|CRIBADO|AASM_SLEEPMED|E|NUM_EPISODIOS
Respiratorio|Posible AOS con obesidad|IMC≥30 + desaturación nocturna repetida, no diagnóstico; solicitar evaluación sueño|imc;spo2_nocturna|CRIBADO|AASM_SLEEPMED|E|NUM_FACTORES
Respiratorio|Posible AOS con HTA nocturna|ABPM noche≥120/70 y desaturaciones nocturnas recurrentes|pa_abpm_noche;spo2_nocturna|CRIBADO|AASM_SLEEPMED|E|NUM_FACTORES
Respiratorio|Nocturna sin patrón apnea demostrable|Oximetría nocturna sola insuficiente para diagnosticar AOS o calcular IAH|spo2_nocturna|SEGUIMIENTO|AASM_SLEEPMED|G|NINGUNA
Respiratorio|Sin datos frecuencia respiratoria|No disponible FR ni calidad sueño: no calcular NEWS2 ni AHI|fr;datos_sueño|SEGUIMIENTO|AASM_SLEEPMED|G|NINGUNA
Respiratorio|Enfermedad pulmonar + saturación baja|EPOC previo + SpO2<90 nueva; clínica decide nivel de intervención|epoc_previa;spo2_clinica;spo2_baseline|URGENTE|ATS_OXYGEN|D|NUM_FACTORES
Respiratorio|Altitud cambiante confunde SpO2|Nueva estancia altitud >500 m superior basal coincide con caída SpO2: contextualizar|altitud_historial;spo2_baseline|SEGUIMIENTO|ATS_OXYGEN|E|DELTA_M
Respiratorio|Desaturación y FC altas en reposo|SpO2 clínica<90 + FC>110: valorar patología respiratoria/cardiaca|spo2_clinica;fc_reposo|URGENTE|ATS_OXYGEN|D|NUM_FACTORES
Respiratorio|Caída SpO2 4pp basal|SpO2 clínica desciende≥4 puntos de basal estable y se confirma|spo2_clinica;spo2_baseline|CONSULTA|ATS_OXYGEN|E|DELTA_PP
Respiratorio|SpO2 durante ejercicio no comparable|SpO2 de ejercicio no usar umbral reposo sin protocolo específico|spo2;actividad|SEGUIMIENTO|ATS_OXYGEN|D|NINGUNA
Respiratorio|Oximetría saturada al 100 no descarta problemas|SpO2≈100% no descarta anemia, hipoventilación ni hipercapnia|spo2_clinica|SEGUIMIENTO|ATS_OXYGEN|D|NINGUNA
Respiratorio|SpO2 piel no validada|Oximetría no clínica de pulsera no equivalente a finger probe validado|spo2_dispositivo;spo2_calidad|SEGUIMIENTO|FDA_SPO2|G|NINGUNA
Seguridad clínica|Antecedente de infarto -> prevención secundaria|Infarto documentado en historial; no usar PREVENT primaria|infarto_previo|CONSULTA|ACC_LIP26|G|NINGUNA
Seguridad clínica|Ictus previo -> prevención secundaria|Ictus isquémico previo documentado; no usar PREVENT primaria|ictus_previo|CONSULTA|ACC_LIP26|G|NINGUNA
Seguridad clínica|Trasplante renal -> seguimiento específico|Trasplante renal previo: eGFR/ACR con umbrales y monitorización adaptados|trasplante_renal_previo|CONSULTA|KDIGO24|G|NINGUNA
Seguridad clínica|Dializado excluido KFRE|Diálisis actual: no estimar primer fallo renal por KFRE|dialisis_actual|SEGUIMIENTO|KDIGO24|G|NINGUNA
Seguridad clínica|Portador de marcapasos y bradicardia|Marcapasos documentado: pulso PPG requiere interpretación específica|marcapasos_previo;fc_ppg|CONSULTA|ESC_AF|D|NINGUNA
Seguridad clínica|Enfermedad hematológica y Hb|Anemia hemolítica/hemoglobinopatía: HbA1c puede ser engañosa|hemoglobinopatia_previa;hba1c|SEGUIMIENTO|ADA_DX26|G|NINGUNA
Seguridad clínica|Amputación afecta IMC|Amputación mayor: peso e IMC no equiparables a referencia ordinaria|amputacion_previa;peso_kg|SEGUIMIENTO|WHO_BMI|D|NINGUNA
Seguridad clínica|Embarazo y score cardiaco no validado|Embarazo confirmado: abstener PREVENT/HBPM estándar sin adaptación|embarazo_confirmado|SEGUIMIENTO|AHA_PREVENT|D|NINGUNA
Seguridad clínica|Datos familiares insuficientes|No inferir antecedente familiar negativo cuando no está registrado|historia_familiar_estado|SEGUIMIENTO|ADA_DX26|D|NINGUNA
Seguridad clínica|Etnicidad no proxy biológico|Origen étnico sin justificación científica específica no modifica arbitrariamente riesgos|origen_etnico|SEGUIMIENTO|AHA_PREVENT|G|NINGUNA
Seguridad clínica|Alertas repetidas sin nueva información|Misma condición vigente: agrupar episodios, no disparar por cada muestra|episodios_activos|SEGUIMIENTO|NICE_SEPSIS|D|NUM_EPISODIOS
Seguridad clínica|Dos hipótesis no suman riesgo|Una misma taquicardia compartida por varias enfermedades no sumar probabilidades|alertas_solapadas|SEGUIMIENTO|NICE_SEPSIS|D|NINGUNA
Seguridad clínica|No automedicación en crisis|Cualquier alerta crítica no debe generar dosificación automáticamente|alertas_criticas|CRITICA|NICE_SEPSIS|D|NINGUNA
Seguridad clínica|Sin síntomas no excluir emergencia|Ausencia de síntomas registrados es dato faltante, no negación de síntomas|sintomas_estado|SEGUIMIENTO|NICE_SEPSIS|D|NINGUNA
Seguridad clínica|Ventana de datos insuficiente|Se exige criterio 14d y faltan días/cobertura para inferir normalidad|calidad_serie;dias_serie|SEGUIMIENTO|ISPAD_CGM24|D|NINGUNA
Seguridad clínica|Sensor sin sincronización temporal|FC, PA, glucosa y SpO2 no alineados: no unir como evento simultáneo|timestamps_sensores|SEGUIMIENTO|NICE_SEPSIS|D|NINGUNA
Seguridad clínica|No predecir FA con HRV solamente|HRV baja sin ECG no permite probabilidad específica de FA|hrv;ecg_interpretado|SEGUIMIENTO|ESC_AF|G|NINGUNA
Seguridad clínica|Sin hemograma no excluir anemia|Hemoglobina opcional ausente: no se puede emitir normalidad hemática|hb|SEGUIMIENTO|WHO_HB24|G|NINGUNA
Seguridad clínica|Sin perfil tiroideo no excluir tiroides|TSH ausente: FC o peso no descartan patología tiroidea|tsh|SEGUIMIENTO|NICE_TSH|G|NINGUNA
Seguridad clínica|Sin ACR no calcular KFRE|eGFR conocida, ACR ausente: probabilidades KFRE no calculables|egfr;acr_orina|SEGUIMIENTO|KFRE_TANGRI16|G|NINGUNA
Seguridad clínica|Sin colesterol no calcular PREVENT|No hay colesterol total y HDL: PREVENT no calculable|colesterol_total;hdl|SEGUIMIENTO|AHA_PREVENT|G|NINGUNA
Seguridad clínica|Sin sexo usado en fórmula|No inventar coeficiente sexo en eGFR/PREVENT/KFRE si no hay campo adecuado|sexo_modelo|SEGUIMIENTO|NIDDK_EGFR|G|NINGUNA
Seguridad clínica|Sin contexto de edad/gestación|Adulto/embarazo no confirmado: abstener rangos específicos hasta aclarar|edad;embarazo_estado|SEGUIMIENTO|ACOG_PREE|D|NINGUNA
Seguridad clínica|Origen étnico sensible|No usar origen étnico para aumentar urgencia sin validación de equidad|origen_etnico;validacion_equidad|SEGUIMIENTO|AHA_PREVENT|D|NINGUNA
'''

def default_action(domain, severity, label):
    if severity=='CRITICA':return 'Solicitar evaluación médica inmediata; no administrar tratamientos automáticamente.'
    if severity=='URGENTE':return 'Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.'
    if domain=='Calidad de datos' or domain=='Seguridad clínica':return 'Abstenerse de inferencia específica y solicitar el dato o medición pertinente.'
    if domain=='Riñón':return 'Revisión clínica nefrológica o general según cronicidad; comprobar analítica y tendencia.'
    if domain=='Glucosa':return 'Revisión clínica del control glucémico; distinguir CGM de plasma diagnóstico.'
    if domain=='Hígado':return 'Revisión clínica de riesgo hepatometabólico y, si corresponde, elastografía u otra prueba.'
    if domain=='Hematología':return 'Evaluar hemograma repetido y etiología clínica; interpretar según embarazo y edad.'
    if domain=='Embarazo':return 'Valoración obstétrica específica según semana gestacional y gravedad.'
    if domain=='Reproductivo':return 'Revisión ginecoendocrinológica; no usar fase ovulatoria aislada como diagnóstico.'
    if domain=='Cardiovascular':return 'Evaluar prevención cardiovascular y confirmar según score o prueba indicada.'
    if domain=='Antropometría':return 'Evaluación nutricional y cardiometabólica contextualizada.'
    if domain=='Infecciones':return 'Valorar contexto clínico y pruebas de infección, sin diagnosticar sepsis con signos aislados.'
    if domain=='Respiratorio':return 'Verificar con oxímetro clínico y valorar estudio respiratorio/sueño según proceda.'
    if domain=='Tiroides':return 'Repetir o completar perfil tiroideo según guía, ensayo y contexto.'
    return 'Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.'

new=[]
for raw in B.strip().splitlines():
    if not raw.strip() or raw.startswith('#'):continue
    parts=[v.strip() for v in raw.split('|')]
    if len(parts)!=8: raise ValueError((len(parts),raw))
    dom,name,criterion,variables,sev,source,grade,quant=parts
    if source not in S:raise ValueError(('source',source))
    if grade not in ('G','D','E'):raise ValueError(('grade',grade))
    new.append(dict(id=f'R{len(base["reglas"])+len(new)+1:04d}',dominio=dom,condicion=name,
        severidad=sev,tipo_inferencia='OBSERVACION' if grade=='G' and quant in ('MMHG','MG_DL','G_DL','MMOL_L','PORCENTAJE_SPO2','PUNTUACION') else 'PATRON_RIESGO',
        disponibilidad='BASE+OPCIONAL' if any(x in variables for x in (';','tsh','creatinina','colesterol','plaquetas','hb','egfr','hba1c','ast','alt','ac','potasio','ferritina','lip')) else 'BASE',
        variables_necesarias=variables,criterio_SI=criterion,ventana='Según la condición (episodio, serie o laboratorio) indicada en criterio',
        resultado_ENTONCES=default_action(dom,sev,name),prueba_confirmatoria='Control mediante técnica clínica validada; según el criterio',
        estado_evidencia={'G':'UMBRAL_GUIA','D':'DERIVADA_NO_VALIDADA','E':'EXPERIMENTAL_NO_VALIDADA'}[grade],
        fuente_id=source,fuente_url=S[source],poblacion='Adultos; aplicar restricciones descritas en el criterio',
        limitaciones='La relación multivariable no constituye modelo de probabilidad calibrada. Interpretar enfermedad, medicamentos, embarazo, edad y calidad.',
        riesgo_formato=quant,horizonte_probabilidad=('2 años' if quant=='PROBABILIDAD_2_ANOS' else '5 años' if quant=='PROBABILIDAD_5_ANOS' else '10 años' if quant=='PROBABILIDAD_10_ANOS' else 'No aplicable'),
        es_probabilidad_calibrada= quant.startswith('PROBABILIDAD'),puede_diagnosticarse_automaticamente=False,
        requiere_validacion_local=True, version_catalogo='v03'))

# Reglas legado conservadas, con interpretación recalibrada para evitar falsos porcentajes
old=[]
for r in base['reglas']:
  x=r.copy(); x['id']=f"R{int(r['id'][1:]):04d}"
  x['estado_evidencia']= {'GUIA':'UMBRAL_GUIA', 'DERIVADA':'DERIVADA_NO_VALIDADA','EXPERIMENTAL':'EXPERIMENTAL_NO_VALIDADA','NO_DISPONIBLE':'ABSTENCION'}.get(r['estado_evidencia'],r['estado_evidencia'])
  x.update(riesgo_formato='CRITERIO_O_EXPOSICION',horizonte_probabilidad='No aplicable',es_probabilidad_calibrada=False,puede_diagnosticarse_automaticamente=False,requiere_validacion_local=True,version_catalogo='v02_historica')
  old.append(x)
R=old+new
# Umbral prohibido para probabilidades: sólo modelos con entradas completas computan el porcentaje; un umbral de riesgo NO es probabilidad del paciente.
MODELS=[
 dict(id='KFRE_4V_2Y',nombre='KFRE 4 variables, 2 años',salida='Probabilidad fallo renal terminal (2 años)',horizonte='2 años',tipo='PROB_ABSOLUTA',estado='IMPLEMENTADO_REFERENCIA',poblacion='ERC confirmada G3–G5; no diálisis',inputs='edad, sexo usado en ecuación, eGFR validado, ACR urinario mg/g',formula='1 - 0.9832^(exp(-0.2201*(edad/10-7.036)+0.2467*(hombre-0.5642)-0.5567*(eGFR/5-7.222)+0.4510*(ln(ACR)-5.137)))',regiones='No Norteamérica (recalibración 2016), calibración mexicana pendiente',fuente='KFRE_TANGRI16;KFRE_BMJ;KDIGO24',limitaciones='Estimación estadística, no diagnóstico; no reemplaza derivación clínica.'),
 dict(id='KFRE_4V_5Y',nombre='KFRE 4 variables, 5 años',salida='Probabilidad fallo renal terminal (5 años)',horizonte='5 años',tipo='PROB_ABSOLUTA',estado='IMPLEMENTADO_REFERENCIA',poblacion='ERC confirmada G3–G5; no diálisis',inputs='edad, sexo, eGFR validado, ACR urinario mg/g',formula='1 - 0.9365^(exp(-0.2201*(edad/10-7.036)+0.2467*(hombre-0.5642)-0.5567*(eGFR/5-7.222)+0.4510*(ln(ACR)-5.137)))',regiones='No Norteamérica (recalibración 2016), calibración mexicana pendiente',fuente='KFRE_TANGRI16;KFRE_BMJ;KDIGO24',limitaciones='Una probabilidad puntual no implica certeza; validar prospectivamente en población objetivo.'),
 dict(id='PREVENT_CVD',nombre='AHA PREVENT-CVD',salida='Riesgo CVD total',horizonte='10 años (30 años edades elegibles)',tipo='PROB_ABSOLUTA',estado='PENDIENTE_IMPLEMENTACION_OFICIAL',poblacion='Edad 30-79 sin ECV establecida, datos completos',inputs='edad, sexo, PAS, colesterol total, HDL, eGFR, diabetes, tabaquismo, estatinas, antihipertensivos (+BMI en modelo IC)',formula='Utilizar implementación PREVENT oficial completa, no suma manual de pesos inventados',regiones='Derivado EUA; comprobar calibración en México',fuente='AHA_PREVENT',limitaciones='Sin tabaquismo o medicación no calcular. Modelo 10/30 años sólo en grupos correspondientes.'),
 dict(id='FIB4',nombre='FIB-4',salida='Índice de fibrosis avanzada probable',horizonte='No probabilístico',tipo='PUNTUACION',estado='IMPLEMENTADO_REFERENCIA',poblacion='Riesgo MASLD, interpretación válida por edad, no contexto agudo',inputs='edad (años), AST (U/L), ALT (U/L), plaquetas (10^9/L)',formula='edad*AST/(plaquetas*sqrt(ALT))',regiones='Validar por población y condiciones hepáticas',fuente='AASLD_FIB4',limitaciones='No es P(fibrosis); <35 no confiable; >=65 usa corte 2.0 para bajo riesgo; >2.67 alto riesgo si aplica.'),
 dict(id='EGFR21',nombre='CKD-EPI creatinina 2021',salida='eGFR mL/min/1.73 m2',horizonte='Estado actual',tipo='DERIVADO',estado='IMPLEMENTADO_REFERENCIA',poblacion='Adultos >=18 con creatinina estándar IDMS',inputs='edad, creatinina mg/dL, sexo usado en ecuación',formula='142*min(Scr/k,1)^alpha*max(Scr/k,1)^(-1.2)*0.9938^edad*(1.012 si mujer)',regiones='Sin coeficiente por etnicidad',fuente='NIDDK_EGFR',limitaciones='No usar fórmula en niños ni asumir que eGFR sola diagnostica ERC sin cronicidad.'),
 dict(id='CHA2DS2_VA',nombre='CHA2DS2-VA',salida='0 a 8 puntos',horizonte='No porcentaje individual sin calibración',tipo='PUNTUACION',estado='IMPLEMENTADO_REFERENCIA',poblacion='FA confirmada; antecedentes completos',inputs='IC, HTA, edad, diabetes, ictus/AIT/tromboembolia, vasculopatía',formula='IC(1)+HTA(1)+edad65-74(1)/edad≥75(2)+DM(1)+ictus/AIT(2)+vasculopatía(1)',regiones='ESC 2024',fuente='ESC_AF',limitaciones='No convertir puntos a % anual con tabla indiscriminada; decisiones clínicas y sangrado no derivables.'),
 dict(id='CGM_METRICS',nombre='CGM tiempo en rango',salida='TIR/TBR/TAR % por ventana',horizonte='14 días',tipo='EXPOSICION',estado='IMPLEMENTADO_REFERENCIA',poblacion='Principalmente personas con diabetes; metas según edad y embarazo',inputs='serie glucosa, timestamps, calidad, diabetes previa',formula='integral temporal fraccionada sobre intervalo válido',regiones='Consenso internacional / ADA',fuente='ADA_GLY26;ISPAD_CGM24',limitaciones='No diagnostica diabetes; no usar suma simple de muestras si frecuencia no uniforme.'),
 dict(id='WHtR',nombre='Cintura/altura',salida='Cociente adimensional',horizonte='Estado actual',tipo='DERIVADO',estado='IMPLEMENTADO_REFERENCIA',poblacion='Adultos; NICE especialmente IMC<35',inputs='cintura cm, altura cm, IMC',formula='cintura_cm/altura_cm',regiones='Interpretación NICE',fuente='NICE_OBESITY',limitaciones='Proporción no equivale a riesgo absoluto individual.'),
]

# Reglas de antecedente como MODIFICADORES DE RUTA, no multiplicadores probabilísticos arbitrarios.
MOD=[
 ('Diabetes tipo 1','Hipoglucemia y cetosis','Priorizar eventos CGM<54; no cambiar probabilidad de otras enfermedades sin modelo'),
 ('Diabetes tipo 2','Renal/ASCVD','Solicitar ACR y eGFR; activar PREVENT con diabetes=1 sólo si otras entradas completas'),
 ('Infarto previo','Prevención secundaria','No calcular PREVENT primaria; revisar lípidos'),
 ('Ictus previo','Prevención secundaria','Si FA confirmada aumenta CHA2DS2-VA +2; revisar anticoagulación sólo clínicamente'),
 ('Insuficiencia cardiaca','Congestión','Peso +2kg/3d y PAS baja ameritan revisión; No inferir HF de peso solo'),
 ('ERC','Fallo renal','Si G3–G5 y ACR existe, KFRE; evitar si diálisis o G1–G2'),
 ('FA documentada','Ictus','Activar CHA2DS2-VA sólo con componentes completos'),
 ('EPOC','Hipoxemia','Contextualizar SpO2 basal y objetivos; no usar oxígeno sin prescripción'),
 ('Hepatopatía crónica','Fibrosis','Revisar FIB4 sólo cuando sea clínicamente pertinente'),
 ('Hipotiroidismo','Metabólico','Evaluar TSH/FT4 y tendencia, evitar inferir de FC'),
 ('Embarazo en curso','PA gestacional','Aplicar umbrales ACOG; desactivar clasificaciones no gestantes'),
 ('Hipertensión crónica','Renal','Monitorizar ACR/eGFR y PA validada; riesgo CV según modelo'),
 ('Cáncer en quimioterapia','Neutropenia febril','Umbral fiebre+ANC requiere acción urgente'),
 ('Anemia previa','HbA1c potencialmente sesgada','Verificar método de HbA1c y recambio eritrocitario'),
 ('Cirrosis conocida','Disfunción hepática','Evitar FIB4 como confirmación de cirrosis y contextualizar INR/albumina'),
 ('Trasplante renal','ERC seguimiento','No aplicar FKRE automáticamente; seguimiento específico'),
 ('Amputación mayor','Antropometría','IMC puede requerir ajuste por extremidad faltante'),
 ('Marcapasos','Pulso','PPG no debe inferir bloqueos automáticamente'),
 ('Anticoagulación','Hemorragia','Caída Hb aguda requiere valoración; no indicar ajustes de dosis'),
 ('Enfermedad hemolítica','HbA1c','Posible falseamiento; alternativas de laboratorio'),
]

# Inputs nuevos detectados, para ampliar diccionario sin inventar obligatoriedad.
known={v['variable'] for v in base['variables']}; extras=set()
for r in new:
 for v in r['variables_necesarias'].split(';'):
  v=v.strip()
  if v and v not in known: extras.add(v)
VAR=base['variables'][:]+[dict(variable=v,unidad='Según protocolo (unidad declarada en esquema)',origen='Serie, historia o laboratorio; opcional salvo que forme parte de BASE real',frecuencia='Según indicación y disponibilidad',validacion='No inferir ausencias; comprobar unidades, calidad, metadatos y fecha',estatus='OPCIONAL_O_DERIVADA',observaciones='Añadida en v03; revisar correspondencia con esquema de captura local') for v in sorted(extras)]

# Revisar ausencia de fuentes en reglas, IDs únicos y peligro de porcentajes arbitrarios
assert len(set(r['id'] for r in R))==len(R)
assert all(r.get('fuente_url') for r in R)
assert all(m['tipo']=='PROB_ABSOLUTA' for m in MODELS if m['id'].startswith(('PREVENT','KFRE')))
assert sum(m['tipo']=='PROB_ABSOLUTA' for m in MODELS)==3
SEVERITY={'CRITICA':5,'URGENTE':4,'CONSULTA':3,'CRIBADO':2,'SEGUIMIENTO':1}
for r in R:
 r['prioridad_ordinal']=SEVERITY.get(r['severidad'],2)
 r['p_riesgo_enfermedad_pct']='NO_ESTIMABLE_CON_ESTA_REGLA'
 r['recomendar_riesgo_absoluto']='Solo con modelo validado y todas sus entradas; nunca con conteo de factores'
 r['riesgo_falso_positivo']='Alto si se ignoran calidad, medicamentos, embarazo, contexto y prevalencia'
 r['necesita_revision_clinica']=True
 r['fuente_url']=S.get(r['fuente_id'],r['fuente_url'])

meta=dict(base['meta']);meta.update(version='v03',fecha_elaboracion='2026-11-14',total_reglas=len(R),reglas_agregadas=len(new),total_variables=len(VAR),total_modelos=len(MODELS),nota='Catálogo educativo de prototipado; no apto para decisión clínica autónoma o uso médico sin validación prospectiva, regulación y supervisión profesional.',riesgo_absoluto='KFRE calculable si se satisfacen los requisitos; PREVENT listado pero no implementado sin código oficial completo.')
OBJ=dict(meta=meta,reglas=R,variables=VAR,antecedentes=base['antecedentes'],secuelas=base['secuelas'],modificadores=MOD,modelos_riesgo=MODELS,fuentes=[dict(id=k,url=v) for k,v in S.items()],diccionario_formato_riesgo={
 'PROB_ABSOLUTA':'Porcentaje de riesgo de un desenlace dentro de un horizonte definido según modelo validado','PUNTUACION':'Score clínico no necesariamente convertible a probabilidad','EXPOSICION':'Proporción/duración de tiempo fuera de rango','DERIVADO':'Valor calculado con fórmula física/clínica','NINGUNA':'No cuantificable con evidencia actual','INTENSIDAD':'Magnitud de umbral, no probabilidad'
})
(OUT/'motor_alertas_catalogo_v03.json').write_text(json.dumps(OBJ,ensure_ascii=False,indent=2))
cols=['id','dominio','condicion','severidad','criterio_SI','variables_necesarias','disponibilidad','ventana','estado_evidencia','riesgo_formato','horizonte_probabilidad','p_riesgo_enfermedad_pct','resultado_ENTONCES','prueba_confirmatoria','fuente_id','fuente_url','poblacion','limitaciones','version_catalogo']
with (OUT/'motor_alertas_reglas_v03.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=cols,extrasaction='ignore'); w.writeheader();w.writerows(R)
# Crear XLSX con artifact_tool y resumen cuantificado, sin fórmulas clínicas no calibradas.
wb=Workbook.create()
README=[['CATÁLOGO BIOMÉTRICO DE ALERTAS · V03',''],['Fecha','2026-11-14'],['Reglas históricas',len(old)],['Reglas nuevas',len(new)],['Total reglas',len(R)],['Dominios',len(set(r['dominio'] for r in R))],['Variables registradas',len(VAR)],['Modelos cuantitativos especificados',len(MODELS)],['Riesgos absolutos implementados','KFRE 2 y 5 años únicamente; PREVENT pendiente de implementación exacta'],['ADVERTENCIA','Los porcentajes sólo pueden derivarse de modelos de riesgo validados con inputs completos. Los umbrales NO son probabilidades.'],['Límite operacional','Las reglas requieren evaluación de un clínico y validación con cohorte prospectiva mexicana; un prototipo no es dispositivo aprobado.'],['Fuentes','Cada fila de regla incluye enlace y clasificación de evidencia (G=umbral, D=derivada, E=exploratoria).'],['DATO FALTANTE','NO_CALCULABLE / ABSTENERSE; prohibidas imputaciones silenciosas y ceros por defecto.'],['SESGO','Origen étnico y pigmentación no son intercambiables; validar sesgos de medición y equidad.'],['Estructura','Reglas, Modelos, Variables, Modificadores, Fuentes, Antecedentes, Secuelas, Dominios y Ejemplos']]

def sheetdata(name,headers,rows,widths=None):
 sh=wb.worksheets.add(name)
 vals=[list(headers)]+[list(x) for x in rows]
 n=len(headers); chunk=130
 for i in range(0,len(vals),chunk):
  block=vals[i:i+chunk]; sh.get_range_by_indexes(i,0,len(block),n).values=block
 sh.get_range_by_indexes(0,0,1,n).format={'fill':'#12354B','font':{'bold':True,'color':'#FFFFFF'},'row_height':30,'vertical_alignment':'center'}
 sh.freeze_panes.freeze_rows(1)
 try:sh.get_range_by_indexes(1,0,max(1,len(vals)-1),n).format.row_height=23
 except Exception:pass
 for i in range(n):
  w=(widths[i] if widths and i<len(widths) else (44 if i<3 else 27))
  sh.get_range_by_indexes(0,i,max(1,len(vals)),1).format.column_width=w
 return sh
intro=wb.worksheets.add('Inicio'); intro.get_range(f'A1:B{len(README)}').values=README;intro.get_range('A1:B1').format={'fill':'#12354B','font':{'bold':True,'color':'#FFFFFF'},'row_height':38};intro.get_range('A1:A20').format.column_width=33;intro.get_range('B1:B20').format.column_width=98;intro.freeze_panes.freeze_rows(1)
rows=[]
for r in R:rows.append([str(r.get(c,'')) if r.get(c) is not None else '' for c in cols])
rule_sheet=sheetdata('Reglas',cols,rows,[12,27,45,15,85,53,21,35,25,22,22,26,69,47,23,68,33,63,18])
# Individualizar colores de evidencia sin mucho overhead
try:
 col=rule_sheet.get_range(f'I2:I{len(rows)+1}')
 col.conditional_formats.add_custom('=$I2="EXPERIMENTAL_NO_VALIDADA"',{'fill':'#FFF0E1'})
 col.conditional_formats.add_custom('=$I2="UMBRAL_GUIA"',{'fill':'#E8F4EC'})
except Exception:pass
sheetdata('Modelos',list(MODELS[0].keys()),[[m.get(k,'') for k in MODELS[0].keys()] for m in MODELS],[22,36,48,34,22,28,45,62,70,47,43,75])
sheetdata('Variables',list(VAR[0].keys()),[[v.get(k,'') for k in VAR[0].keys()] for v in VAR],[31,21,37,30,60,26,67])
sheetdata('Modificadores',['Antecedente','Activa ruta','Acción sin pesos arbitrarios'],MOD,[39,37,85])
sheetdata('Fuentes',['ID','URL'],[[k,v] for k,v in S.items()],[26,95])
sheetdata('Antecedentes',['Enfermedad','Efecto'],[[x.get('enfermedad',''),x.get('efecto','')] for x in base['antecedentes']],[35,92])
sheetdata('Secuelas',['Secuela','Efecto'],[[x.get('secuela',''),x.get('efecto','')] for x in base['secuelas']],[35,92])
summary=collections.Counter(r['dominio'] for r in R)
sheetdata('Dominios',['Dominio','Total reglas','Guía/umbral','Derivada','Experimental'],[[d,n,sum(x['dominio']==d and x['estado_evidencia']=='UMBRAL_GUIA' for x in R),sum(x['dominio']==d and x['estado_evidencia']=='DERIVADA_NO_VALIDADA' for x in R),sum(x['dominio']==d and x['estado_evidencia']=='EXPERIMENTAL_NO_VALIDADA' for x in R)] for d,n in sorted(summary.items())],[34,19,22,19,19])
EXAMPLES=[
('KFRE', 'eGFR 35 + ACR 600 mg/g + edad 65 + sexo registrado + ERC confirmada','Calcular probabilidad de fallo renal 2/5 años; región no Norteamérica','NUNCA extrapolar a G1/G2 ni diálisis'),
('PREVENT','Edad 58 + PAS 145 + lípidos y eGFR, sin información tabaquismo','NO_CALCULABLE; solicitar tabaquismo y fármacos','No sustituir tabaquismo por origen étnico'),
('PA','PAS media ABPM 24h 133, PAD 77, mediciones validadas','Clasificación hipertensión por criterio ESC ABPM 24h','No informar P(cardiopatía) a partir de 133/77 solamente'),
('Diabetes','HbA1c 6.2% de laboratorio no gestante','Prediabetes por criterio ADA; intensidad relativa al intervalo','Sin horizonte no expresar "80% de diabetes"'),
('CGM','TBR <54 = 1.8% en 14d, datos 85% disponibles, diabetes establecida','Tiempo bajo 54 superior al objetivo <1%; revisión clínica','1.8% significa tiempo, no probabilidad'),
('ERC','eGFR 58 una vez y ACR ausente','Repetir y ACR; NO diagnosticar ERC por una medición aislada','Se requiere persistencia≥3 meses o marcadores apropiados'),
('FIB4','Edad 50 AST 30 ALT 25 plaquetas 160','FIB4 = 50*30/(160*sqrt25)=1.875; intervalo intermedio','1.875 no equivale a 18.75% de fibrosis'),
('Sepsis','T38.5, FC118, PAS94; infección clínica sospechada','Evaluación de deterioro con NICE; estrato moderado-alto según conjunto','No adjudicar riesgo de muerte individual numérico'),
]
sheetdata('Ejemplos',['Ejemplo','Datos','Resultado esperado','Control de seguridad'],EXAMPLES,[24,63,82,75])
try:
 check=wb.inspect({'kind':'table','range':'Inicio!A1:B7','include':'values','table_max_rows':7,'table_max_cols':2})
 print('INSPECCION:',check.ndjson[:1800])
except Exception as e:print('inspect warn',e)
SpreadsheetFile.export_xlsx(wb).save(str(OUT/'catalogo_alertas_biometricas_v03.xlsx'))
print('TOTAL',len(R),'NEW',len(new),'VARIABLES',len(VAR),'DOMAINS',len(summary),'SOURCES',len(S),'MODELS',len(MODELS))
print('EVIDENCE',collections.Counter(r['estado_evidencia'] for r in R))
print('ARTIFACTS',[(p.name,p.stat().st_size) for p in [OUT/'motor_alertas_catalogo_v03.json',OUT/'motor_alertas_reglas_v03.csv',OUT/'catalogo_alertas_biometricas_v03.xlsx']])
