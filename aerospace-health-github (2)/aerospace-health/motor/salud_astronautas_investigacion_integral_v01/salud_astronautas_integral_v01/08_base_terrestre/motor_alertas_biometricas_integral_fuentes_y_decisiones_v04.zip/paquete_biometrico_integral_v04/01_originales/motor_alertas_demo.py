#!/usr/bin/env python3
"""Prototipo didáctico de motor de reglas, NO aprobado para uso clínico.

Entrada: diccionario JSON de medidas resumidas y metadatos de sensor.
Salida: alertas trazables y abstenciones (no equivale a diagnóstico).

Los umbrales deben someterse a revisión clínica, validación externa y autorización
regulatoria antes de emitir notificaciones médicas reales.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any
import json
import sys

SOURCE = {
 'ADA26':'https://doi.org/10.2337/dc26-s002',
 'AHA25':'https://www.jacc.org/doi/10.1016/j.jacc.2025.05.007',
 'NICE_SEPSIS':'https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk',
 'NICE_WHTR':'https://www.nice.org.uk/guidance/ng246/chapter/Identifying-and-assessing-overweight-obesity-and-central-adiposity',
 'ACOG':'https://www.acog.org/womens-health/faqs/preeclampsia-and-high-blood-pressure-during-pregnancy',
 'UKKA':'https://www.ukkidney.org/sites/renal.org/files/FINAL%20VERSION%20-%20UKKA%20CLINICAL%20PRACTICE%20GUIDELINE%20-%20MANAGEMENT%20OF%20HYPERKALAEMIA%20IN%20ADULTS%20-%20191223.pdf',
 'AASM':'https://aasm.org/resources/clinicalguidelines/diagnostic-testing-osa.pdf',
 'CDC_BMI':'https://www.cdc.gov/bmi/adult-calculator/bmi-categories.html',
 'ESC_BP':'https://academic.oup.com/eurheartj/article/45/38/3912/7741010',
 'ESC_AF':'https://academic.oup.com/eurheartj/article/45/36/3314/7738779',
 'NEUTRO':'https://www.cancercare.mb.ca/export/sites/default/For-Health-Professionals/.galleries/files/treatment-guidelines-rro-files/practice-guidelines/supportive-care/CCMB-Neutropenia-Protocol-and-Algorithms-2017.pdf',
 'WHO':'https://www.ncbi.nlm.nih.gov/books/NBK602185/table/ch5.tab2/',
 'ADA_GLY':'https://doi.org/10.2337/dc26-s006',
 'ESC_HF':'https://academic.oup.com/eurheartj/article/42/36/3599/6358045',
}

SEVERITY_RANK={'CRITICA':0,'URGENTE':1,'CONSULTA':2,'CRIBADO':3,'SEGUIMIENTO':4}

def alert(code:str, severity:str, message:str, action:str, source:str, confidence:str='contextual') -> dict:
    return dict(codigo=code, severidad=severity, observacion=message,
                accion=action, certeza=confidence, diagnostico=False, fuente=SOURCE[source])

def evaluate(p:dict[str,Any]) -> dict:
    """No utiliza datos faltantes como normales ni asigna probabilidades inventadas."""
    alerts=[]; abstentions=[]
    age=p.get('age_years')
    if not isinstance(age,(int,float)) or age <18:
        return {'alertas':[],'abstenciones':['Edad ausente, <18 o inválida; el prototipo sólo admite adultos.']}
    h,w=p.get('height_cm'),p.get('weight_kg')
    bmi=None
    if isinstance(h,(int,float)) and h>0 and isinstance(w,(int,float)) and w>0:
        bmi=w/(h/100)**2
        if age>=20 and bmi>=30:
            alerts.append(alert('BMI_30','CONSULTA',f'IMC {bmi:.1f} kg/m²',
                                'Valoración de obesidad y factores cardiometabólicos','CDC_BMI'))
        waist=p.get('waist_cm')
        if age>=20 and waist is not None and bmi<35 and waist/h>=0.5:
            alerts.append(alert('WHtR','CONSULTA',f'Cintura/talla = {waist/h:.2f}',
                                'Evaluar adiposidad central con medidas estandarizadas','NICE_WHTR'))
    else:
        abstentions.append('IMC/cintura-talla: talla o peso ausentes o inválidos.')

    # Validez de presión precede todo análisis del corte de PA.
    bp=p.get('bp')
    if not bp:
        abstentions.append('Presión arterial ausente.')
    elif not bp.get('validated_cuff'):
        abstentions.append('PA no validada (posible cuffless): sin diagnóstico por reloj; repetir con manguito validado.')
    else:
        sbp,dbp=bp.get('sbp'),bp.get('dbp')
        if not all(isinstance(x,(int,float)) for x in (sbp,dbp)) or not (40<sbp<330 and 20<dbp<200 and sbp>dbp):
            abstentions.append('PA inválida/inverosímil; repetir.')
        else:
            pregnant=p.get('pregnancy_status','unknown')
            if pregnant=='confirmed':
                if sbp>=160 or dbp>=110:
                    alerts.append(alert('OB_BP_SEVERE','CRITICA',f'Embarazo y PA {sbp}/{dbp} mmHg',
                                        'Evaluación obstétrica inmediata','ACOG'))
                elif sbp>=140 or dbp>=90:
                    alerts.append(alert('OB_BP_HIGH','URGENTE',f'Embarazo y PA {sbp}/{dbp} mmHg',
                                        'Valoración obstétrica y confirmación protocolizada','ACOG'))
            elif sbp>180 or dbp>120:
                if bp.get('rechecked'):
                    alerts.append(alert('BP_SEVERE','URGENTE',f'PA severa {sbp}/{dbp} mmHg',
                                        'Evaluación médica pronta y preguntar síntomas/daño de órgano','AHA25'))
                else:
                    abstentions.append('PA severa observada pero no reconfirmada; requiere repetición segura e inmediata.')
            else:
                method=bp.get('setting','unknown')
                threshold={'clinic':(140,90),'home':(135,85),'abpm_24h':(130,80),'abpm_night':(120,70)}.get(method)
                if threshold and bp.get('multi_reading_average') and (sbp>=threshold[0] or dbp>=threshold[1]):
                    alerts.append(alert('BP_PERSISTENT','CONSULTA',f'Media PA {method}: {sbp}/{dbp}',
                                        'Confirmación y evaluación de hipertensión','ESC_BP'))
                elif not threshold:
                    abstentions.append('Tipo de toma PA desconocido; umbral de hipertensión no aplicable.')
            if pregnant=='unknown':
                abstentions.append('Embarazo no documentado: no se puede aplicar ruta obstétrica específica.')

    # Saturación: no usar sin registro de calidad / contexto.
    ox=p.get('pulse_ox')
    if ox is None:
        abstentions.append('SpO2: no disponible.')
    elif ox.get('clinically_validated') and ox.get('resting') and ox.get('reconfirmed') and ox.get('quality_ok'):
        value=ox.get('spo2')
        if isinstance(value,(int,float)) and 40<=value<=100 and value<=88:
            alerts.append(alert('LOW_SPO2','URGENTE',f'SpO2 {value}% confirmada en reposo',
                                'Valoración médica urgente y evaluación respiratoria','NICE_SEPSIS'))
    else:
        abstentions.append('SpO2 sin calidad, reposo o confirmación requeridas; no aplicar corte clínico.')

    # Los datos de CGM sólo guían manejo de personas YA diagnosticadas.
    cgm=p.get('cgm')
    hist=p.get('history') or []
    known_diabetes=('diabetes_tipo_1' in hist or 'diabetes_tipo_2' in hist)
    if cgm:
        if not cgm.get('quality_ok'):
            abstentions.append('CGM con calidad insuficiente.')
        elif known_diabetes and isinstance(cgm.get('mg_dl'),(int,float)) and cgm['mg_dl']<54:
            alerts.append(alert('GLUCOSE_LOW_2','CRITICA',f'CGM <54 mg/dL: {cgm["mg_dl"]}',
                                'Aplicar plan individual de hipoglucemia; verificar capilar si discordante','ADA_GLY'))
        elif known_diabetes and isinstance(cgm.get('mg_dl'),(int,float)) and cgm['mg_dl']<70:
            alerts.append(alert('GLUCOSE_LOW_1','URGENTE',f'CGM <70 mg/dL: {cgm["mg_dl"]}',
                                'Revisar plan individual y confirmar lectura si discordante','ADA_GLY'))
        if not known_diabetes and isinstance(cgm.get('mg_dl'),(int,float)) and cgm['mg_dl']>=180:
            abstentions.append('CGM >=180 mg/dL: NO diagnostica ni constituye cribado validado para diabetes; puede discutirse laboratorio.')

    # Pruebas opcionales de laboratorio. No inferirlas de sensores.
    labs=p.get('labs') or {}
    potassium=labs.get('potassium_mmol_l')
    if isinstance(potassium,(int,float)) and potassium>=6.5:
        alerts.append(alert('K_6_5','CRITICA',f'Potasio sérico {potassium} mmol/L',
                            'Evaluación hospitalaria urgente y ECG','UKKA'))
    a1c=labs.get('hba1c_pct'); fpg=labs.get('fasting_plasma_glucose_mg_dl')
    a1c_high=isinstance(a1c,(int,float)) and a1c>=6.5
    fpg_high=isinstance(fpg,(int,float)) and fpg>=126
    if a1c_high or fpg_high:
        count=int(a1c_high)+int(fpg_high)
        alerts.append(alert('DIABETES_LAB','CONSULTA',f'{count} prueba(s) analítica(s) por encima de corte diagnóstico ADA',
                            'Confirmar validez e interpretar clínicamente; no usar CGM como prueba diagnóstica','ADA26',
                            confidence='dos pruebas alteradas' if count==2 else 'falta corroboración'))
    hb=labs.get('hemoglobin_g_dl')
    sex=p.get('sex_for_reference')
    if isinstance(hb,(int,float)):
        if sex=='male' and hb<13 or sex=='female' and p.get('pregnancy_status')=='not_pregnant' and hb<12:
            alerts.append(alert('ANEMIA','CONSULTA',f'Hemoglobina {hb} g/dL',
                                'Evaluar anemia según rango aplicable y altitud','WHO'))
        elif sex is None:
            abstentions.append('Hemoglobina disponible sin categoría de referencia por sexo/embarazo; no etiquetar anemia.')
    anc=labs.get('neutrophils_per_ul')
    clinical_temp=p.get('clinical_temperature_c')
    if isinstance(anc,(int,float)) and anc<500 and isinstance(clinical_temp,(int,float)) and clinical_temp>=38.3:
        alerts.append(alert('FEBRILE_NEUTROPENIA','CRITICA',f'ANC={anc}/µL y T={clinical_temp} °C',
                            'Atención hospitalaria inmediata','NEUTRO',confidence='patrón de alto riesgo'))

    # Antecedentes modificadores explícitos (no equivalen a diagnóstico nuevo).
    if 'insuficiencia_cardiaca' in hist:
        weight_gain=p.get('weight_gain_3d_kg')
        if isinstance(weight_gain,(int,float)) and weight_gain>2:
            alerts.append(alert('HF_GAIN','CONSULTA',f'IC previa y +{weight_gain:.1f} kg/3 días',
                                'Contactar equipo tratante; valorar retención de líquidos','ESC_HF'))
    if p.get('ppg_irregular') is True and p.get('ppg_quality_ok') is True:
        alerts.append(alert('SUSPECT_AF','CRIBADO','Irregularidad PPG reproducible',
                            'Solicitar ECG para confirmar o excluir FA','ESC_AF',confidence='sin ECG no hay diagnóstico'))

    alerts.sort(key=lambda r:(SEVERITY_RANK[r['severidad']],r['codigo']))
    return {'alertas':alerts,'abstenciones':abstentions,'evaluado_con':'Reglas demo 2026-11-14; NO para uso clínico'}

if __name__=='__main__':
    if len(sys.argv)>1:
        with open(sys.argv[1],encoding='utf-8') as fh: data=json.load(fh)
    else:
        data={ 'age_years':55, 'height_cm':170, 'weight_kg':94,'waist_cm':105,
          'pregnancy_status':'not_pregnant', 'sex_for_reference':'male',
          'bp': {'sbp':151,'dbp':92,'validated_cuff':True,'setting':'home','multi_reading_average':True},
          'pulse_ox':{'spo2':97,'clinically_validated':True,'resting':True,'reconfirmed':True,'quality_ok':True},
          'cgm':{'mg_dl':165,'quality_ok':True},'history':[],
          'labs':{'hba1c_pct':6.7}}
    print(json.dumps(evaluate(data),ensure_ascii=False,indent=2))
