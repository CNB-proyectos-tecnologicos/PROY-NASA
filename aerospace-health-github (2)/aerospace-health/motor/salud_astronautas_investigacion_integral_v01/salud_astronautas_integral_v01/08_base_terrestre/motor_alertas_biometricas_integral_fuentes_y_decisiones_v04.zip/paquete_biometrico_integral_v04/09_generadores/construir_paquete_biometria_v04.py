#!/usr/bin/env python3
"""Construye un paquete de documentación auditable a partir del catálogo v03.
No modifica los artefactos originales, no usa datos de pacientes y no valida clínicamente el producto.
Extractos breves con un solo fragmento por obra/fuente (<=25 palabras).
"""
import os, json, csv, re, math, zipfile, hashlib, collections, pathlib, sys, shutil, textwrap, datetime
P=pathlib.Path('/mnt/data/paquete_biometrico_integral_v04')
X=json.load(open(P/'01_originales/motor_alertas_catalogo_v03.json',encoding='utf8'))
rules=X['reglas']; ref_list=X['fuentes']

# Transcripción breve y localizable a partir de fuentes verificadas en web el 14-11-2026.
# Cada URL distinta tiene a lo sumo una cita literal corta (<=25 palabras), el resto son paráfrasis propias.
S=[
('S01','ADA_DX26','ADA Standards of Care 2026, Section 2 / Table 2.1', 'https://diabetesjournals.org/care/article/49/Supplement_1/S27/163926', 'A1C ≥6.5% (≥48 mmol/mol).', 'Prueba de laboratorio certificada; ausencia de hiperglucemia inequívoca exige confirmación.', 'CGM nunca sustituye la glucosa plasmática o HbA1c de diagnóstico.', 'A1C vs glucemia en ayunas vs OGTT; analizar interferencias de A1C.'),
('S02','ADA_GLY26','ADA Standards of Care 2026, Section 6 / Table 6.2','https://doi.org/10.2337/dc26-s006', '70% of time active out of 14 days', 'Mínimo de cobertura para evaluación de patrones CGM; los objetivos TIR/TBR tienen subpoblaciones distintas.', 'No inferir diabetes en personas sin diagnóstico previo; verificar datos faltantes y precisión del sensor.', 'HbA1c para control promedio; HbA1c no reproduce variabilidad ni hipoglucemia.'),
('S03','AHA_BP25','ACC/AHA 2025 hipertensión, categorías PA, Table 4','https://www.ahajournals.org/doi/10.1161/CIR.0000000000001356', 'stage 1 hypertension as 130 to 139 mm Hg systolic', 'Cifras para categorías en adultos, promediadas con protocolo; no extrapolar a PA continua no validada.', 'NICE maneja otro umbral confirmatorio fuera de consulta; separar jurisdicciones.', 'NICE NG136: HBPM promedio ≥135/85 tras PA de consulta elevada.'),
('S04','NICE_BP','NICE NG136, 1.2.7–1.2.8','https://www.nice.org.uk/guidance/ng136/chapter/Recommendations', 'blood pressure recording continues for at least 4 days, ideally for 7 days.', 'Promediar HBPM tras descartar el primer día; confirmar con técnica apropiada.', 'No mezclar 135/85 en HBPM con 130/80 como si representaran idéntico método.', 'AHA/ACC 2025 para clasificación por otro protocolo.'),
('S05','KDIGO24','KDIGO 2024 ERC, Practice Point 2.2.1, página S156','https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf', 'A 5-year kidney failure risk of 3%–5% can be used to determine need for nephrology referral', 'Sólo usar KFRE con ERC G3–G5 establecida y ACR urinaria válida.', 'Distinción entre derivación (3–5 % a 5 años) y preparación para TRR (horizontes diferentes).', 'eGFR y albuminuria; ecuaciones específicas de enfermedad en IgA o ADPKD.'),
('S06','NICE_SEPSIS','NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo)','https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk', 'Raised heart rate: more than 130 beats per minute', 'El cuadro es de SEPSIS SOSPECHADA, no un diagnóstico por FC aislada.', 'Prioridad ante deterioro general; síntomas, foco infeccioso, conciencia y FR no siempre disponibles.', 'NEWS2 donde exista frecuencia respiratoria, oxígeno suplementario y estado de conciencia.'),
('S07','UKKA_K26','UK Kidney Association 2026, Introduction / Hyperkalaemia severity','https://guidelines.ukkidney.org/hyperkalaemia/', 'mild (5.5-5.9 mmol/l), moderate (6.0-6.4 mmol/l) or severe (≥ 6.5 mmol/l)', 'K sérico requiere muestra válida, verificar hemólisis; ECG y evaluación clínica si urgencia.', 'No usar K intersticial inexistente; evolución renal y medicamentos importan.', 'Niveles comunitarios y hospitalarios, individualizar por manifestaciones clínicas.'),
('S08','WHO_HB24','OMS 2024, Table 3: Haemoglobin cutoffs / anaemia severity','https://www.ncbi.nlm.nih.gov/books/NBK602183/table/fm-ch1.tab2/', 'Adults, 15–65 years, nonpregnant women', 'Los cortes dependen de población, embarazo, trimestre y a veces altitud.', 'No extrapolar sin ajuste a embarazo o menores ni confundir anemia con etiología.', 'Investigación de ferropenia/hemólisis/deficiencias según hemograma y clínica.'),
('S09','AASM_OSA','AASM 2017, Good Practice Statements / Recommendations 1–2','https://pmc.ncbi.nlm.nih.gov/articles/PMC5337595/', 'Polysomnography is the standard diagnostic test for the diagnosis of OSA', 'Desaturación nocturna de reloj orienta estudio; no confirma apnea.', 'La saturación tiene artefactos; medir apnea-hipopnea requiere estudio validado.', 'Polisomnografía o prueba domiciliaria técnicamente adecuada.'),
('S10','FDA_SPO2','FDA Pulse Oximeters, February 2021 safety communication','https://www.fda.gov/medical-devices/products-and-medical-procedures/pulse-oximeters', 'poor circulation, skin pigmentation, skin thickness, skin temperature, current tobacco use, and use of fingernail polish', 'Los valores límite de SpO2 no son totalmente transportables entre dispositivos.', 'No usar origen étnico como sustituto de pigmentación ni compensación clínica arbitraria.', 'Repetir medición clínicamente fiable; gasometría si procede.'),
('S11','AHA_PREVENT','AHA PREVENT original model (2024), base equations','https://pmc.ncbi.nlm.nih.gov/articles/PMC10910659/', 'Predicting Risk of CVD Events', 'Probabilidad de desenlace cardiovascular en horizonte concreto, modelo estadounidense no necesariamente calibrado en México.', 'No se puede calcular sin tabaquismo, dislipidemia, medicación y función renal; no imputar negativos.', 'SCORE2/SCORE2-OP europeo; QRISK3 Reino Unido; recalibración propia local.'),
('S12','ACC_LIP26','ACC/AHA Dyslipidemia 2026, Section 4.2.3.7','https://www.jacc.org/doi/10.1016/j.jacc.2025.11.016', 'Low (<3%) Estimated 10-Year ASCVD Risk', 'Categorías sólo para PREVENT-ASCVD, no para PREVENT-HF o CVD-total.', 'No crear decisiones terapéuticas automáticas sin revisión médica.', 'Prevención primaria con LDL y preferencias clínico-paciente.'),
('S13','NIDDK_EGFR','NIDDK, eGFR Equations for Adults / 2021 CKD-EPI','https://www.niddk.nih.gov/research-funding/research-programs/kidney-clinical-research-epidemiology/laboratory/glomerular-filtration-rate-equations/adults', 'eGFR = 142 × min(SCr/κ,1)', 'Utilizar creatinina sérica calibrada (IDMS), y variable de sexo definida por el modelo.', 'La fórmula sin raza no es una probabilidad y su precisión varía con la fisiología.', 'CKD-EPI creatinina+cistatina C, o mGFR si decisión exige mayor precisión.'),
('S14','NICE_WHTR','NICE NG246, 1.9.14–1.9.15','https://www.nice.org.uk/guidance/ng246/chapter/Identifying-and-assessing-overweight-obesity-and-central-adiposity', 'keep their waist to less than half their height', 'Razón cintura/estatura <0.5 como referencia de adiposidad central (BMI<35 para esta clasificación).', 'No sustituye medición de grasa visceral ni diagnóstico metabólico.', 'Perímetro cintura y otras medidas corporales; curvas pediátricas distintas.'),
('S15','AASLD_FIB4','AASLD Practice Guidance 2023 (update MASLD 2024), Figure 2','https://pmc.ncbi.nlm.nih.gov/articles/PMC10735173/', 'FIB-4 should not be used in acutely ill patients.', 'FIB-4 es triage de fibrosis, no probabilidad individual; >65 requiere otro corte inferior.', 'Menores de 35 con baja precisión; ALT/AST agudas alteran el score.', 'EASL 2024 considera elastografía o intervención metabólica + repetición.'),
('S16','EASL_FIB4','EASL-EASD-EASO 2024 MASLD, Recommended strategy','https://pmc.ncbi.nlm.nih.gov/articles/PMC11299976/', 'FIB-4 will miss around 10% of individuals with advanced fibrosis', 'Evitar interpretar FIB-4 bajo como exclusión infalible; prevalencia importa.', 'No usar porcentajes individuales a partir de las tasas agregadas.', 'Elastografía VCTE, ELF, MRE, evaluación hepática.'),
('S17','NICE_B12_24','NICE NG239, Table 1 total or active B12','https://www.nice.org.uk/guidance/ng239/chapter/recommendations', 'Less than 180 nanograms (133 pmol) per litre', 'B12 total <180 ng/L indica deficiencia bajo contexto y analítica compatible; 180–350 indeterminado.', 'Cortes válidos para el método especificado; embarazo, dieta y síntomas alteran ruta.', 'B12 activa, ácido metilmalónico cuando corresponde.'),
('S18','AGA_IRON20','AGA 2020 Guideline, Recommendations point 1','https://gastro.org/clinical-guidance/gastrointestinal-evaluation-of-iron-deficiency-anemia/', 'cutoff of 45 ng/mL over 15 ng/mL', 'Ferritina <45 ng/mL se interpreta dentro de ANEMIA y evaluación de ferropenia.', 'La inflamación puede elevar ferritina; otros marcadores pueden ser necesarios.', 'Saturación transferrina, PCR, hierro sérico según contexto.'),
('S19','NICE_TSH','NICE NG145, recommendation 1.2.8','https://www.nice.org.uk/guidance/ng145/chapter/recommendations', 'if the TSH is above the reference range, measure free thyroxine (FT4) in the same sample', 'El diagnóstico requiere laboratorio, no FC, temperatura o ciclo por sí solos.', 'La biotina puede interferir con inmunoensayos.', 'FT4/FT3 según TSH y sospecha de enfermedad hipofisaria.'),
('S20','PCOS_GUIDE23','PCOS International Guideline 2023, diagnostic criteria','https://academic.oup.com/jcem/article/108/10/2447/7242360', 'Serum AMH should not be used as a single test for the diagnosis of PCOS.', 'Fase ovulatoria sola no diagnostica SOP; exige patrón, hiperandrogenismo y excluir otras causas.', 'Adolescentes tienen criterios distintos, AMH no recomendado para diagnóstico.', 'Rotterdam revisado con ecografía o AMH en adultos seleccionados.'),
('S21','ESC_AF','ESC 2024 AF guideline, key message 10','https://academic.oup.com/eurheartj/article/45/36/3314/7738779', 'CHA₂DS₂-VA ≥2 anticoagulation recommended', 'Aplicar únicamente si FA está confirmada; score NO ofrece probabilidad calibrada por sí solo.', 'PPG no diagnostica FA; decisión de anticoagulación es médica.', 'CHA₂DS₂-VASc, herramientas locales validadas y riesgo hemorrágico.'),
('S22','AHA_PREG','ACC/AHA 2025, Table 21, hypertension pregnancy','https://www.jacc.org/doi/10.1016/j.jacc.2025.05.007', 'Severe-range hypertension SBP ≥160 mm Hg', 'Ruta obstétrica independiente, requiere estado de embarazo y semana gestacional.', 'No inferir embarazo a partir de fase ovulatoria.', 'ACOG preeclampsia: PA, proteinuria o disfunción orgánica, cronología.'),
('S23','NOM241_MX','NOM-241-SSA1-2025, numerales 3.118, 11.16','https://sidof.segob.gob.mx/notas/docFuente/5754074', 'Software como dispositivo médico (ScDM)', 'El uso previsto de alertas de salud puede activar obligaciones regulatorias.', 'No asuma que etiquetar la app como bienestar evita el régimen sanitario.', 'Consulta regulatoria COFEPRIS, evaluación de clasificación y expediente técnico.'),
('S24','NOM137_MX','NOM-137-SSA1-2025, numeral 6.3','https://sidof.segob.gob.mx/notas/docFuente/5787790', 'Software como dispositivo médico (ScDM)', 'Versionado, identificación e instrucciones de uso en producto final, según procedencia.', 'No atribuir vigencia sin comprobar Diario Oficial y entrada en vigor.', 'Mecanismos de etiquetado electrónico, avisos y control de versiones.'),
('S25','PROBAST_AI','PROBAST+AI 2025, four domains','https://www.bmj.com/content/388/bmj-2024-082505', 'participants, predictors, outcome, and analysis', 'La precisión de un modelo no implica ausencia de sesgo o aplicabilidad.', 'Validación independiente por centros, sensores, grupos demográficos y sexo.', 'TRIPOD+AI para reporte; evaluación de sesgo PROBAST+AI.'),
('S26','FDA_GMLP','FDA Good Machine Learning Practice / 10 principles','https://www.fda.gov/medical-devices/artificial-intelligence-enabled-medical-devices/good-machine-learning-practice-medical-device-development-guiding-principles', 'safe, effective, and high-quality medical devices', 'Validación del ciclo de vida: monitorización de deriva, control cambios, humana supervisión.', 'La implementación de reglas no reduce automáticamente obligaciones de seguridad.', 'Registro de decisión y control de versiones.'),
('S27','CDC_BMI24','CDC Adult BMI categories','https://www.cdc.gov/bmi/adult-calculator/bmi-categories.html', 'Adult BMI Categories', 'El IMC indica categoría antropométrica, no composición corporal ni enfermedad diagnosticada.', 'No aplicar puntos de corte de adulto a menores o embarazo.', 'Cintura-talla, circunferencia y valoración funcional.'),
('S28','NKF_EGFR_CYS','NKF CKD-EPI creatinine-cystatin 2021','https://www.kidney.org/professionals/ckd-epi-creatinine-cystatin-equation-2021', 'CKD-EPI Creatinine-Cystatin Equation (2021)', 'Al añadir cistatina C se dispone de estimación renal alternativa en contexto adecuado.', 'No intercambiar unidades mg/L de cistatina C y mg/dL de creatinina.', 'mGFR o panel renal ampliado si hay alta incertidumbre.'),
('S29','PCOS_NORDIC','PCOS Nordic 2023 diagnostic review, adult and adolescent differences','https://obgyn.onlinelibrary.wiley.com/doi/10.1111/aogs.14725', 'In adolescents, both ovulatory dysfunction and hyperandrogenism are mandatory.', 'Separa criterios adultos y adolescentes; los usuarios sin datos de síntomas requieren abstención.', 'No usar supuesta ovulación como sustituto de pruebas endocrinas.', 'Confirmar con clínica, laboratorios y exclusiones.'),
('S30','PREVENT_AHA','AHA Professional PREVENT calculator', 'https://professional.heart.org/en/guidelines-and-statements/prevent-calculator', 'PREVENT', 'En prevención primaria se debe comparar implementación local con calculadora oficial en múltiples casos.', 'No dar porcentajes si faltan predictores; recalibrar para población mexicana.', 'Versiones con predictores adicionales y horizontes alternativos según disponibilidad.'),
]
# Ensure no cited source contains overly long verbatim excerpt.
for x in S:
 q=x[4]; assert len(q.split())<=25,(x[0],len(q.split()))
assert len(set(t[3] for t in S))==len(S), 'Duplicated URLs in quotes could exceed source quotation limit.'
with (P/'02_literatura/extractos_verificados.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.writer(f);w.writerow(['ID','FUENTE_ID','SECCION_LOCALIZABLE','URL','EXTRACTO_LITERAL_EN_ORIGINAL','PARAFRASIS_CRITERIO','JUSTIFICACION_DE_USO','LIMITACIONES','ALTERNATIVAS'])
 for sid,alias,sec,url,q,meaning,limit,altern in []:pass
 for sid,alias,sec,url,q,meaning,limit,altern in S:
  w.writerow([sid,alias,sec,url,q,meaning,'Conservar el criterio de la fuente restringido a la población y modalidad indicadas.',limit,altern])

smd=['# Extractos literales breves y valoración de evidencia','',
'**Fecha de consulta:** 14-11-2026. Se conserva un fragmento literal verificable por obra (máximo 25 palabras), su ubicación, URL, interpretación y motivo de inclusión. El acceso a los párrafos completos se hace mediante URL y localizador. Los criterios resumidos NO reemplazan el texto de la guía.','',
'Los fragmentos están en el idioma original del documento; no se hacen pasar traducciones por citas literales. No se han descargado ni redistribuido íntegramente obras protegidas.','']
for sid,alias,sec,url,q,meaning,limit,altern in S:
 smd.extend([f'## {sid}. {alias} — {sec}','',f'**Fuente:** {url}',f'**Cita literal breve:** “{q}”','',f'**Qué aporta:** {meaning}','',f'**Justificación de incorporación:** {limit}','',f'**Alternativas/confirmación:** {altern}','','**Verificación:** fuente y pasaje identificados, pero no implica que cada variante derivada del catálogo reproduzca literalmente la guía.',''])
(P/'02_literatura/EXTRACTOS_Y_VALORACION.md').write_text('\n'.join(smd),encoding='utf8')

# Linking of legacy IDs to verified snippets; source-based traceability not equivalent to rule-level verification.
byid={s[1]:s[0] for s in S}
link_map={
 'ADA26':'S01','ADA_GDM26':'S01','ADA_DX26':'S01','ADA_GLY26':'S02','ADA_GLY24':'S02','ADA_HOSP26':'S02',
 'AHA_BP25':'S03','NICE_BP25':'S03','ESC_BP24':'S04','NICE_SEPSIS':'S06','KDIGO24':'S05','KDIGO_CKD24':'S05',
 'UKKA_K26':'S07','UKKA_K23':'S07','WHO_HB24':'S08','WHO_HBSEV24':'S08','AASM_OSA':'S09','AASM_SLEEPMED':'S09',
 'FDA_SPO2':'S10','AHA_PREVENT':'S30','PREVENT_PAPER24':'S11','ACC_LIP26':'S12','ACC_DYSLIP26':'S12','NIDDK_EGFR':'S13',
 'NICE_WHTR':'S14','NICE_OBESITY':'S14','AASLD_FIB4':'S15','ACG_FIB4':'S15','AASLD_MASLD':'S15',
 'NICE_B12':'S17','NICE_B12_24':'S17','AGA_FERR':'S18','AGA_IRON20':'S18','NICE_TSH':'S19',
 'PCOS_GUIDE23':'S20','PCOS23':'S20','ESC_AF':'S21','ESC_AF24':'S21','ACOG_PREE':'S22','ACOG_BP':'S22',
 'CDC_BMI24':'S27','WHO_BMI':'S27'
}
source_by_id={s['id']:s['url'] for s in ref_list}
by_sid={s[0]:s for s in S}
row_map=[]
for r in rules:
 sid=link_map.get(r['fuente_id'])
 anchor=by_sid[sid] if sid else None
 # Extra caution: all previously assembled rules require specific verification.
 if r['estado_evidencia']=='EXPERIMENTAL_NO_VALIDADA': classif='SOLO_INVESTIGACION_DESACTIVADA'
 elif r['estado_evidencia']=='DERIVADA_NO_VALIDADA': classif='REGLA_DERIVADA_PENDIENTE_VALIDACION'
 else: classif='CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO'
 words=r['criterio_SI'].lower()
 caution=[]
 if 'cgm' in (r['variables_necesarias']+' '+r['criterio_SI']).lower() or r['dominio']=='Glucosa':caution.append('CGM=intersticial, no prueba diagnóstica de diabetes')
 if r['dominio'] in ('Presión arterial','Cardiovascular agudo','Embarazo'):caution.append('PA: manguito validado y protocolo; embarazo separado')
 if r['dominio'] in ('Infecciones','Deterioro sistémico'):caution.append('no atribuir a sepsis sin sospecha de infección y signos adicionales')
 if r['dominio'] in ('Ritmo cardiaco',):caution.append('ECG requerido para diagnosticar fibrilación auricular')
 if r['dominio']=='Respiratorio':caution.append('oxímetro puede producir errores; diagnóstico de SAOS exige estudio')
 if r['dominio']=='Hígado':caution.append('FIB-4 no es porcentaje; no durante enfermedad aguda; ajustar por edad')
 if r['dominio']=='Riñón':caution.append('repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5')
 if r['dominio']=='Hematología':caution.append('Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata')
 if r['dominio']=='Reproductivo':caution.append('fase del ciclo observada/estimada ≠ prueba diagnóstica hormonal')
 if r['dominio']=='Electrolitos':caution.append('revisar hemólisis, recolección, laboratorio y contexto')
 if r['riesgo_formato'].startswith('PROBABILIDAD'):
  caution.append('comparar salida del modelo con calculadora original y calibración local; no porcentaje arbitrario')
 if r['estado_evidencia']!='UMBRAL_GUIA': caution.append('combinación NO validada: manténgase apagada hasta estudio')
 if not caution:caution.append('confirmar que indicador, protocolo y población coinciden exactamente con la fuente')
 row_map.append({
  'id_regla':r['id'],'dominio':r['dominio'],'condicion':r['condicion'],
  'criterio':r['criterio_SI'],'tipo_evidencia_declarado_v03':r['estado_evidencia'],
  'estado_verificacion_regla_v04':classif,'fuente_v03':r['fuente_id'],
  'url_v03':r['fuente_url'],'id_extracto_relacionado':sid or 'SIN_EXTRACTO_VERIFICADO',
  'url_fuente_extracto':anchor[3] if anchor else '',
  'seccion_para_revision':anchor[2] if anchor else 'PENDIENTE',
  'justificacion_tecnica_candidata':'Alerta que cuantifica patrón/exposición o sugiere comprobación bajo condiciones de calidad; NO predice por sí sola probabilidad de diagnóstico.',
  'limitaciones_explicitas':' | '.join(caution),
  'datos_faltantes':'NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental',
  'activacion_productiva':'NO hasta revisión de criterio, pruebas y comité clínico',
  'poblacion':r.get('poblacion',''),'ventana':r.get('ventana',''),
  'riesgo_formato':r.get('riesgo_formato',''),
  'horizonte':r.get('horizonte_probabilidad',''),
  'modelo_probabilidad_calibrada':r.get('es_probabilidad_calibrada',False),
 })
with (P/'04_trazabilidad/REGLAS_TRAZABILIDAD_512.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(row_map[0]));w.writeheader();w.writerows(row_map)
(P/'04_trazabilidad/REGLAS_TRAZABILIDAD_512.json').write_text(json.dumps(row_map,ensure_ascii=False,indent=2),encoding='utf8')

cards=['# Fichas de trazabilidad y evaluación de las 512 reglas','',
'Cada ficha reproduce la especificación v03 y añade justificación pública de ingeniería. **No es una reconstrucción del razonamiento interno del modelo; es un registro de decisiones de diseño verificables y riesgos.**','',
'**Estado:** todo el catálogo queda en revisión; los extractos asociados prueban sólo un enunciado fuente, no la concordancia de cada regla compleja. Las heurísticas derivadas y experimentales requieren estudios independientes.','']
for r,row in zip(rules,row_map):
 cards.extend([f'## {r["id"]}: {r["condicion"]} ({r["dominio"]})','',
 f'- **SI:** {r["criterio_SI"]}',f'- **ENTONCES:** {r["resultado_ENTONCES"]}',
 f'- **Variables:** {r["variables_necesarias"]}; disponibilidad {r["disponibilidad"]}.',
 f'- **Ventana:** {r["ventana"]}; **Población:** {r["poblacion"]}.',
 f'- **Prioridad:** {r["severidad"]}; **Naturaleza:** {r["tipo_inferencia"]}.',
 f'- **Confirmación necesaria:** {r["prueba_confirmatoria"]}.',
 f'- **Fuente declarada v03:** {r["fuente_id"]} — {r["fuente_url"]}.',
 f'- **Pasaje breve relacionado:** {row["id_extracto_relacionado"]}; **ubicación:** {row["seccion_para_revision"]}.',
 f'- **Clasificación original:** {r["estado_evidencia"]}; **revisión v04:** {row["estado_verificacion_regla_v04"]}.',
 f'- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.',
 f'- **Supuestos que deben comprobarse:** {row["limitaciones_explicitas"]}.',
 f'- **Qué se decide ante datos ausentes:** {row["datos_faltantes"]}.',
 f'- **Riesgo cuantitativo reportable:** {r["riesgo_formato"]}; horizonte: {r["horizonte_probabilidad"]}; porcentaje calibrado: {str(r["es_probabilidad_calibrada"]).lower()}.',
 f'- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.',
 f'- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.',
 f'- **Decisión para producción:** {row["activacion_productiva"]}.',''])
(P/'04_trazabilidad/FICHAS_ANOTADAS_512_REGLAS.md').write_text('\n'.join(cards),encoding='utf8')

# Source register, state is *source level* not individual criterion verification.
with (P/'02_literatura/REGISTRO_DE_61_FUENTES.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.writer(f);w.writerow(['ID_CATALOGO','URL_REGISTRADA','ESTADO','EXTRACTO_RELACIONADO','URL_VERIFICADA_ALTERNATIVA','NOTA'])
 for s in ref_list:
  sid=link_map.get(s['id']);obj=by_sid.get(sid)
  w.writerow([s['id'],s['url'],('PASO_FUENTE_CONTRASTADO_NO_CADA_REGLA' if sid else 'SOLO_REGISTRO_HEREDADO_SIN_VERIFICACION_INDIVIDUAL'),sid or '',obj[3] if obj else '',
  'La coincidencia es temática, no verificación automática de cada valor; comprobar página, versión y fecha.' if sid else 'Referencia heredada; puede estar obsoleta/duplicada/no corresponder al criterio.'])

# More narrative docs filled separately below.
print('Evidence snippets:',len(S),'rules:',len(rules),'links:',sum(bool(z['id_extracto_relacionado']!='SIN_EXTRACTO_VERIFICADO') for z in row_map))
