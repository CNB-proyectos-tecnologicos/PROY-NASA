# Protocolo mínimo para pasar de 512 reglas candidatas a alertas clínicamente utilizables

## 1. Objeto de estudio

Diseñar una herramienta de apoyo que detecte patrones de deterioro o indique cribado/consulta **sin atribuir diagnósticos indebidamente**. Subestudios diferentes por desenlace (hipoglucemia, FA confirmada por ECG, lesión renal aguda, sepsis sospechada, descompensación de insuficiencia cardiaca, evolución renal, etc.), porque no tienen la misma prevalencia, patrón temporal, consecuencia ni verificación.

## 2. Diseño en etapas

- E0 documental: médico(s) de especialidad revisan cada condición, exclusión, unidad, versión y el pasaje de guía con sección precisa. Cada regla recibe `ACCEPTED`, `REJECTED`, `DERIVED_RESEARCH` o `PENDING` y sus firmas.
- E1 analítico: pruebas de algoritmos de señal, conversiones y artefactos en bancos de referencia; no usar pacientes en esta etapa.
- E2 validación retrospectiva con cohortes multicéntricas, temporalmente independientes, desenlaces adjudicados y sensores etiquetados. No mezclar observaciones de un mismo paciente entre particiones.
- E3 evaluación prospectiva silenciosa: motor ejecutándose SIN alertar a pacientes. Cuantificar activaciones, falsos positivos, sensibilidad, deficiencias de datos y población fuera de rango.
- E4 estudio prospectivo de implementación: con comité ético, plan de gestión de riesgo, profesionales responsables, evaluación de intervenciones y de daño por fatiga de alarmas.
- E5 mantenimiento regulado: monitorización de deriva, incidentes adversos, cambios de firmware/sensores, recalibración y control de versiones. Volver a E2/E3 ante modificaciones relevantes.

## 3. Muestreo y calidad

Medir disponibilidad real de cada campo y su variabilidad por región, hospital, atención primaria, smartphone, sensor, fabricante y firmware. Para cada registro: timestamp con zona horaria, unidad, dispositivo, versión, técnica, calibración, modo, reposo/postura, calidad, movimiento, uso de medicamentos, procedencia de dato, alteración aguda y si el valor es externo o calculado. Ausencia NO es valor normal. Falsos datos plausibles son igual de peligrosos que datos ausentes.

Definir horizonte y referencia clínica antes de entrenar; ejemplo FA en 30 días debe confirmarse por ECG y ser adjudicada; hipoglucemia debe confirmarse según plan clínico cuando CGM es discordante; sepsis necesita sospecha clínica + criterio de referencia, no sólo FC/PA anómalas.

## 4. Estimación de métricas

| Fase | Indicador | Por qué se requiere |
|---|---|---|
| Analítica | Sensibilidad y especificidad por evento | Positivos/negativos correctos según referencia |
| Analítica | Falsas alarmas por 100 paciente-días | Carga real de notificaciones |
| Analítica | Retardo de detección y anticipación | Relevancia temporal de alerta |
| Analítica | PPV/NPV e intervalos | Son funciones de prevalencia, no propiedades universales |
| Modelo probabilístico | AUROC, AUPRC | Discriminación, relevante en clases raras |
| Modelo probabilístico | Brier, pendiente e intercepto calibración | Evita asignar porcentajes no fiables |
| Modelo probabilístico | Curvas de decisión y beneficio neto | Utilidad clínica de umbrales |
| Inclusión | Cobertura, abandono, missingness | Identifica selectividad de datos |
| Equidad | Sensibilidad, error y calibración por grupo | Detecta disparidades por dispositivo y población |
| Seguridad | Notificaciones repetidas y errores de precedencia | Detecta fatiga y cancelación indebida de alertas |

Todos los intervalos y errores de muestreo deben calcularse sobre unidades independientes o por bootstrap agrupado. Para alertas longitudinales, pacientes, centros y días están correlacionados; no asumir independencia entre lecturas cada cinco minutos. Reportar censura y eventos competidores para predicciones de riesgo.

## 5. Manejo de ausentes y abstención

Comprobar tres tipos de ausencia: `PREDICTOR_INEXISTENTE`, `DATOS_OBSOLETOS` y `MEDICION_NO_VALIDADA`. Cuando falta un predictor esencial, conservar la regla como `NO_EVALUABLE` y mostrar qué prueba faltante hace falta. Un score de severidad no se debe recalcular tras rellenar faltantes con ceros. Los casos fuera de población de validación tienen estado `FUERA_DE_POBLACION`.

## 6. Regulación y privacidad — México

El software que ofrece indicaciones para detectar, diagnosticar, monitorizar o predecir enfermedades puede quedar comprendido dentro del **Software como Dispositivo Médico** según su uso previsto; revisar NOM-241-SSA1-2025, numerales 3.118 y 11.16, y NOM-137-SSA1-2025, numeral 6.3. La clasificación, obligaciones y autorizaciones aplicables deben verificarse con un especialista regulatorio y COFEPRIS, no decidirse por la documentación de este prototipo.

Fuentes: https://sidof.segob.gob.mx/notas/docFuente/5754074 ; https://sidof.segob.gob.mx/notas/docFuente/5787790 ; https://www.gob.mx/cofepris/documentos/registros-dispositivos-medicos

Los datos clínicos y biométricos exigen controles reforzados: consentimiento/otra base jurídica pertinente, minimización de datos, segregación de identidades, acceso por funciones, auditoría de consultas y cambios, cifrado en tránsito y reposo, retención limitada, eliminación controlada, minimización de exportaciones y seguimiento de incidentes. Revisar legislación mexicana de datos personales vigente para el tipo concreto de responsable (particular/sujeto obligado); las leyes no son idénticas.

## 7. Matriz de severidad clínica

No dar tratamientos autónomos ni prometer diagnóstico. Niveles operativos a revisar con comité: `CRITICA` para potencial emergencia clínica confirmada con fuente/calidad adecuada; `URGENTE` para evaluación breve; `CONSULTA` para valoración programada; `CRIBADO` para prueba confirmatoria; `SEGUIMIENTO` para tendencias; `NO_EVALUABLE` si faltan requisitos. Una PA cuffless nunca activa criterios diagnósticos de HTA por sí sola; un valor severo sospechoso debe solicitar comprobación y no silenciarse sin avisar sobre la posibilidad de artefacto. Ninguna alerta probabilística puede anular una alerta fisiológica aguda.

## 8. Límites de la arquitectura de datos original

Con las medidas enumeradas NO se pueden diagnosticar directamente: ictus agudo (sin examen neurológico), infarto de miocardio (sin ECG/troponinas), embolia pulmonar (sin evaluación/imagen), apnea del sueño (sin estudio), infecciones específicas (sin evaluación causal), cáncer en general, enfermedades autoinmunes, depresión, trastornos de coagulación sin pruebas, diabetes con sólo CGM, embarazo sin prueba, función ovárica con sólo calendario. Es legítimo recomendar valoración o prueba adicional ante combinaciones sugestivas; no declarar una enfermedad confirmada.

## 9. Checklist de liberación

1. Ficha de propósito médico y población firmada.
2. Matriz 512/512 con fuente y fecha; variantes de regla con versión y aprobador.
3. Test de unidad de cada cálculo y equivalencia dimensional.
4. Casos límite: edad 18/30/35/65/75/79, embarazo, diálisis, FA no confirmada, sensoriales invalidos.
5. Validación en modo silencioso con métricas por paciente y por cohorte.
6. Umbrales de intervención derivados de beneficio/daño, NO exclusivamente de maximizar AUROC.
7. Revisión de sesgos por grupo, dispositivos y centros.
8. Plan de retiro/reversión (`kill switch`) de reglas por incidentes y deriva.
9. Evaluación regulatoria y de protección de datos.
10. Mecanismo de explicación para clínico: dato, fecha, calidad, criterio, referencia, motivo de alerta y prueba confirmatoria.

**Referencias metodológicas:** PROBAST+AI https://www.bmj.com/content/388/bmj-2024-082505 ; TRIPOD+AI (buscar su publicación oficial actual antes de incluir como norma específica); FDA GMLP https://www.fda.gov/medical-devices/artificial-intelligence-enabled-medical-devices/good-machine-learning-practice-medical-device-development-guiding-principles
