# Paquete integral de alertas biométricas: catálogo, evidencia, decisiones, fórmulas y auditoría

**Edición:** v04, 14 de noviembre de 2026. **Idioma de las anotaciones:** español. **Naturaleza:** investigación y prototipado; **no apto para diagnóstico o alertas médicas autónomas en producción**.

## Contenido esencial

| Carpeta | Qué contiene | Para quién |
|---|---|---|
| `01_originales/` | Todos los artefactos previos recuperados del entorno: Excel v02/v03, JSON v02/v03, CSV v02/v03, calculadoras, casos de prueba y scripts de construcción | Desarrollo y reproducibilidad |
| `02_literatura/` | 30 extractos literales BREVES con enlaces, apartado exacto, comentario, alternativas; registro de 61 fuentes heredadas con nivel de verificación | Revisión médica/documental |
| `03_decisiones/` | 60 decisiones explícitas con justificación, alternativas y pruebas exigidas; semántica DSL/abstención | Arquitectura y auditoría |
| `04_trazabilidad/` | 512 fichas individuales, matriz de trazabilidad CSV y JSON | Revisión regla por regla |
| `05_modelos/` | Formulación matemática, modelos alternativos, incertidumbre, distribuciones y calibración | Bioestadística |
| `06_validacion/` | Protocolo para validación retrospectiva, prospectiva, regulación, equidad y privacidad | Responsable clínico/regulatorio |
| `07_pruebas/` | 8 tests ejecutables de humo para modelos originales | Ingeniería |
| `08_auditoria/` | Informe de consistencia, 512 flags por regla y estadísticas | Gestión de riesgos |
| `09_generadores/` | Scripts que crearon los extractos, las 512 fichas y el informe automático; tienen rutas `/mnt/data` propias del entorno de elaboración | Reproducción de la documentación |
| `MANIFIESTO_SHA256.json` | Hash de cada archivo para integridad | Control documental |

## Magnitudes verificadas automáticamente

- **512 reglas** v03 en 24 dominios. Conserva v02 con 128 reglas.
- **287** previamente rotuladas «umbral de guía», **185** derivadas no validadas y **40** experimentales no validadas. Etiqueta heredada NO equivale a validación individual de la regla compuesta.
- **265 variables/campos** en el diccionario, **20 antecedentes**, **20 secuelas** y **10 índices/modelos** descritos en el catálogo heredado.
- **61 referencias/IDs**, que representan **49 URLs distintas**, además de fuentes añadidas en el anexo. Hay fuentes heredadas y alias duplicados.
- **30 pasajes breves consultados y contextualizados**, asociados de manera temática a 437 reglas. En 75 no se adjunta pasaje localizado; en ninguna el vínculo temático confirma automáticamente todo el criterio de la regla.
- **384 reglas adicionales v03** contienen una ventana genérica que DEBE especificarse en un DSL ejecutable antes de cualquier uso.
- **8 pruebas** de humo (no validez clínica) de los modelos ejecutaron correctamente en el entorno de construcción.

## Por qué no hay párrafos largos reproducidos de literatura

Los artículos y guías publicados tienen condiciones de reproducción diferentes. Para respetar el texto protegido, este paquete incorpora **fragmentos literales breves** de hasta 25 palabras por fuente, acompañados por URL verificable, localizador de sección/página, explicación en español y limitaciones. **Se adjuntan vínculos a los párrafos completos, no copias extensas del texto original.** Es posible solicitar permiso de reproducción/licencias cuando sea estrictamente necesario incorporar una publicación íntegra.

## Guía de lectura técnica

1. Comenzar por `08_auditoria/INFORME_AUDITORIA.md`, porque muestra qué NO está validado.
2. Buscar condición o id en `01_originales/catalogo_alertas_biometricas_v03.xlsx`, luego la misma `rule_id` en `04_trazabilidad/REGLAS_TRAZABILIDAD_512.csv`.
3. Revisar la ficha en `04_trazabilidad/FICHAS_ANOTADAS_512_REGLAS.md`.
4. Consultar el pasaje y su fuente completa en `02_literatura/EXTRACTOS_Y_VALORACION.md`.
5. Leer la alternativa/justificación técnica en `03_decisiones/` y `05_modelos/`.
6. Sólo después de validación médica, definir predicados tipados, intervalos, metadatos de sensor y pruebas de regresión.

## Ejecución local

Con Python 3, sin dependencias añadidas:

```bash
python3 07_pruebas/test_modelos_referencia.py
```

Importar calculadoras en un script desde `01_originales/modelos_riesgo_clinico_v03.py`. `motor_alertas_demo.py` es una DEMOSTRACIÓN de algunas reglas, no evaluador de las 512.

## Principios de cuantificación

- PREVENT y KFRE: porcentaje de evento futuro con población/horizonte y predictores completos, sujeto a calibración local.
- FIB-4, CHA₂DS₂-VA, CKD-EPI: score, clasificación o medición de función, nunca porcentaje automático de enfermedad.
- CGM, presión, SpO2 y FC: exposiciones y tendencias, susceptibles a artefacto; una alerta con valor clínico no necesita inventar una probabilidad.
- Para cualquier variable ausente o sensor inadecuado: `NO_EVALUABLE`, no `NO_RIESGO`.

## Temas pendientes antes de cualquier uso asistencial

1. Anclar el valor y condición EXACTOS de las 512 reglas a pasajes de la guía y conservar aprobación clínica por regla.
2. Convertir las 384 ventanas genéricas y los 512 criterios en sintaxis tipada ejecutable.
3. Corregir formalmente el corte de FIB-4 a la edad frontera 65 y revisar versiones/rangos de modelos.
4. Comprobar contra calculadoras oficiales y cohortes locales los porcentajes; no presentar intervalos de incertidumbre ficticios.
5. Asegurar equipos médicos y calidad documental de PA/glucosa/oximetría; diferenciar PPG de ECG.
6. Evaluar normativa COFEPRIS y protección de datos.

## Uso ético

No contiene información de pacientes, no adjunta expedientes, ni se han usado registros individuales. Cualquier sistema de monitoreo humano debe contar con autorización, controles de acceso, información clínica de procedencia verificable y responsable de respuesta a las alertas.
