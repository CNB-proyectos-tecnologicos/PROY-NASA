# Fórmulas, alternativas estadísticas, distribuciones empíricas y límites de validez

**Estado:** especificación de investigación, 14 de noviembre de 2026. Los modelos clínicos ya implementados se conservan SIN modificaciones en `01_originales/modelos_riesgo_clinico_v03.py`. El contenido de este anexo documenta alternativas y pruebas; no significa que dichas alternativas estén entrenadas ni validadas.

## 1. La pregunta probabilística debe estar perfectamente definida

Antes de introducir números de riesgo elegir `desenlace`, `población`, `instante de inicio`, `horizonte`, `política de intervención` y `datos disponibles`.

\[
p_t(x)=P(T_{\mathrm{evento}}\le t\mid X(t_0)=x,\,\mathcal P,\,\mathcal I),
\]

donde `\mathcal P` es la población de destino y `\mathcal I` el régimen de intervención. La probabilidad de insuficiencia renal que requiere tratamiento sustitutivo antes de cinco años no es intercambiable con «tener enfermedad renal» ni con «presentar creatinina elevada». La intervención cambia el riesgo y la distribución observada no es inmutable.

Separar cuatro salidas: **probabilidad del desenlace** (si existe modelo calibrado), **puntuación clínica**, **intensidad/exposición a una anomalía**, **prioridad de respuesta**. No convertir unas en otras sin puente de calibración validado.

## 2. Ecuaciones existentes que sí generan porcentajes absolutos

### 2.1 PREVENT-AHA

En la implementación base de 10 años, la estructura es una regresión logística específica de sexo y desenlace:

\[
\eta=\beta_0+\sum_{j=1}^p\beta_j f_j(x),\qquad P(Y_{10}=1\mid x)=\frac{1}{1+e^{-\eta}}.
\]

Los términos `f_j` incluyen transformaciones a tramos, normalizaciones, términos de interacción con edad, tratamientos y variables lipídicas/renales, como se aprecia en `modelos_riesgo_clinico_v03.py`. **No** implementar una logística sencilla con coeficientes ad hoc: usar coeficientes EXACTOS del modelo y pruebas contra calculadora oficial y casos publicados.

- Variables obligatorias base (según componente): edad 30–79, variable de sexo usada por la ecuación, presión sistólica, colesterol total, HDL, diabetes, tabaquismo, medicación antihipertensiva, estatinas y eGFR; IMC en salida HF. No confundir antecedentes de diabetes con HbA1c aislada.
- Población de derivación estadounidense, sin ECV previa para prevención primaria; predicción no calibrada necesariamente en México.
- Desenlaces **separados**: CVD total, ASCVD e insuficiencia cardiaca, con interceptos/coeficientes distintos. En ningún caso sumar las tres probabilidades (los eventos se superponen).
- Horizonte alternativo: existen versiones 30 años y versiones opcionales con otros predictores; **no implementadas en el archivo original**. El horizonte debe constar explícitamente.
- Etnicidad: PREVENT no requiere clasificador racial; no añadir multiplicadores étnicos inventados. Ver guía 2026 ACC/AHA, Table 11.
- Calibración: contrastar por deciles o curvas continuas en población mexicana; si hay descalibración, considerar \(\operatorname{logit}(p_{nuevo})=\alpha+\gamma\operatorname{logit}(p_{original})\), estimados con desenlaces y validación externa.

**Fuentes:** https://pmc.ncbi.nlm.nih.gov/articles/PMC10910659/ ; https://www.jacc.org/doi/10.1016/j.jacc.2025.11.016 ; https://professional.heart.org/en/guidelines-and-statements/prevent-calculator

**Alternativas posibles, no intercambiables:** SCORE2 y SCORE2-OP (regiones europeas), QRISK3 (población británica), Pooled Cohort Equations (modelo histórico estadounidense), Framingham (cohortes históricas). Elegir según población, desenlace, tratamiento, estratos de edad y validación externa; no por la sola mayor cantidad de variables.

### 2.2 KFRE — ecuación de riesgo de falla renal a dos y cinco años

La forma matemática del modelo de supervivencia es:

\[
P(\text{falla renal en }t\mid X)=1-S_0(t)^{\exp(\eta)},
\]

con predictor lineal \(\eta\) construido a partir de edad, sexo del modelo, eGFR y logaritmo de uACR, centrados según el modelo publicado. `S_0(t)` es distinto para 2 y 5 años y puede requerir recalibración regional. Los coeficientes y supervivencias de referencia están en el archivo de Python; **es obligatorio corroborarlos contra la publicación específica antes de despliegue**.

- Aplicación: ERC G3–G5 clínicamente confirmada, no pacientes en diálisis. Por ejemplo, eGFR aislada 35 no confirma cronicidad sin contexto y persistencia.
- El riesgo es de FALLA RENAL CON TRATAMIENTO SUSTITUTIVO, no incidencia de ERC ni «riesgo de muerte por falla renal».
- Umbrales KDIGO 2024: riesgo KFRE a 5 años 3–5 % como señal orientativa de derivación; a 2 años >10 % para organizar atención multidisciplinaria; >40 % a 2 años para planificación de modalidad. Son **umbrales de gestión asistencial**, no sensibilidades/especificidades universales.
- Riesgo competidor: personas que fallecen por otras causas antes de falla renal no necesariamente se modelan igual con todos los enfoques; comparar con análisis de riesgos competitivos cuando proceda.

**Fuentes:** https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf (Practice Points 2.2.1–2.2.4); https://jamanetwork.com/journals/jama/fullarticle/2481005

**Alternativas:** KFRE 8 variables si están disponibles y poblaciones pertinentes; modelos específicos para nefropatía por IgA y riñón poliquístico; modelos de progresión G1–G2 (no aplicar KFRE G3–G5 allí).

## 3. Índices que NO son probabilidades de enfermedad

### 3.1 FIB-4: fibrosis hepática, selección para segunda prueba

\[
\mathrm{FIB4}=\frac{\operatorname{edad(años)}\operatorname{AST(U/L)}}{\operatorname{plaquetas}(10^9/L)\sqrt{\operatorname{ALT(U/L)}}}.
\]

Para adultos en población de riesgo MASLD, FIB-4 <1.3 suele orientar bajo riesgo (umbral inferior 2.0 si >65 según guías), 1.3–2.67 es la franja que motiva evaluación secundaria, >2.67 mayor sospecha y valoración especializada. No usar de modo indiscriminado en menores de 35 ni enfermedad aguda. En función del ámbito y la prevalencia, una fracción significativa de casos avanzados podría quedar sin identificar; EASL 2024 reporta alrededor de 10 % en su discusión de la estrategia de cribado. Ese 10 % es una propiedad poblacional de la ruta, NO probabilidad individual de cada FIB-4 bajo.

**Control de implementación detectado:** el código heredado usa `edad>=65`, pero las fuentes citadas expresan `older than age 65` o `>65` para el umbral de 2.0. Tratar exactamente edad 65 como frontera pendiente de revisión clínica; no modificar el original en silencio.

**Alternativas/seguimiento:** elastografía transitoria VCTE; ELF sérico; MRE; combinación secuencial; revaloración de aminotransferasas/imagen y de factores metabólicos. Un resultado FIB-4 positivo no equivale a diagnóstico de cirrosis.

Fuentes: https://pmc.ncbi.nlm.nih.gov/articles/PMC10735173/ ; https://pmc.ncbi.nlm.nih.gov/articles/PMC11299976/

### 3.2 CKD-EPI 2021: eGFR como estimador renal

\[
\operatorname{eGFR}_{cr}=142\min(\mathrm{Scr}/\kappa,1)^\alpha\max(\mathrm{Scr}/\kappa,1)^{-1.200}\cdot0.9938^{edad}\cdot [1.012\text{ si mujer según ecuación}].
\]

\(\kappa=0.7,\alpha=-0.241\) (categoría femenina del modelo) o \(\kappa=0.9,\alpha=-0.302\) (categoría masculina). Se necesita creatinina estandarizada en mg/dL; eGFR se expresa en mL/min/1.73 m². No sustituir creatinina por «azúcar», ni asignar eGFR sin muestra clínica. Las ecuaciones no requieren una corrección por raza. No confundir eGFR (tasa) con riesgo probabilístico de falla.

**Alternativa creatinina+cistatina C 2021:**

\[
\mathrm{eGFR}_{cr-cys}=135\min(\mathrm{Scr}/\kappa,1)^{\alpha'}\max(\mathrm{Scr}/\kappa,1)^{-0.544}
\min(\mathrm{Scys}/0.8,1)^{-0.323}\max(\mathrm{Scys}/0.8,1)^{-0.778}
\cdot0.9961^{edad}\cdot[0.963\text{ si mujer según ecuación}].
\]

Con \(\alpha'=-0.219\) categoría femenina o \(-0.144\) masculina. Cuando la estimación tiene consecuencias importantes o la composición muscular es atípica, evaluar prueba confirmatoria de función renal según clínica.

Fuentes: https://www.niddk.nih.gov/research-funding/research-programs/kidney-clinical-research-epidemiology/laboratory/glomerular-filtration-rate-equations/adults ; https://www.kidney.org/professionals/ckd-epi-creatinine-cystatin-equation-2021

### 3.3 CHA₂DS₂-VA para FA confirmada

Puntos por insuficiencia cardiaca (1), hipertensión (1), edad ≥75 (2) o 65–74 (1), diabetes (1), evento cerebral/embolismo previo (2) y enfermedad vascular (1). Se obtiene una puntuación de estratificación, no un porcentaje universal: tasas observadas varían por cohortes, anticoagulación y periodo. Antes de aplicar, documentar FA confirmada por ECG; un reloj PPG irregular sólo recomienda evaluación ECG. ESC 2024 contempla anticoagulación a partir de determinados puntajes bajo decisión clínica; el software no debe ordenar tratamiento.

Fuente: https://academic.oup.com/eurheartj/article/45/36/3314/7738779

## 4. Cuantificación de exposición sin inventar probabilidades

### 4.1 CGM

Defina un intervalo observado válido \(W\), máscara de cobertura de dispositivo \(m(t)\in\{0,1\}\) y glucosa intersticial \(G(t)\).

\[
TBR_{70}=\frac{\int_W m(t)\mathbf 1\{G(t)<70\}dt}{\int_W m(t)dt},\quad
TBR_{54}=\frac{\int_W m(t)\mathbf 1\{G(t)<54\}dt}{\int_W m(t)dt},\\
TIR_{70:180}=\frac{\int_W m(t)\mathbf 1\{70\le G(t)\le180\}dt}{\int_W m(t)dt}.
\]

TAR análogo con >180 y >250. TBR54 es subconjunto de TBR70: no son categorías disjuntas y **no deben sumarse**. La interpolación sólo debe operar en huecos muy pequeños preespecificados. Informar cobertura (%), número de episodios y minutos por día, no solamente un promedio. ADA 2026 ofrece metas de manejo principalmente para personas con diabetes, con variación por edad/comorbilidad: ≥70 % activo en 14 días y TIR >70 % como referencia para muchos adultos; TBR <70 <4 %; TBR <54 <1 %.

Variabilidad por coeficiente de variación: \(CV=100\,s_G/\bar G\). Este CV tampoco es un porcentaje de enfermedad.

Fuente: https://doi.org/10.2337/dc26-s006

### 4.2 Presión arterial y cardiaco continuos

- **Promedio temporal:** \(\bar x=\int m(t)x(t)dt/\int m(t)dt\); ponderación explícita por duración, no por densidad irregular de muestreo.
- **Presión de pulso:** \(PP=PAS-PAD\), mmHg. Aumentos aislados pueden corresponder a rigidez arterial, error de manguito o actividad física; no diagnóstico automático.
- **Presión arterial media aproximada:** \(MAP\approx PAD+(PAS-PAD)/3\). La aproximación es menos adecuada con FC muy alta o formas de pulso particulares; útil como resumen, no como sustituto de perfusión clínica.
- **Cambio respecto de basal:** \(\Delta x=\bar x_{actual}-\operatorname{mediana}(x_{basal})\); acompañar de intervalo de referencia, hora, postura y tratamiento.
- **Desviación robusta:** \(z_{MAD}=0.6745(x-\operatorname{mediana})/MAD\), cuando MAD>0. **Heurística estadística**; ningún umbral z implica sepsis, FA o hipoglucemia por sí mismo.
- **Persistencia:** minutos fuera de rango, longitud de episodios consecutivos y recuento por paciente-día con condición mínima de cobertura y artefactos.

### 4.3 Saturación, temperatura y circadianidad

El porcentaje de tiempo debajo de un corte SpO2 es medición de exposición condicionada a calidad, altitud, pigmentación, perfusión, apnea, oxígeno suplementario y enfermedad pulmonar. La variable origen étnico autodeclarado NO mide pigmentación cutánea. Un desplazamiento de temperatura alrededor de la fase lútea puede ser fisiológico; la fase declarada necesita método de determinación, ausencia de fiebre, horario y calidad. Ninguno de estos datos por sí solo confirma embarazo, infección, función ovárica, insuficiencia cardiaca o trastorno tiroideo.

## 5. Distribuciones empíricas: cuáles podrían estimarse, nunca fabricarlas

### 5.1 Densidades condicionales y cohortes

Un monitor de riesgo continuo requiere estudiar \(p(X_{t:t+\Delta}|Y=1,Z)\) y \(p(X_{t:t+\Delta}|Y=0,Z)\), donde \(Z\) incluye edad, tratamientos, comorbilidades, dispositivo, contexto y selección de la muestra. **Sin cohortes locales con desenlaces adjudicados no conocemos estas distribuciones**. No introducir gausianas ni tasas basales por intuición.

Modelos estadísticos candidatos, bajo diagnóstico de distribución:

1. Gaussiana robusta/t-Student para residuales de FC/PA con posibles colas pesadas. Verificar distribución y dependencia temporal.
2. Poisson para recuentos de episodios sólo si media≈varianza y exposiciones comparables; binomial negativa ante sobredispersión; modelos cero-inflados cuando corresponda.
3. Beta-binomial para incertidumbre en tasas por persona con **observaciones independientes**; en series temporales CGM la autocorrelación reduce el tamaño efectivo de muestra y exige estimación por bloques.
4. Modelos de supervivencia (Cox) para un primer evento; comprobar riesgos proporcionales; Weibull o modelos flexibles si falla.
5. Riesgo competidor (Fine–Gray o causa-específica) cuando muerte impide el evento principal.
6. Modelos longitudinales conjuntos (longitudinal + supervivencia) cuando una trayectoria fisiológica importa, evitando usar información futura.
7. Modelos mixtos jerárquicos cuando hay medidas repetidas, dispositivos, clínicas y pacientes diferentes.
8. Conformal prediction y bandas de predicción sólo si se demuestra intercambioabilidad o se adapta de forma válida a cambio de distribución/tiempo.

**No se suministran parámetros empíricos** de las distribuciones 1–8: requerirían estimación y validación con datos de la población objetivo.

### 5.2 Métricas de discriminación y calibración

- AUROC: capacidad de ordenar casos, puede ocultar desempeño pobre si el evento es poco prevalente.
- AUPRC: depende de prevalencia; siempre reportar prevalencia y comparador.
- Brier: \(\frac1n\sum_i(p_i-y_i)^2\), con calibración y resolución combinadas.
- Calibración en grande: diferencia entre promedio de riesgo pronosticado y observado.
- Pendiente de calibración: regresión sobre `logit(p)`, ideal cercano a 1 en muestra externa.
- Intervalo del estimador: bootstrap agrupado por paciente/centro (no dividir días del mismo paciente entre entrenamiento y prueba).
- C-index temporal y Brier dependiente de tiempo, incorporando censura según método.

Ejemplo didáctico de prevalencia y valor predictivo positivo (NO rendimiento observado): sensibilidad 90 %, especificidad 98 %, prevalencia 1 % da
\[
PPV=\frac{0.90\times0.01}{0.90\times0.01+0.02\times0.99}\approx 31.25\%.
\]

Un detector muy preciso técnicamente puede generar 69 falsas alarmas por cada 100 alarmas si la enfermedad es rara. La decisión de umbral debe considerar daños de falsos negativos y falsos positivos.

### 5.3 Umbral de acción por utilidad esperada

Bajo costes hipotéticos comparables \(C_{FN},C_{FP}\), una política simplificada alerta si
\[
P(Y=1\mid X)>\frac{C_{FP}}{C_{FP}+C_{FN}},
\]

pero la fórmula requiere consecuencias, intervención, beneficio, costes y responsabilidad explícitos. No elegir los costes para producir artificialmente una cantidad deseada de alertas. Eventos de alta gravedad requieren lógica de seguridad clínica y supervisión fuera de este umbral simplista.

## 6. Cómo construir probabilidades para nuevas reglas si existiera una cohorte

1. Definir desenlace (por ejemplo evento de FA confirmado por ECG durante 30 días) y etiqueta adjudicada, población/edad, momento y horizonte.
2. Congelar ventanas retrospectivas que TERMINEN antes de la adjudicación; prohibir fuga de datos de desenlace y tratamientos posteriores.
3. Asegurar calidad y uniformidad de sensores; registrar los ausentes explícitamente.
4. Separar hospitales, pacientes y periodos de entrenamiento/validación externa para evitar correlación artificial.
5. Comparar logística preespecificada, Cox/cause-specific, GAM y regresión regularizada con baselines clínicos; evaluar complejidad vs interpretabilidad.
6. Reportar capacidad discriminativa, calibración, intervalos y curvas de decisión por enfermedad, estratos y dispositivo.
7. Hacer prueba en modo silencioso, luego estudio prospectivo controlado bajo comité clínico/regulador antes de alertar pacientes.

Fuentes metodológicas: https://www.bmj.com/content/388/bmj-2024-082505 (PROBAST+AI) y documentación TRIPOD+AI.
