# Alcance de la revisión de literatura y restricciones de extracción

## Qué se revisó directamente

Fueron localizados y contrastados pasajes de 30 referencias principales o páginas institucionales, con detalles en `extractos_verificados.csv`. Se priorizaron guías primarias y páginas de organismos profesionales o reguladores. Cada pasaje tiene localizador; el enlace lleva a la fuente para la lectura completa.

## Qué se conserva sin verificación completa

El registro heredado v03 enumera 61 IDs (49 URL diferentes). No se revisó individualmente la totalidad de los 512 criterios frente al texto completo de cada publicación. Un mismo artículo puede aparecer bajo dos IDs; un documento listado puede ser anterior a un cambio posterior. `REGISTRO_DE_61_FUENTES.csv` explicita cuáles tienen extracto conectado por temática, y cuáles sólo constan como referencias heredadas.

## Cómo concluir que una variante deriva realmente de la guía

Una comprobación reproducible requiere:

1. Documentar edición, año, página/párrafo, recomendación y tabla específicos.
2. Transcribir criterio y población con unidad, ventana y técnica de medición.
3. Comparar la definición de evento con el desenlace propuesto.
4. Identificar adiciones del prototipo (antecedentes, umbrales de persitencia, combinación de sensores y gradación de alerta).
5. Etiquetar `EXACTA`, `PARAFRASIS_FIEL`, `DERIVACION` o `HEURISTICA` con evaluador y fecha.
6. Formular contraejemplos y pruebas antes de permitir una alerta.

La categoría `UMBRAL_GUIA` **no** debe reinterpretarse como prueba de exactitud de toda la regla compuesta. La decisión de usar un criterio incluye elección entre guías, calidad de medición, prevalencia y función de costes; esas decisiones están documentadas en otros anexos.

## Diferencia entre evidencia bibliográfica y desempeño empírico del motor

Ninguna revisión bibliográfica sustituye la calibración de un sistema concreto en la población objetivo. Incluso si la guía respalda el valor PAS>=140, la sensibilidad/especificidad de una alerta que exige además «HR>110 durante 15 minutos» es una propiedad NUEVA que debe medirse con pacientes reales. Lo mismo ocurre con sensores de consumidores.

## Bibliografía adicional

- FDA, desarrollo ML en dispositivos: https://www.fda.gov/medical-devices/artificial-intelligence-enabled-medical-devices/good-machine-learning-practice-medical-device-development-guiding-principles
- PROBAST+AI, riesgo de sesgo: https://www.bmj.com/content/388/bmj-2024-082505
- OMS, Hb anemia 2024: https://www.who.int/publications/i/item/9789240088542/
- NIDDK, fórmulas renal: https://www.niddk.nih.gov/research-funding/research-programs/kidney-clinical-research-epidemiology/laboratory/glomerular-filtration-rate-equations/adults
- NOM-241-SSA1-2025: https://sidof.segob.gob.mx/notas/docFuente/5754074
- NOM-137-SSA1-2025: https://sidof.segob.gob.mx/notas/docFuente/5787790

No se incluyen PDFs completos de material protegido ni reproducciones extensas de párrafos de terceros. Los 30 extractos son intencionalmente breves.
