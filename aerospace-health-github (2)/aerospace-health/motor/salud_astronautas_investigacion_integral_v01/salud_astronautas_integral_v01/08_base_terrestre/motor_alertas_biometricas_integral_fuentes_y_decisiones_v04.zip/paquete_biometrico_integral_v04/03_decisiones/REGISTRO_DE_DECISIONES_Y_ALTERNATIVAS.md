# Registro explícito de decisiones técnicas y clínicas (ADR)

Este registro presenta **razones y alternativas de diseño comprobables**. No describe un pensamiento privado interno: identifica qué se decidió hacer con los criterios del catálogo, por qué es seguro o útil, qué alternativa existe, qué se desconoce y qué prueba faltaría para validar el sistema. Fecha: 14-11-2026.

| ADR | Decisión aplicada/recomendada | Razón | Alternativa y coste | Verificación obligatoria |
|---|---|---|---|---|
| D01 | Separar `valor_anómalo`, `patrón`, `riesgo`, `sospecha` y `diagnóstico` | Un sensor mide fenómenos, no causas únicas | Clasificador de enfermedad directo; puede confundir causas | Auditoría clínica, trazabilidad por regla |
| D02 | Prohibir porcentajes de probabilidad sin modelo | La salida 82 % no se deduce de tres umbrales | Scoring arbitrario; no calibrado | Validación externa y curvas de calibración |
| D03 | Exigir desenlace y horizonte | 5 años de falla renal ≠ ERC actual | «riesgo de riñón» ambiguo | Validar semántica del resultado |
| D04 | Usar edad exacta y reglas estratificadas | Adultos, embarazo, adolescentes tienen distintos cortes | Tabla única; peligrosa | Especificar población de guía |
| D05 | Etnicidad autodeclarada como contexto, no multiplicador universal | Evita proxies raciales no justificados | Ajustes de raza de ecuaciones históricas | Auditoría de equidad y justificación específica |
| D06 | Conservar fase menstrual con método y certeza | Una fase supuesta no prueba ovulación | Asumir «día 14» como ovulación | Confirmación LH/progesterona si clínicamente indicada |
| D07 | Embarazo es estado propio, no función de ciclo | Reglas obstétricas tienen alto impacto | Inferir con retraso menstrual | Confirmación del estado gestacional |
| D08 | No inferir síntomas no medidos | Sepsis, DKA y otras definiciones exigen clínica | «No informado» igual a «ausente» | Triage que pregunta información faltante |
| D09 | No asumir no fumador | PREVENT exige el predictor | Asumir cero reduce riesgo calculado | Registro explícito sí/no/desconocido |
| D10 | No asumir ausencia de medicación | Tratamiento modifica PA, glucosa y modelos | Imputar como no tratado | Histórico farmacológico verificado |
| D11 | Preferir magnitud y duración en series | Una sola lectura genera falsas alarmas | Umbral instantáneo generalizado | Definir ventanas por fuente y sensor |
| D12 | Crear rutas de urgencia sobre otras puntuaciones | Una cifra peligrosa puede ser urgente sin probabilidad | Esperar score compuesto | Guía de deterioro, protocolo de confirmación |
| D13 | No convertir alta FC en FA | PPG no reemplaza ECG | Diagnóstico desde pulso irregular | ECG documentado |
| D14 | No convertir SpO2 nocturna en apnea del sueño | AASM exige estudio diagnóstico adecuado | Diagnóstico de reloj | Polisomnografía o HSAT aceptable |
| D15 | Incorporar calidad del oxímetro | Perfusión y pigmentación afectan error | Corregir por etnia; no justificado | Validación específica del dispositivo |
| D16 | Bloquear PA cuffless para diagnóstico | ACC/AHA 2025 recomienda contra ese uso | Estimar PA de forma continua | Manguito validado y método clínico |
| D17 | Distinguir ABPM 24h, nocturna, clínica y HBPM | Los umbrales no son equivalentes | Valor «PA media» sin método | Metadatos de postura, sensor y protocolo |
| D18 | No diagnosticar DM por CGM | ADA usa laboratorio plasmático o HbA1c validada | «Media CGM alta => diabetes» | HbA1c/FPG/OGTT apropiados |
| D19 | TIR/TBR se interpretan sólo en contexto de diabetes/tratamiento | Los objetivos proceden de poblaciones específicas | Meta universal | Datos diagnóstico, fármacos y comorbilidades |
| D20 | GMI no equivale necesariamente a HbA1c | Discrepancias sistemáticas | Reemplazar A1c por GMI | Corroboración en laboratorio |
| D21 | CKD necesita persistencia o evidencia clínica | eGFR puntual no basta para cronicidad | ERC de una sola creatinina | ≥3 meses u otros criterios médicos |
| D22 | KFRE sólo para ERC G3–G5 confirmada | Restricciones publicadas por KDIGO | Extrapolación a sanos | Restricción de población + validación |
| D23 | No inventar riesgo renal si falta ACR | Variable indispensable de KFRE 4V | Imputar albúmina normal | Solicitar uACR válida |
| D24 | FIB-4 es score, no % fibrosis | No tiene enlace probabilístico universal | Convertir corte 2.67 a 80 % | Cohorte específica para calibración |
| D25 | FIB-4 se abstiene en enfermedad aguda | AST/ALT alteran puntuación | Aplicarlo siempre | Estado de enfermedad aguda registrado |
| D26 | Revisar frontera exactamente 65 años en FIB-4 | Código usa >=65, guías >65 | Diferencias sutiles de corte | Dictamen clínico antes de producción |
| D27 | Aplicar Hb OMS por embarazo y edad | Diferencias de cortes y severidad | Un único Hb<12 para todos | Edad/sexo/gestación/altitud |
| D28 | Ferritina requiere contexto de anemia/inflamación | Ferritina es reactante de fase aguda | Umbral idéntico siempre | Hemograma, PCR y pruebas complementarias |
| D29 | Potasio exige laboratorio válido y revaluación | Hemólisis produce pseudohiperpotasemia | Tratar reloj/estimar K | Repetición, electrocardiograma según riesgo |
| D30 | Sospecha de sepsis requiere infección plausible | FC, PA, temperatura no identifican infección | Diagnóstico a partir de reglas NICE aisladas | Anamnesis/evaluación clínica y otros signos |
| D31 | Diseñar salud reproductiva estratificada | Adolescentes y SOP requieren definiciones distintas | Un único algoritmo SOP | Criterios revisados PCOS y exclusión |
| D32 | Mantener experimentales apagadas | No tienen propiedades diagnósticas conocidas | Activarlas por exhaustividad | Estudio de seguridad primero |
| D33 | Desactivar derivadas para alerta a pacientes hasta validar | Combinación propia no equivale a guía | Atribuirla a la publicación base | Revisión línea por línea |
| D34 | Trabajar con variable `NO_EVALUABLE` | Falta de predictores no equivale a normalidad | Valores predeterminados normales | Pruebas con faltantes |
| D35 | Respetar precedencia de niveles críticos | Evita silenciar deterioro grave | Alertas promedio cancelan episodios | Tabla de precedencia validada |
| D36 | Aplicar deduplicación de alertas | Un mismo evento activa decenas de reglas | 512 notificaciones | Agrupar por evento y ventana |
| D37 | Registrar evidencia y versión por alerta | Permite explicar decisión | Texto libre sin provenance | Identificador regla, fuente y commit |
| D38 | Mantener umbrales por jurisdicción | ACC/AHA y NICE no usan cortes idénticos | Mezclar umbrales en un árbol | Perfil reglamentario explícito |
| D39 | Evitar ajuste étnico de sensores sin evidencia | Etnia no mide pigmentación cutánea | Corregir SpO2 por etiqueta social | Ensayos instrumento/tonos de piel |
| D40 | Riesgo bajo no cancela señal aguda | Horizonte largo vs minuto actual | Ocultar urgencia por PREVENT bajo | Prioridades independientes |
| D41 | Anotar unidades y método de muestra | mg/dL vs mmol/L cambia 18x para glucosa | Conversiones implícitas | Unit tests dimensionales |
| D42 | Fechar y versionar resultados de laboratorio | Valor antiguo no representa estado actual | Reutilizar indefinidamente | TTL clínico según prueba |
| D43 | Preferir mediana/ventana a puntos aberrantes | Reduce artefacto sensorial | Umbral instantáneo para todos | Validar sensibilidad a duración |
| D44 | No aplicar basal sin historial suficiente | Basal arbitraria induce «anomalías» ficticias | Usar promedio global no ajustado | Mínimos de cobertura definidos por caso |
| D45 | Usar calibración específica de población | Ecuaciones originales se desarrollaron fuera de México | Traslado sin estudio | Calibración intercepto/pendiente |
| D46 | Auditoría por subgrupos | Mismo rendimiento global puede ocultar desigualdad | Sólo AUROC agregado | Sexo, edad, sensor, centro y condiciones |
| D47 | No transformar intensidad en probabilidad | % del día con hipoglucemia es una exposición | «Riesgo de DM 25%» desde TBR | Ensayo longitudinal con desenlaces |
| D48 | Comparar score alternativo antes de seleccionar | Los criterios se solapan y difieren | Elegir sólo un puntaje por costumbre | Validez, datos, outcome y coste |
| D49 | Mostrar incertidumbre epistemológica y estadística | 15.14 % puntual no tiene error ±0.01 % | Falsa precisión decimal | Intervalos bootstrap/modelo/calibración |
| D50 | Evaluación regulatoria en México | Puede considerarse ScDM | Publicarlo como app de bienestar con alertas diagnósticas | COFEPRIS/NOM-241 y uso previsto |
| D51 | No codificar rasgos sensibles innecesarios | Riesgo de discriminación y privacidad | Recolectar todo por defecto | Minimización y análisis de equidad |
| D52 | No atribuir 512 reglas a 512 guías | Las entradas incluyen derivaciones y seguridad lógica | Conteo publicitario | Matriz de trazabilidad y estados |
| D53 | No simular prevalencia real sin datos | La prevalencia determina PPV | «Sensibilidad 95%» sin cohorte | Prospectiva o validación externa |
| D54 | Separar detector y política de notificación | Umbral técnico no define a quién avisar | Notificar cada activación | Evaluar fatiga de alerta y daño |
| D55 | Conservación de datos longitudinales proporcional | Series detalladas son sensibles | Historial ilimitado sin motivo | Política retención/consentimiento |
| D56 | Mantener un registro de contraindicaciones | Un biomarcador puede ser engañoso en distintas condiciones | Un criterio global | Reglas de exclusión verificables |
| D57 | Documentar qué no puede inferirse | Evita sobreprometer detección de cáncer, ictus o infecciones | Clasificador universal | Tabla de límites y pruebas externas |
| D58 | No entrenar sobre datos de seguimiento posteriores | Fuga de etiqueta mejora artificialmente el modelo | División aleatoria de ventanas | Corte temporal y externo |
| D59 | Reportar falsas alarmas por paciente-tiempo | AUROC no mide carga operativa | Sólo sensibilidad | Alarmas por 100 paciente-días |
| D60 | Revisión clínica humana antes de activar | Interpretación requiere especialidad y contexto | Activación autónoma del JSON | Comité multidisciplinario y pruebas prospectivas |

## Razones de conflictos concretos detectados

**Hipertensión: perfiles jurisdiccionales.** Clasificación ACC/AHA 2025 en adultos incluye estadio 1 a 130–139 o 80–89 con medición protocolizada, mientras NICE NG136 exige criterios de consulta y promedio fuera de consulta distintos. Decisión: soportar `guideline_profile='AHA2025'` y `guideline_profile='NICE_NG136'` sin combinar criterios de manera implícita. Motivo: una misma cifra tomada en distintos contextos tiene valor diagnóstico distinto. Fuentes: AHA 2025 y NICE NG136, citados en `02_literatura`.

**FIB-4 y edad.** Fuentes AASLD/EASL describen ajuste del punto de corte inferior en mayores de 65 años; el código `>=65` entra en un límite fronterizo que debe revisarse. Decisión: no corregir silenciosamente calculadora heredada; marcar su validación pendiente.

**KFRE y riesgo empírico.** El resultado 15.14 % del caso hipotético es cálculo reproducible del modelo y NO evidencia de que la incidencia en una población mexicana semejante vaya a ser exactamente 15.14 %. Decisión: mostrar `calibracion_mexico=NO_VERIFICADA` siempre.

**Antecedentes.** Hasta 20 diagnósticos y 20 secuelas no justifican modificar logits con multiplicadores elegidos a mano. Decisión: antecedentes influyen en selección de ruta, exclusiones y prioridades, pero sólo cambian la probabilidad absoluta si entran explícitamente en un modelo validado o existe actualización calibrada.

**Fuentes heredadas.** La lista previa contiene entradas duplicadas/alias de la misma obra y referencias de distinta actualidad. La relación `fuente_id -> extracto` en v04 es contextual, **no** una comprobación literal de cada una de las 512 reglas. Decisión: introducir el estado `CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO` incluso para reglas previamente rotuladas `UMBRAL_GUIA`.
