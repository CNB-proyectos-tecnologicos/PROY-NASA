# Fichas de trazabilidad y evaluación de las 512 reglas

Cada ficha reproduce la especificación v03 y añade justificación pública de ingeniería. **No es una reconstrucción del razonamiento interno del modelo; es un registro de decisiones de diseño verificables y riesgos.**

**Estado:** todo el catálogo queda en revisión; los extractos asociados prueban sólo un enunciado fuente, no la concordancia de cada regla compleja. Las heurísticas derivadas y experimentales requieren estudios independientes.

## R0001: Bajo peso (Antropometría)

- **SI:** IMC < 18.5 kg/m²
- **ENTONCES:** Evaluar estado nutricional y causas clínicas
- **Variables:** imc, edad; disponibilidad BASE.
- **Ventana:** Medición actual y reconfirmación; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRIBADO.
- **Confirmación necesaria:** Evaluación nutricional.
- **Fuente declarada v03:** CDC_BMI24 — https://www.cdc.gov/bmi/adult-calculator/bmi-categories.html.
- **Pasaje breve relacionado:** S27; **ubicación:** CDC Adult BMI categories.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0002: Sobrepeso (Antropometría)

- **SI:** 25 <= IMC < 30 kg/m²
- **ENTONCES:** Revisar riesgo cardiometabólico y perímetro abdominal
- **Variables:** imc, edad; disponibilidad BASE.
- **Ventana:** Actual; **Población:** Adultos >=18 años.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** CRIBADO.
- **Confirmación necesaria:** Evaluación clínica.
- **Fuente declarada v03:** CDC_BMI24 — https://www.cdc.gov/bmi/adult-calculator/bmi-categories.html.
- **Pasaje breve relacionado:** S27; **ubicación:** CDC Adult BMI categories.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0003: Obesidad clase I (Antropometría)

- **SI:** 30 <= IMC < 35 kg/m²
- **ENTONCES:** Evaluación de comorbilidades
- **Variables:** imc, edad; disponibilidad BASE.
- **Ventana:** Actual; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRIBADO.
- **Confirmación necesaria:** Evaluación clínica.
- **Fuente declarada v03:** CDC_BMI24 — https://www.cdc.gov/bmi/adult-calculator/bmi-categories.html.
- **Pasaje breve relacionado:** S27; **ubicación:** CDC Adult BMI categories.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0004: Obesidad clase II (Antropometría)

- **SI:** 35 <= IMC < 40 kg/m²
- **ENTONCES:** Evaluación integral de riesgo
- **Variables:** imc, edad; disponibilidad BASE.
- **Ventana:** Actual; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRIBADO.
- **Confirmación necesaria:** Evaluación clínica.
- **Fuente declarada v03:** CDC_BMI24 — https://www.cdc.gov/bmi/adult-calculator/bmi-categories.html.
- **Pasaje breve relacionado:** S27; **ubicación:** CDC Adult BMI categories.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0005: Obesidad clase III (Antropometría)

- **SI:** IMC >= 40 kg/m²
- **ENTONCES:** Evaluación especializada
- **Variables:** imc, edad; disponibilidad BASE.
- **Ventana:** Actual; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRIBADO.
- **Confirmación necesaria:** Evaluación clínica.
- **Fuente declarada v03:** CDC_BMI24 — https://www.cdc.gov/bmi/adult-calculator/bmi-categories.html.
- **Pasaje breve relacionado:** S27; **ubicación:** CDC Adult BMI categories.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0006: Adiposidad central aumentada (Antropometría)

- **SI:** 0.50 <= cintura/estatura < 0.60 y IMC <35
- **ENTONCES:** Revisar riesgo de diabetes y cardiovascular
- **Variables:** cintura_cm, estatura_cm, imc; disponibilidad BASE.
- **Ventana:** Medición actual; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRIBADO.
- **Confirmación necesaria:** Antropometría estandarizada.
- **Fuente declarada v03:** NICE_WHTR — https://www.nice.org.uk/guidance/ng246/chapter/Identifying-and-assessing-overweight-obesity-and-central-adiposity.
- **Pasaje breve relacionado:** S14; **ubicación:** NICE NG246, 1.9.14–1.9.15.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0007: Adiposidad central alta (Antropometría)

- **SI:** cintura/estatura >=0.60 y IMC <35
- **ENTONCES:** Evaluación cardiometabólica
- **Variables:** cintura_cm, estatura_cm, imc; disponibilidad BASE.
- **Ventana:** Medición actual; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRIBADO.
- **Confirmación necesaria:** Antropometría estandarizada.
- **Fuente declarada v03:** NICE_WHTR — https://www.nice.org.uk/guidance/ng246/chapter/Identifying-and-assessing-overweight-obesity-and-central-adiposity.
- **Pasaje breve relacionado:** S14; **ubicación:** NICE NG246, 1.9.14–1.9.15.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0008: Cambios ponderales progresivos (Antropometría)

- **SI:** Cambio de peso relativo >=5% en 3-6 meses
- **ENTONCES:** Verificar intencionalidad, hidratación, alimentación y posibles causas
- **Variables:** peso_kg, historial_peso; disponibilidad BASE.
- **Ventana:** Meses; **Población:** Adultos >=18 años.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** SEGUIMIENTO.
- **Confirmación necesaria:** Entrevista y exploración.
- **Fuente declarada v03:** CDC_BMI24 — https://www.cdc.gov/bmi/adult-calculator/bmi-categories.html.
- **Pasaje breve relacionado:** S27; **ubicación:** CDC Adult BMI categories.
- **Clasificación original:** EXPERIMENTAL_NO_VALIDADA; **revisión v04:** SOLO_INVESTIGACION_DESACTIVADA.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0009: Ganancia rápida de peso en IC conocida (Antropometría)

- **SI:** Insuficiencia cardiaca conocida y aumento >2 kg en 3 días
- **ENTONCES:** Contactar al equipo de insuficiencia cardiaca; valorar congestión
- **Variables:** peso_kg, insuficiencia_cardiaca_previa; disponibilidad BASE.
- **Ventana:** 3 días; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** VIGILANCIA.
- **Confirmación necesaria:** Valoración clínica y peso estandarizado.
- **Fuente declarada v03:** ESC_HF21 — https://academic.oup.com/eurheartj/article/42/36/3599/6358045.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0010: Pérdida rápida de peso con taquicardia (Antropometría)

- **SI:** Peso cae >2% en 72 h y FC basal aumenta persistentemente
- **ENTONCES:** Valorar pérdida de volumen u otras causas
- **Variables:** peso_kg, fc_reposo, presion; disponibilidad BASE.
- **Ventana:** 72 horas; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON.
- **Confirmación necesaria:** Evaluación clínica; química sanguínea si procede.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** EXPERIMENTAL_NO_VALIDADA; **revisión v04:** SOLO_INVESTIGACION_DESACTIVADA.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0011: Fiebre medida clínicamente (Temperatura)

- **SI:** Temperatura clínica >=38.0 °C
- **ENTONCES:** Investigar causa y contexto
- **Variables:** temperatura, sitio_sensor; disponibilidad BASE.
- **Ventana:** Repetir si procede; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Termómetro clínico validado.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0012: Temperatura muy elevada (Temperatura)

- **SI:** Temperatura clínica >=40 °C
- **ENTONCES:** Valoración médica pronta; revisar exposición al calor e infección
- **Variables:** temperatura, sitio_sensor; disponibilidad BASE.
- **Ventana:** Confirmación inmediata; **Población:** Adultos >=18 años.
- **Prioridad:** URGENTE; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Termometría clínica.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0013: Hipotermia (Temperatura)

- **SI:** Temperatura central confirmada <35 °C
- **ENTONCES:** Evaluación médica urgente
- **Variables:** temperatura, sitio_sensor; disponibilidad BASE.
- **Ventana:** Inmediato; **Población:** Adultos >=18 años.
- **Prioridad:** CRITICA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Temperatura central adecuada.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0014: Hipotermia relativa en sospecha infecciosa (Temperatura)

- **SI:** Tª timpánica <36 °C y sospecha clínica de infección
- **ENTONCES:** Evaluación de posible deterioro séptico
- **Variables:** temp_timpanica, sospecha_infeccion; disponibilidad BASE.
- **Ventana:** Medición actual; **Población:** Adultos >=18 años.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON.
- **Confirmación necesaria:** Valoración presencial.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0015: Hipotensión potencialmente grave (Cardiovascular agudo)

- **SI:** PAS <=90 mmHg en medición validada
- **ENTONCES:** Evaluación de perfusión y causas, particularmente si nueva
- **Variables:** pa_sistolica_validada; disponibilidad BASE.
- **Ventana:** Repetición inmediata según seguridad; **Población:** Adultos >=18 años.
- **Prioridad:** URGENTE; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Presión por manguito y exploración.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0016: Caída brusca de presión basal (Cardiovascular agudo)

- **SI:** PAS disminuye >40 mmHg frente a habitual, con medición validada
- **ENTONCES:** Valoración de deterioro circulatorio
- **Variables:** pa_sistolica_validada, pas_baseline; disponibilidad BASE.
- **Ventana:** Comparación basal y actual; **Población:** Adultos >=18 años.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON.
- **Confirmación necesaria:** Manguito validado y evaluación.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0017: Taquicardia marcada (Cardiovascular agudo)

- **SI:** FC >130 lpm en reposo, sostenida y confirmada
- **ENTONCES:** Evaluación clínica y ECG
- **Variables:** fc_reposo, calidad_fc; disponibilidad BASE.
- **Ventana:** Repetir/confirmar; **Población:** Adultos >=18 años.
- **Prioridad:** URGENTE; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** ECG si disponible.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0018: Taquicardia en reposo (Cardiovascular agudo)

- **SI:** FC de reposo >100 lpm en medidas repetidas
- **ENTONCES:** Evaluar fiebre, anemia, deshidratación, arritmia, fármacos
- **Variables:** fc_reposo, actividad; disponibilidad BASE.
- **Ventana:** Dos o más periodos en reposo; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON.
- **Confirmación necesaria:** ECG y consulta.
- **Fuente declarada v03:** ESC_AF24 — https://academic.oup.com/eurheartj/article/45/36/3314/7738779.
- **Pasaje breve relacionado:** S21; **ubicación:** ESC 2024 AF guideline, key message 10.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0019: Bradicardia de vigilancia (Cardiovascular agudo)

- **SI:** FC en reposo <50 lpm y desviación relevante del patrón habitual
- **ENTONCES:** Comprobar atleta/sueño/fármacos y evaluar si corresponde
- **Variables:** fc_reposo, edad, fc_baseline; disponibilidad BASE.
- **Ventana:** Varias mediciones; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON.
- **Confirmación necesaria:** ECG.
- **Fuente declarada v03:** ESC_AF24 — https://academic.oup.com/eurheartj/article/45/36/3314/7738779.
- **Pasaje breve relacionado:** S21; **ubicación:** ESC 2024 AF guideline, key message 10.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0020: Bradicardia muy marcada (Cardiovascular agudo)

- **SI:** FC de reposo <40 lpm confirmada y no habitual
- **ENTONCES:** Evaluación médica rápida
- **Variables:** fc_reposo, contexto; disponibilidad BASE.
- **Ventana:** Repetir; **Población:** Adultos >=18 años.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON.
- **Confirmación necesaria:** ECG.
- **Fuente declarada v03:** ESC_AF24 — https://academic.oup.com/eurheartj/article/45/36/3314/7738779.
- **Pasaje breve relacionado:** S21; **ubicación:** ESC 2024 AF guideline, key message 10.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0021: Hipoxemia importante (Respiratorio)

- **SI:** SpO2 <=88% en reposo y señal fiable, confirmada
- **ENTONCES:** Valoración médica pronta/urgente según estado
- **Variables:** spo2, calidad_spo2; disponibilidad BASE.
- **Ventana:** Persistente o reconfirmada; **Población:** Adultos >=18 años.
- **Prioridad:** URGENTE; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Oximetría clínica; gasometría si procede.
- **Fuente declarada v03:** ATS_O2 — https://academic.oup.com/ajrccm/article/202/10/e121/8495596.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** oxímetro puede producir errores; diagnóstico de SAOS exige estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0022: Desaturación nueva moderada (Respiratorio)

- **SI:** SpO2 89–92% nueva frente a basal y repetida
- **ENTONCES:** Evaluar ventilación, enfermedad pulmonar y artefactos
- **Variables:** spo2, spo2_baseline; disponibilidad BASE.
- **Ventana:** Repetir en reposo; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON.
- **Confirmación necesaria:** Oxímetro validado.
- **Fuente declarada v03:** ATS_O2 — https://academic.oup.com/ajrccm/article/202/10/e121/8495596.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** oxímetro puede producir errores; diagnóstico de SAOS exige estudio | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0023: Desaturaciones nocturnas cíclicas (Respiratorio)

- **SI:** Desaturaciones relativas nocturnas de >=3–4 puntos repetidas y buena señal
- **ENTONCES:** Considerar estudio del sueño si contexto compatible
- **Variables:** spo2_nocturna, calidad_spo2; disponibilidad BASE.
- **Ventana:** >=3 noches; **Población:** Adultos >=18 años.
- **Prioridad:** CRIBADO; **Naturaleza:** PATRON.
- **Confirmación necesaria:** PSG o HSAT técnicamente adecuado.
- **Fuente declarada v03:** AASM_OSA — https://aasm.org/resources/clinicalguidelines/diagnostic-testing-osa.pdf.
- **Pasaje breve relacionado:** S09; **ubicación:** AASM 2017, Good Practice Statements / Recommendations 1–2.
- **Clasificación original:** EXPERIMENTAL_NO_VALIDADA; **revisión v04:** SOLO_INVESTIGACION_DESACTIVADA.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** oxímetro puede producir errores; diagnóstico de SAOS exige estudio | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0024: Sospecha de apnea obstructiva del sueño (Respiratorio)

- **SI:** Obesidad/centralidad + PA nocturna elevada + desaturaciones nocturnas repetidas
- **ENTONCES:** Solicitar evaluación por medicina del sueño
- **Variables:** imc, presion_nocturna, spo2_nocturna; disponibilidad BASE.
- **Ventana:** Varias noches; **Población:** Adultos >=18 años.
- **Prioridad:** CRIBADO; **Naturaleza:** RIESGO.
- **Confirmación necesaria:** PSG o HSAT validado.
- **Fuente declarada v03:** AASM_OSA — https://aasm.org/resources/clinicalguidelines/diagnostic-testing-osa.pdf.
- **Pasaje breve relacionado:** S09; **ubicación:** AASM 2017, Good Practice Statements / Recommendations 1–2.
- **Clasificación original:** EXPERIMENTAL_NO_VALIDADA; **revisión v04:** SOLO_INVESTIGACION_DESACTIVADA.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** oxímetro puede producir errores; diagnóstico de SAOS exige estudio | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0025: Deterioro multivariable (Deterioro sistémico)

- **SI:** Fiebre o hipotermia relativa + FC en ascenso + PAS en descenso ± SpO2 en descenso
- **ENTONCES:** Priorizar revisión presencial, sin etiquetar sepsis
- **Variables:** temperatura, fc_reposo, pa_sistolica, spo2; disponibilidad BASE.
- **Ventana:** Horas; **Población:** Adultos >=18 años.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON.
- **Confirmación necesaria:** Evaluación clínica, lactato y panel según sospecha.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** EXPERIMENTAL_NO_VALIDADA; **revisión v04:** SOLO_INVESTIGACION_DESACTIVADA.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** no atribuir a sepsis sin sospecha de infección y signos adicionales | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0026: Infección sistémica posible con hipotensión (Deterioro sistémico)

- **SI:** Tª clínica >=38 + PAS <=90 y/o FC >130 en reposo
- **ENTONCES:** Valoración clínica urgente; posibles causas múltiples
- **Variables:** temperatura, pa_sistolica_validada, fc_reposo; disponibilidad BASE.
- **Ventana:** Mediciones confirmadas; **Población:** Adultos >=18 años.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON.
- **Confirmación necesaria:** Evaluación presencial.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** no atribuir a sepsis sin sospecha de infección y signos adicionales | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0027: Hipertensión estadio 1 AHA/ACC (Presión arterial)

- **SI:** PAS 130–139 O PAD 80–89 (promedio válido)
- **ENTONCES:** Revisar y confirmar hipertensión según protocolo US
- **Variables:** pa_sistolica_validada, pa_diastolica_validada; disponibilidad BASE.
- **Ventana:** Series validadas repetidas; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRIBADO.
- **Confirmación necesaria:** HBPM/ABPM con manguito validado.
- **Fuente declarada v03:** AHA_BP25 — https://www.jacc.org/doi/10.1016/j.jacc.2025.05.007.
- **Pasaje breve relacionado:** S03; **ubicación:** ACC/AHA 2025 hipertensión, categorías PA, Table 4.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0028: Hipertensión estadio 2 AHA/ACC (Presión arterial)

- **SI:** PAS >=140 O PAD >=90, sin alcanzar corte de urgencia
- **ENTONCES:** Solicitar evaluación de HTA
- **Variables:** pa_sistolica_validada, pa_diastolica_validada; disponibilidad BASE.
- **Ventana:** Series validadas repetidas; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRIBADO.
- **Confirmación necesaria:** HBPM/ABPM validada.
- **Fuente declarada v03:** AHA_BP25 — https://www.jacc.org/doi/10.1016/j.jacc.2025.05.007.
- **Pasaje breve relacionado:** S03; **ubicación:** ACC/AHA 2025 hipertensión, categorías PA, Table 4.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0029: Hipertensión ESC en consulta (Presión arterial)

- **SI:** PAS consulta >=140 O PAD consulta >=90
- **ENTONCES:** Evaluación según protocolo europeo/MX
- **Variables:** pa_consulta_validada; disponibilidad BASE.
- **Ventana:** Repetida; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRIBADO.
- **Confirmación necesaria:** Medición clínica y ABPM/HBPM.
- **Fuente declarada v03:** ESC_BP24 — https://academic.oup.com/eurheartj/article/45/38/3912/7741010.
- **Pasaje breve relacionado:** S04; **ubicación:** NICE NG136, 1.2.7–1.2.8.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0030: Hipertensión ESC domiciliaria/diurna (Presión arterial)

- **SI:** Media HBPM o ABPM diurna >=135/85 mmHg (PAS o PAD)
- **ENTONCES:** Revisar HTA
- **Variables:** pa_domiciliaria_validada; disponibilidad BASE.
- **Ventana:** Mediciones protocolizadas; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRIBADO.
- **Confirmación necesaria:** HBPM/ABPM validada.
- **Fuente declarada v03:** ESC_BP24 — https://academic.oup.com/eurheartj/article/45/38/3912/7741010.
- **Pasaje breve relacionado:** S04; **ubicación:** NICE NG136, 1.2.7–1.2.8.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0031: Hipertensión ESC 24 horas (Presión arterial)

- **SI:** Media ABPM 24 h >=130/80 mmHg (PAS o PAD)
- **ENTONCES:** Revisar HTA
- **Variables:** pa_24h_validada; disponibilidad BASE.
- **Ventana:** 24 horas; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRIBADO.
- **Confirmación necesaria:** ABPM de manguito.
- **Fuente declarada v03:** ESC_BP24 — https://academic.oup.com/eurheartj/article/45/38/3912/7741010.
- **Pasaje breve relacionado:** S04; **ubicación:** NICE NG136, 1.2.7–1.2.8.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0032: Hipertensión ESC nocturna (Presión arterial)

- **SI:** Media ABPM noche >=120/70 mmHg (PAS o PAD)
- **ENTONCES:** Revisar patrón de HTA
- **Variables:** pa_noche_validada; disponibilidad BASE.
- **Ventana:** Noche validada; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRIBADO.
- **Confirmación necesaria:** ABPM validada.
- **Fuente declarada v03:** ESC_BP24 — https://academic.oup.com/eurheartj/article/45/38/3912/7741010.
- **Pasaje breve relacionado:** S04; **ubicación:** NICE NG136, 1.2.7–1.2.8.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0033: PA severamente elevada (Presión arterial)

- **SI:** PAS >180 O PAD >120, confirmada adecuadamente
- **ENTONCES:** Evaluación pronta; solicitar signos/síntomas de daño de órgano
- **Variables:** pa_sistolica_validada, pa_diastolica_validada; disponibilidad BASE.
- **Ventana:** Inmediato tras repetir; **Población:** Adultos >=18 años.
- **Prioridad:** URGENTE; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Exploración clínica y evaluación de órgano blanco.
- **Fuente declarada v03:** AHA_BP25 — https://www.jacc.org/doi/10.1016/j.jacc.2025.05.007.
- **Pasaje breve relacionado:** S03; **ubicación:** ACC/AHA 2025 hipertensión, categorías PA, Table 4.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0034: Sospecha de hipotensión ortostática (Presión arterial)

- **SI:** Caída de PAS >=20 O PAD >=10 mmHg en 3 min tras ponerse de pie
- **ENTONCES:** Evaluar ortostatismo y etiología
- **Variables:** pa_supina_y_de_pie, instante_postura; disponibilidad CONTEXTO_ADICIONAL.
- **Ventana:** Prueba postural 3 min; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRIBADO.
- **Confirmación necesaria:** Prueba ortostática validada.
- **Fuente declarada v03:** ESC_BP24 — https://academic.oup.com/eurheartj/article/45/38/3912/7741010.
- **Pasaje breve relacionado:** S04; **ubicación:** NICE NG136, 1.2.7–1.2.8.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0035: Patrón no-dipper (Presión arterial)

- **SI:** Caída media nocturna de PAS <10% respecto a día
- **ENTONCES:** Considerar revisión de riesgo HTA/OSA
- **Variables:** abpm_dia, abpm_noche; disponibilidad BASE.
- **Ventana:** ABPM día+noche; **Población:** Adultos >=18 años.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON.
- **Confirmación necesaria:** ABPM validada.
- **Fuente declarada v03:** ESC_BP24 — https://academic.oup.com/eurheartj/article/45/38/3912/7741010.
- **Pasaje breve relacionado:** S04; **ubicación:** NICE NG136, 1.2.7–1.2.8.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0036: Irregularidad PPG sugestiva de FA (Ritmo cardiaco)

- **SI:** Episodios recurrentes de irregularidad por algoritmo PPG validado
- **ENTONCES:** Obtener trazado ECG
- **Variables:** irregularidad_ppg, calidad_ppg; disponibilidad BASE.
- **Ventana:** Múltiples episodios; **Población:** Adultos >=18 años.
- **Prioridad:** CRIBADO; **Naturaleza:** SOSPECHA.
- **Confirmación necesaria:** ECG de una derivación o 12 derivaciones.
- **Fuente declarada v03:** ESC_AF24 — https://academic.oup.com/eurheartj/article/45/36/3314/7738779.
- **Pasaje breve relacionado:** S21; **ubicación:** ESC 2024 AF guideline, key message 10.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** ECG requerido para diagnosticar fibrilación auricular.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0037: Fibrilación auricular por ECG (Ritmo cardiaco)

- **SI:** ECG documenta FA y es interpretado por profesional competente
- **ENTONCES:** Activar valoración de anticoagulación/riesgo ictus
- **Variables:** ecg_interpretado; disponibilidad OPCIONAL.
- **Ventana:** ECG episodio; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRITERIO_ECG.
- **Confirmación necesaria:** Revisión clínica del ECG.
- **Fuente declarada v03:** ESC_AF24 — https://academic.oup.com/eurheartj/article/45/36/3314/7738779.
- **Pasaje breve relacionado:** S21; **ubicación:** ESC 2024 AF guideline, key message 10.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** ECG requerido para diagnosticar fibrilación auricular.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0038: Palpitación posible por irregularidad y FC elevada (Ritmo cardiaco)

- **SI:** Irregularidad PPG + FC reposo >100 en episodios repetidos
- **ENTONCES:** Confirmar posible taquiarritmia
- **Variables:** ppg_ritmo, fc_reposo; disponibilidad BASE.
- **Ventana:** Episodios; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** SOSPECHA.
- **Confirmación necesaria:** ECG/Holter.
- **Fuente declarada v03:** ESC_AF24 — https://academic.oup.com/eurheartj/article/45/36/3314/7738779.
- **Pasaje breve relacionado:** S21; **ubicación:** ESC 2024 AF guideline, key message 10.
- **Clasificación original:** EXPERIMENTAL_NO_VALIDADA; **revisión v04:** SOLO_INVESTIGACION_DESACTIVADA.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** ECG requerido para diagnosticar fibrilación auricular | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0039: Evaluar riesgo de evento ASCVD (Cardiovascular preventivo)

- **SI:** Variables PREVENT completas y población de aplicación apropiada
- **ENTONCES:** Calcular score PREVENT exacto sin imputaciones silenciosas
- **Variables:** edad, sexo_modelo, PAS, colesterol_total, HDL, diabetes, etc; disponibilidad BASE+OPCIONAL.
- **Ventana:** Evaluación periódica; **Población:** Adultos >=18 años.
- **Prioridad:** CRIBADO; **Naturaleza:** SCORE.
- **Confirmación necesaria:** Perfil lipídico y anamnesis pertinente.
- **Fuente declarada v03:** ACC_LIP26 — https://www.jacc.org/doi/10.1016/j.jacc.2025.11.016.
- **Pasaje breve relacionado:** S12; **ubicación:** ACC/AHA Dyslipidemia 2026, Section 4.2.3.7.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0040: ASCVD previa: prevención secundaria (Cardiovascular preventivo)

- **SI:** Antecedente de enfermedad aterosclerótica establecido
- **ENTONCES:** Activar ruta prevención secundaria; no aplicar score de riesgo primario
- **Variables:** infarto_ictus_PAD_conocido; disponibilidad BASE.
- **Ventana:** Actual y seguimiento; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** ANTECEDENTE.
- **Confirmación necesaria:** Evaluación especializada.
- **Fuente declarada v03:** ACC_LIP26 — https://www.jacc.org/doi/10.1016/j.jacc.2025.11.016.
- **Pasaje breve relacionado:** S12; **ubicación:** ACC/AHA Dyslipidemia 2026, Section 4.2.3.7.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0041: Enfermedad arterial periférica posible (Vascular periférico)

- **SI:** ABI <=0.90 en prueba validada
- **ENTONCES:** Valoración vascular
- **Variables:** indice_tobillo_brazo; disponibilidad OPCIONAL.
- **Ventana:** Prueba actual; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRITERIO_PRUEBA.
- **Confirmación necesaria:** Revisión Doppler/ABI.
- **Fuente declarada v03:** ESC_PAD24 — https://academic.oup.com/eurheartj/article/45/36/3538/7738955.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0042: Arterias no compresibles (Vascular periférico)

- **SI:** ABI >1.40
- **ENTONCES:** Considerar índice dedo-brazo y evaluación vascular
- **Variables:** indice_tobillo_brazo; disponibilidad OPCIONAL.
- **Ventana:** Prueba actual; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRITERIO_PRUEBA.
- **Confirmación necesaria:** TBI.
- **Fuente declarada v03:** ESC_PAD24 — https://academic.oup.com/eurheartj/article/45/36/3538/7738955.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0043: Riesgo alto de ictus en FA conocida (Cardiovascular preventivo)

- **SI:** FA confirmada + antecedentes vasculares o edad avanzada
- **ENTONCES:** Valorar riesgo embólico mediante score completo y prevención
- **Variables:** FA_confirmada, HTA, diabetes, edad, ictus_previo; disponibilidad BASE.
- **Ventana:** Actual; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** RIESGO.
- **Confirmación necesaria:** Evaluación cardiológica.
- **Fuente declarada v03:** ESC_AF24 — https://academic.oup.com/eurheartj/article/45/36/3314/7738779.
- **Pasaje breve relacionado:** S21; **ubicación:** ESC 2024 AF guideline, key message 10.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0044: Prediabetes por HbA1c (Glucosa)

- **SI:** 5.7 <= HbA1c <= 6.4 %
- **ENTONCES:** Intervención preventiva y seguimiento
- **Variables:** hba1c_pct; disponibilidad OPCIONAL.
- **Ventana:** Laboratorio actual; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** HbA1c laboratorio validado.
- **Fuente declarada v03:** ADA26 — https://diabetesjournals.org/care/article/49/Supplement_1/S27/163926/2-Diagnosis-and-Classification-of-Diabetes.
- **Pasaje breve relacionado:** S01; **ubicación:** ADA Standards of Care 2026, Section 2 / Table 2.1.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0045: Prediabetes por ayuno (Glucosa)

- **SI:** 100 <= glucosa plasmática ayuno <=125 mg/dL
- **ENTONCES:** Evaluación de prediabetes
- **Variables:** glucosa_plasma_ayuno; disponibilidad OPCIONAL.
- **Ventana:** Ayuno >=8 h; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** Repetición/otro laboratorio según criterio.
- **Fuente declarada v03:** ADA26 — https://diabetesjournals.org/care/article/49/Supplement_1/S27/163926/2-Diagnosis-and-Classification-of-Diabetes.
- **Pasaje breve relacionado:** S01; **ubicación:** ADA Standards of Care 2026, Section 2 / Table 2.1.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0046: Prediabetes por OGTT (Glucosa)

- **SI:** 140 <= OGTT plasma 2h <=199 mg/dL
- **ENTONCES:** Evaluación de prediabetes
- **Variables:** ogtt_2h; disponibilidad OPCIONAL.
- **Ventana:** 2 horas después 75 g; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** OGTT estandarizado.
- **Fuente declarada v03:** ADA26 — https://diabetesjournals.org/care/article/49/Supplement_1/S27/163926/2-Diagnosis-and-Classification-of-Diabetes.
- **Pasaje breve relacionado:** S01; **ubicación:** ADA Standards of Care 2026, Section 2 / Table 2.1.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0047: Posible diabetes por HbA1c (Glucosa)

- **SI:** HbA1c >=6.5 %
- **ENTONCES:** Confirmar diagnóstico, salvo hiperglucemia inequívoca
- **Variables:** hba1c_pct; disponibilidad OPCIONAL.
- **Ventana:** Prueba actual; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** Segunda prueba alterada.
- **Fuente declarada v03:** ADA26 — https://diabetesjournals.org/care/article/49/Supplement_1/S27/163926/2-Diagnosis-and-Classification-of-Diabetes.
- **Pasaje breve relacionado:** S01; **ubicación:** ADA Standards of Care 2026, Section 2 / Table 2.1.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0048: Posible diabetes por glucosa ayuno (Glucosa)

- **SI:** Glucosa plasmática ayuno >=126 mg/dL
- **ENTONCES:** Confirmar diagnóstico
- **Variables:** glucosa_plasma_ayuno; disponibilidad OPCIONAL.
- **Ventana:** Ayuno >=8h; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** Repetir laboratorio / otra prueba.
- **Fuente declarada v03:** ADA26 — https://diabetesjournals.org/care/article/49/Supplement_1/S27/163926/2-Diagnosis-and-Classification-of-Diabetes.
- **Pasaje breve relacionado:** S01; **ubicación:** ADA Standards of Care 2026, Section 2 / Table 2.1.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0049: Posible diabetes por OGTT (Glucosa)

- **SI:** OGTT plasma 2h >=200 mg/dL
- **ENTONCES:** Confirmación y evaluación
- **Variables:** ogtt_2h; disponibilidad OPCIONAL.
- **Ventana:** 2h tras 75 g; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** Laboratorio validado.
- **Fuente declarada v03:** ADA26 — https://diabetesjournals.org/care/article/49/Supplement_1/S27/163926/2-Diagnosis-and-Classification-of-Diabetes.
- **Pasaje breve relacionado:** S01; **ubicación:** ADA Standards of Care 2026, Section 2 / Table 2.1.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0050: Glucosa al azar muy elevada (Glucosa)

- **SI:** Glucosa plasmática al azar >=200 mg/dL sin síntomas documentados
- **ENTONCES:** Preguntar síntomas; confirmar diabetes o descartar crisis
- **Variables:** glucosa_plasma_aleatoria; disponibilidad OPCIONAL.
- **Ventana:** Prueba actual; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** SOSPECHA.
- **Confirmación necesaria:** Clínica + laboratorio.
- **Fuente declarada v03:** ADA26 — https://diabetesjournals.org/care/article/49/Supplement_1/S27/163926/2-Diagnosis-and-Classification-of-Diabetes.
- **Pasaje breve relacionado:** S01; **ubicación:** ADA Standards of Care 2026, Section 2 / Table 2.1.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0051: Hiperglucemia recurrente CGM (Glucosa)

- **SI:** Lecturas CGM >=180 mg/dL repetidas, sin diagnóstico previo
- **ENTONCES:** Considerar conversación clínica y pruebas plasmáticas, como exploración no validada
- **Variables:** cgm, calidad_cgm; disponibilidad BASE.
- **Ventana:** >=10–14 días; **Población:** Adultos >=18 años.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON.
- **Confirmación necesaria:** HbA1c/FPG/OGTT.
- **Fuente declarada v03:** ADA26 — https://diabetesjournals.org/care/article/49/Supplement_1/S27/163926/2-Diagnosis-and-Classification-of-Diabetes.
- **Pasaje breve relacionado:** S01; **ubicación:** ADA Standards of Care 2026, Section 2 / Table 2.1.
- **Clasificación original:** EXPERIMENTAL_NO_VALIDADA; **revisión v04:** SOLO_INVESTIGACION_DESACTIVADA.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0052: Hipoglucemia nivel 1 por CGM (Glucosa)

- **SI:** CGM <70 y >=54 mg/dL en diabetes tratada y lectura creíble
- **ENTONCES:** Advertir descenso de glucosa y seguir plan individual de manejo
- **Variables:** cgm, calidad_cgm; disponibilidad BASE.
- **Ventana:** Repetición inmediata/algoritmo de sensor; **Población:** Adultos >=18 años.
- **Prioridad:** URGENTE; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Capilar si lectura discordante.
- **Fuente declarada v03:** ADA_GLY26 — https://doi.org/10.2337/dc26-s006.
- **Pasaje breve relacionado:** S02; **ubicación:** ADA Standards of Care 2026, Section 6 / Table 6.2.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0053: Hipoglucemia nivel 2 por CGM (Glucosa)

- **SI:** CGM <54 mg/dL y señal creíble en diabetes
- **ENTONCES:** Aviso de acción inmediata conforme plan individual; confirmar capilar sin retrasar cuidados necesarios
- **Variables:** cgm, calidad_cgm; disponibilidad BASE.
- **Ventana:** Inmediato; **Población:** Adultos >=18 años.
- **Prioridad:** CRITICA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Glucosa capilar/plasmática.
- **Fuente declarada v03:** ADA_GLY26 — https://doi.org/10.2337/dc26-s006.
- **Pasaje breve relacionado:** S02; **ubicación:** ADA Standards of Care 2026, Section 6 / Table 6.2.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0054: Exceso de tiempo bajo rango (Glucosa)

- **SI:** Diabetes conocida, cobertura >=70% en 14d y TBR <70 mg/dL >4%
- **ENTONCES:** Revisión de terapia y patrones hipoglucémicos
- **Variables:** cgm_tbr, cgm_cobertura, diabetes_conocida; disponibilidad BASE.
- **Ventana:** 14 días; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** VIGILANCIA.
- **Confirmación necesaria:** Consulta de diabetes.
- **Fuente declarada v03:** ADA_GLY26 — https://doi.org/10.2337/dc26-s006.
- **Pasaje breve relacionado:** S02; **ubicación:** ADA Standards of Care 2026, Section 6 / Table 6.2.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0055: Exceso de hipoglucemia profunda (Glucosa)

- **SI:** Diabetes conocida, cobertura >=70% en 14d y TBR <54 mg/dL >1%
- **ENTONCES:** Revisión clínica prioritaria de seguridad
- **Variables:** cgm_tbr54, cgm_cobertura, diabetes_conocida; disponibilidad BASE.
- **Ventana:** 14 días; **Población:** Adultos >=18 años.
- **Prioridad:** URGENTE; **Naturaleza:** VIGILANCIA.
- **Confirmación necesaria:** Consulta de diabetes.
- **Fuente declarada v03:** ADA_GLY26 — https://doi.org/10.2337/dc26-s006.
- **Pasaje breve relacionado:** S02; **ubicación:** ADA Standards of Care 2026, Section 6 / Table 6.2.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0056: Posible cetoacidosis diabética (DKA) (Glucosa)

- **SI:** (diabetes conocida O glucosa plasma >=200) Y BHB >=3 mmol/L Y (pH<7.3 O HCO3<18)
- **ENTONCES:** Emergencia hospitalaria
- **Variables:** diabetes_previa/glucosa_plasma, betahidroxibutirato, pH/bicarbonato; disponibilidad BASE+OPCIONAL.
- **Ventana:** Mismo episodio agudo; **Población:** Adultos >=18 años.
- **Prioridad:** CRITICA; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** Pruebas de cetonas/acidosis y evaluación urgente.
- **Fuente declarada v03:** ADA_HOSP26 — https://doi.org/10.2337/dc26-s016.
- **Pasaje breve relacionado:** S02; **ubicación:** ADA Standards of Care 2026, Section 6 / Table 6.2.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0057: Posible estado hiperosmolar HHS (Glucosa)

- **SI:** Glucosa plasma >=600 + osmolalidad efectiva >300 o total >320 + sin cetosis/acidosis significativa
- **ENTONCES:** Emergencia hospitalaria
- **Variables:** glucosa_plasma, osmolaridad, BHB, pH/bicarbonato; disponibilidad OPCIONAL.
- **Ventana:** Mismo episodio agudo; **Población:** Adultos >=18 años.
- **Prioridad:** CRITICA; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** Panel clínico y osmolaridad.
- **Fuente declarada v03:** ADA_HOSP26 — https://doi.org/10.2337/dc26-s016.
- **Pasaje breve relacionado:** S02; **ubicación:** ADA Standards of Care 2026, Section 6 / Table 6.2.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0058: Cetonemia marcada con diabetes (Glucosa)

- **SI:** BHB >=3 mmol/L en persona con diabetes, aun si CGM normal
- **ENTONCES:** Valoración médica inmediata de acidosis
- **Variables:** BHB, diabetes_previa; disponibilidad BASE+OPCIONAL.
- **Ventana:** Actual; **Población:** Adultos >=18 años.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON.
- **Confirmación necesaria:** pH, HCO3, electrolitos.
- **Fuente declarada v03:** ADA_HOSP26 — https://doi.org/10.2337/dc26-s016.
- **Pasaje breve relacionado:** S02; **ubicación:** ADA Standards of Care 2026, Section 6 / Table 6.2.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0059: Revisión de riesgo por diabetes gestacional previa (Glucosa)

- **SI:** Antecedente DM gestacional y cribado no realizado hace >=1–3 años
- **ENTONCES:** Solicitar cribado periódico de diabetes
- **Variables:** diabetes_gestacional_previa, fecha_ultimo_cribado; disponibilidad BASE.
- **Ventana:** Anual-trienal; **Población:** Adultos >=18 años.
- **Prioridad:** CRIBADO; **Naturaleza:** ANTECEDENTE.
- **Confirmación necesaria:** FPG/HbA1c/OGTT según contexto.
- **Fuente declarada v03:** ADA_GDM26 — https://diabetesjournals.org/care/article/49/Supplement_1/S27/163926/2-Diagnosis-and-Classification-of-Diabetes.
- **Pasaje breve relacionado:** S01; **ubicación:** ADA Standards of Care 2026, Section 2 / Table 2.1.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0060: Cribado DM tipo 2 por edad (Glucosa)

- **SI:** Edad >=35 años sin diabetes conocida y sin cribado documentado
- **ENTONCES:** Proponer prueba validada de diabetes
- **Variables:** edad, diagnostico_dm; disponibilidad BASE.
- **Ventana:** Periódico; **Población:** Adultos >=18 años.
- **Prioridad:** CRIBADO; **Naturaleza:** RIESGO.
- **Confirmación necesaria:** FPG o HbA1c.
- **Fuente declarada v03:** ADA26 — https://diabetesjournals.org/care/article/49/Supplement_1/S27/163926/2-Diagnosis-and-Classification-of-Diabetes.
- **Pasaje breve relacionado:** S01; **ubicación:** ADA Standards of Care 2026, Section 2 / Table 2.1.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0061: Síndrome metabólico posible (Metabolismo)

- **SI:** Al menos 3/5: cintura umbral poblacional, TG>=150, HDL bajo, PA>=130/85, FPG>=100
- **ENTONCES:** Valorar riesgo metabólico
- **Variables:** cintura, TG, HDL, PA, glucosa_ayuno; disponibilidad BASE+OPCIONAL.
- **Ventana:** Mediciones contemporáneas; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** Perfil lipídico + FPG.
- **Fuente declarada v03:** ACC_LIP26 — https://www.jacc.org/doi/10.1016/j.jacc.2025.11.016.
- **Pasaje breve relacionado:** S12; **ubicación:** ACC/AHA Dyslipidemia 2026, Section 4.2.3.7.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0062: LDL muy elevado (Lípidos)

- **SI:** LDL >=190 mg/dL
- **ENTONCES:** Evaluar hipercolesterolemia severa, familiar y causas secundarias
- **Variables:** ldl_mgdl; disponibilidad OPCIONAL.
- **Ventana:** Panel actual; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** Perfil lipídico/consulta.
- **Fuente declarada v03:** ACC_LIP26 — https://www.jacc.org/doi/10.1016/j.jacc.2025.11.016.
- **Pasaje breve relacionado:** S12; **ubicación:** ACC/AHA Dyslipidemia 2026, Section 4.2.3.7.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0063: LDL moderadamente elevado y riesgo familiar (Lípidos)

- **SI:** LDL >=160 mg/dL y antecedente familiar de ASCVD precoz
- **ENTONCES:** Evaluar prevención lipídica intensificada
- **Variables:** ldl_mgdl, enfermedad_cv_familiar; disponibilidad BASE+OPCIONAL.
- **Ventana:** Panel actual; **Población:** Adultos >=18 años.
- **Prioridad:** CRIBADO; **Naturaleza:** RIESGO.
- **Confirmación necesaria:** Historia familiar verificada.
- **Fuente declarada v03:** ACC_LIP26 — https://www.jacc.org/doi/10.1016/j.jacc.2025.11.016.
- **Pasaje breve relacionado:** S12; **ubicación:** ACC/AHA Dyslipidemia 2026, Section 4.2.3.7.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0064: Hipertrigliceridemia leve/moderada (Lípidos)

- **SI:** TG en ayuno >=150 y <500 mg/dL
- **ENTONCES:** Investigar causas y riesgo cardiovascular
- **Variables:** tg_mgdl; disponibilidad OPCIONAL.
- **Ventana:** Panel actual; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** Perfil lipídico.
- **Fuente declarada v03:** ACC_LIP26 — https://www.jacc.org/doi/10.1016/j.jacc.2025.11.016.
- **Pasaje breve relacionado:** S12; **ubicación:** ACC/AHA Dyslipidemia 2026, Section 4.2.3.7.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0065: Hipertrigliceridemia severa (Lípidos)

- **SI:** TG >=500 y <1000 mg/dL
- **ENTONCES:** Evaluación pronta por aumento de riesgo de pancreatitis
- **Variables:** tg_mgdl; disponibilidad OPCIONAL.
- **Ventana:** Panel actual; **Población:** Adultos >=18 años.
- **Prioridad:** URGENTE; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** Repetir/valorar perfil y causas.
- **Fuente declarada v03:** ACC_LIP26 — https://www.jacc.org/doi/10.1016/j.jacc.2025.11.016.
- **Pasaje breve relacionado:** S12; **ubicación:** ACC/AHA Dyslipidemia 2026, Section 4.2.3.7.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0066: Hipertrigliceridemia extrema (Lípidos)

- **SI:** TG >=1000 mg/dL
- **ENTONCES:** Evaluación clínica prioritaria por mayor riesgo de pancreatitis
- **Variables:** tg_mgdl; disponibilidad OPCIONAL.
- **Ventana:** Panel actual; **Población:** Adultos >=18 años.
- **Prioridad:** URGENTE; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** Consulta médica.
- **Fuente declarada v03:** ACC_LIP26 — https://www.jacc.org/doi/10.1016/j.jacc.2025.11.016.
- **Pasaje breve relacionado:** S12; **ubicación:** ACC/AHA Dyslipidemia 2026, Section 4.2.3.7.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0067: HDL bajo (Lípidos)

- **SI:** HDL <40 mg/dL (varón) o <50 (mujer)
- **ENTONCES:** Evaluar factores cardiometabólicos
- **Variables:** hdl_mgdl, sexo_clinico; disponibilidad OPCIONAL.
- **Ventana:** Panel actual; **Población:** Adultos >=18 años.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** Perfil lipídico.
- **Fuente declarada v03:** ACC_LIP26 — https://www.jacc.org/doi/10.1016/j.jacc.2025.11.016.
- **Pasaje breve relacionado:** S12; **ubicación:** ACC/AHA Dyslipidemia 2026, Section 4.2.3.7.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0068: Fibrosis avanzada improbable por FIB-4 (Hígado)

- **SI:** FIB-4 <1.3 con edad 35–65 y contexto MASLD
- **ENTONCES:** Reevaluación periódica si persiste riesgo
- **Variables:** edad, ast, alt, plaquetas; disponibilidad OPCIONAL.
- **Ventana:** Laboratorio reciente; **Población:** Adultos >=18 años.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** SCORE.
- **Confirmación necesaria:** FIB-4 + contexto clínico.
- **Fuente declarada v03:** AASLD_MASLD — https://pubmed.ncbi.nlm.nih.gov/38445559/.
- **Pasaje breve relacionado:** S15; **ubicación:** AASLD Practice Guidance 2023 (update MASLD 2024), Figure 2.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** FIB-4 no es porcentaje; no durante enfermedad aguda; ajustar por edad.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0069: FIB-4 indeterminado/alto (35–65) (Hígado)

- **SI:** Edad 35–65 y FIB-4 >=1.3
- **ENTONCES:** Solicitar elastografía o prueba secundaria
- **Variables:** edad, ast, alt, plaquetas; disponibilidad OPCIONAL.
- **Ventana:** Laboratorio reciente; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** SCORE.
- **Confirmación necesaria:** VCTE/ELF.
- **Fuente declarada v03:** AASLD_MASLD — https://pubmed.ncbi.nlm.nih.gov/38445559/.
- **Pasaje breve relacionado:** S15; **ubicación:** AASLD Practice Guidance 2023 (update MASLD 2024), Figure 2.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** FIB-4 no es porcentaje; no durante enfermedad aguda; ajustar por edad.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0070: FIB-4 elevado en mayores (Hígado)

- **SI:** Edad >65 y FIB-4 >2.0
- **ENTONCES:** Evaluación secundaria de fibrosis
- **Variables:** edad, ast, alt, plaquetas; disponibilidad OPCIONAL.
- **Ventana:** Laboratorio reciente; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** SCORE.
- **Confirmación necesaria:** VCTE/ELF.
- **Fuente declarada v03:** AASLD_MASLD — https://pubmed.ncbi.nlm.nih.gov/38445559/.
- **Pasaje breve relacionado:** S15; **ubicación:** AASLD Practice Guidance 2023 (update MASLD 2024), Figure 2.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** FIB-4 no es porcentaje; no durante enfermedad aguda; ajustar por edad.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0071: FIB-4 muy alto (Hígado)

- **SI:** FIB-4 >2.67, edad válida para interpretación
- **ENTONCES:** Considerar valoración hepatológica
- **Variables:** edad, ast, alt, plaquetas; disponibilidad OPCIONAL.
- **Ventana:** Laboratorio reciente; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** SCORE.
- **Confirmación necesaria:** VCTE/ELF y especialista.
- **Fuente declarada v03:** AASLD_MASLD — https://pubmed.ncbi.nlm.nih.gov/38445559/.
- **Pasaje breve relacionado:** S15; **ubicación:** AASLD Practice Guidance 2023 (update MASLD 2024), Figure 2.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** FIB-4 no es porcentaje; no durante enfermedad aguda; ajustar por edad.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0072: Enzimas hepáticas persistentes elevadas (Hígado)

- **SI:** ALT o AST sobre LSN laboratorio durante >6 meses
- **ENTONCES:** Evaluación de causas hepatocelulares
- **Variables:** alt, ast, limite_superior_lab; disponibilidad OPCIONAL.
- **Ventana:** >=6 meses; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON.
- **Confirmación necesaria:** Perfil hepático y evaluación clínica.
- **Fuente declarada v03:** AASLD_MASLD — https://pubmed.ncbi.nlm.nih.gov/38445559/.
- **Pasaje breve relacionado:** S15; **ubicación:** AASLD Practice Guidance 2023 (update MASLD 2024), Figure 2.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** FIB-4 no es porcentaje; no durante enfermedad aguda; ajustar por edad.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0073: Riesgo de MASLD asociado a metabolismo (Hígado)

- **SI:** Obesidad o DM2 + otros factores metabólicos
- **ENTONCES:** Evaluación hepatometabólica; definir necesidad de laboratorio
- **Variables:** obesidad, diabetes, hipertension; disponibilidad BASE.
- **Ventana:** Seguimiento; **Población:** Adultos >=18 años.
- **Prioridad:** CRIBADO; **Naturaleza:** RIESGO.
- **Confirmación necesaria:** ALT, AST, plaquetas y luego FIB-4.
- **Fuente declarada v03:** AASLD_MASLD — https://pubmed.ncbi.nlm.nih.gov/38445559/.
- **Pasaje breve relacionado:** S15; **ubicación:** AASLD Practice Guidance 2023 (update MASLD 2024), Figure 2.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** FIB-4 no es porcentaje; no durante enfermedad aguda; ajustar por edad | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0074: ERC por eGFR persistentemente bajo (Riñón)

- **SI:** eGFR <60 mL/min/1.73m² persistente >=3 meses
- **ENTONCES:** Valorar ERC y clasificar KDIGO
- **Variables:** egfr, fecha_egfr; disponibilidad OPCIONAL.
- **Ventana:** >=3 meses; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** eGFR CKD-EPI sin raza + ACR.
- **Fuente declarada v03:** KDIGO_CKD24 — https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf.
- **Pasaje breve relacionado:** S05; **ubicación:** KDIGO 2024 ERC, Practice Point 2.2.1, página S156.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0075: Albuminuria persistente (Riñón)

- **SI:** ACR >=30 mg/g persistente >=3 meses
- **ENTONCES:** Valorar daño renal y riesgo
- **Variables:** acr_urinaria; disponibilidad OPCIONAL.
- **Ventana:** >=3 meses; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** ACR primera orina / evolución.
- **Fuente declarada v03:** KDIGO_CKD24 — https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf.
- **Pasaje breve relacionado:** S05; **ubicación:** KDIGO 2024 ERC, Practice Point 2.2.1, página S156.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0076: Albuminuria alta (Riñón)

- **SI:** ACR >300 mg/g
- **ENTONCES:** Evaluación nefrológica y riesgo cardiovascular
- **Variables:** acr_urinaria; disponibilidad OPCIONAL.
- **Ventana:** Actual, confirmar; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** Repetir ACR.
- **Fuente declarada v03:** KDIGO_CKD24 — https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf.
- **Pasaje breve relacionado:** S05; **ubicación:** KDIGO 2024 ERC, Practice Point 2.2.1, página S156.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0077: Deterioro renal importante (Riñón)

- **SI:** eGFR <30 mL/min/1.73m² en resultado nuevo
- **ENTONCES:** Valoración pronta; distinguir crónico vs agudo
- **Variables:** egfr; disponibilidad OPCIONAL.
- **Ventana:** Laboratorio actual; **Población:** Adultos >=18 años.
- **Prioridad:** URGENTE; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** Creatinina seriada, ACR, clínica.
- **Fuente declarada v03:** KDIGO_CKD24 — https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf.
- **Pasaje breve relacionado:** S05; **ubicación:** KDIGO 2024 ERC, Practice Point 2.2.1, página S156.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0078: Lesión renal aguda: incremento absoluto (Riñón)

- **SI:** Creatinina sube >=0.3 mg/dL en <=48h
- **ENTONCES:** Evaluar AKI rápidamente
- **Variables:** creatinina_serie; disponibilidad OPCIONAL.
- **Ventana:** 48h; **Población:** Adultos >=18 años.
- **Prioridad:** URGENTE; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** Repetición e investigación clínica.
- **Fuente declarada v03:** NICE_AKI — https://www.nice.org.uk/guidance/ng148/chapter/Recommendations.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0079: Lesión renal aguda: incremento relativo (Riñón)

- **SI:** Creatinina >=1.5x basal en <=7 días
- **ENTONCES:** Evaluar AKI rápidamente
- **Variables:** creatinina_serie; disponibilidad OPCIONAL.
- **Ventana:** 7 días; **Población:** Adultos >=18 años.
- **Prioridad:** URGENTE; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** Repetición e investigación clínica.
- **Fuente declarada v03:** NICE_AKI — https://www.nice.org.uk/guidance/ng148/chapter/Recommendations.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0080: Oliguria (Riñón)

- **SI:** Diuresis <0.5 mL/kg/h durante >=6 h
- **ENTONCES:** Evaluar AKI/obstrucción/hipovolemia
- **Variables:** volumen_orina, peso; disponibilidad CONTEXTO_ADICIONAL.
- **Ventana:** >=6h; **Población:** Adultos >=18 años.
- **Prioridad:** URGENTE; **Naturaleza:** CRITERIO_PRUEBA.
- **Confirmación necesaria:** Diuresis y creatinina.
- **Fuente declarada v03:** NICE_AKI — https://www.nice.org.uk/guidance/ng148/chapter/Recommendations.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0081: Riesgo renal en diabetes/hipertensión (Riñón)

- **SI:** Diabetes o HTA previa con función renal no evaluada
- **ENTONCES:** Proponer ACR/eGFR
- **Variables:** DM_conocida, HTA_conocida; disponibilidad BASE.
- **Ventana:** Periódico; **Población:** Adultos >=18 años.
- **Prioridad:** CRIBADO; **Naturaleza:** RIESGO.
- **Confirmación necesaria:** Creatinina, ACR.
- **Fuente declarada v03:** KDIGO_CKD24 — https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf.
- **Pasaje breve relacionado:** S05; **ubicación:** KDIGO 2024 ERC, Practice Point 2.2.1, página S156.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0082: Anemia adulto varón (Hematología)

- **SI:** Hb <13.0 g/dL en varón adulto
- **ENTONCES:** Evaluar anemia y causas
- **Variables:** hb_gdl, sexo_clinico; disponibilidad OPCIONAL.
- **Ventana:** Laboratorio actual; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** BH con índices y hierro.
- **Fuente declarada v03:** WHO_HB24 — https://www.ncbi.nlm.nih.gov/books/NBK602183/table/fm-ch1.tab2/.
- **Pasaje breve relacionado:** S08; **ubicación:** OMS 2024, Table 3: Haemoglobin cutoffs / anaemia severity.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0083: Anemia mujer no embarazada (Hematología)

- **SI:** Hb <12.0 g/dL en mujer no embarazada
- **ENTONCES:** Evaluar anemia y causas
- **Variables:** hb_gdl, embarazo; disponibilidad OPCIONAL.
- **Ventana:** Laboratorio actual; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** BH/ferropenia.
- **Fuente declarada v03:** WHO_HB24 — https://www.ncbi.nlm.nih.gov/books/NBK602183/table/fm-ch1.tab2/.
- **Pasaje breve relacionado:** S08; **ubicación:** OMS 2024, Table 3: Haemoglobin cutoffs / anaemia severity.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0084: Anemia severa en no embarazada (Hematología)

- **SI:** Hb <8.0 g/dL en adulto no embarazado
- **ENTONCES:** Valoración médica prioritaria
- **Variables:** hb_gdl, embarazo; disponibilidad OPCIONAL.
- **Ventana:** Laboratorio actual; **Población:** Adultos >=18 años.
- **Prioridad:** URGENTE; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** BH, signos clínicos, causas.
- **Fuente declarada v03:** WHO_HBSEV24 — https://www.ncbi.nlm.nih.gov/books/NBK602183/table/fm-ch1.tab2/.
- **Pasaje breve relacionado:** S08; **ubicación:** OMS 2024, Table 3: Haemoglobin cutoffs / anaemia severity.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0085: Anemia gestacional primer trimestre (Hematología)

- **SI:** Embarazo 1er trimestre y Hb <11.0 g/dL
- **ENTONCES:** Evaluación obstétrica/nutricional
- **Variables:** hb_gdl, trimestre; disponibilidad OPCIONAL.
- **Ventana:** Actual; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** BH y hierro.
- **Fuente declarada v03:** WHO_HB24 — https://www.ncbi.nlm.nih.gov/books/NBK602183/table/fm-ch1.tab2/.
- **Pasaje breve relacionado:** S08; **ubicación:** OMS 2024, Table 3: Haemoglobin cutoffs / anaemia severity.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0086: Anemia gestacional segundo trimestre (Hematología)

- **SI:** Embarazo 2º trimestre y Hb <10.5 g/dL
- **ENTONCES:** Evaluación obstétrica
- **Variables:** hb_gdl, trimestre; disponibilidad OPCIONAL.
- **Ventana:** Actual; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** BH y hierro.
- **Fuente declarada v03:** WHO_HB24 — https://www.ncbi.nlm.nih.gov/books/NBK602183/table/fm-ch1.tab2/.
- **Pasaje breve relacionado:** S08; **ubicación:** OMS 2024, Table 3: Haemoglobin cutoffs / anaemia severity.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0087: Anemia gestacional tercer trimestre (Hematología)

- **SI:** Embarazo 3er trimestre y Hb <11.0 g/dL
- **ENTONCES:** Evaluación obstétrica
- **Variables:** hb_gdl, trimestre; disponibilidad OPCIONAL.
- **Ventana:** Actual; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** BH y hierro.
- **Fuente declarada v03:** WHO_HB24 — https://www.ncbi.nlm.nih.gov/books/NBK602183/table/fm-ch1.tab2/.
- **Pasaje breve relacionado:** S08; **ubicación:** OMS 2024, Table 3: Haemoglobin cutoffs / anaemia severity.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0088: Anemia microcítica (Hematología)

- **SI:** Anemia confirmada y VCM <80 fL
- **ENTONCES:** Solicitar ferritina y estudio de hierro
- **Variables:** hb_gdl, vcm_fl; disponibilidad OPCIONAL.
- **Ventana:** Misma BH; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON.
- **Confirmación necesaria:** Perfil férrico.
- **Fuente declarada v03:** WHO_HB24 — https://www.ncbi.nlm.nih.gov/books/NBK602183/table/fm-ch1.tab2/.
- **Pasaje breve relacionado:** S08; **ubicación:** OMS 2024, Table 3: Haemoglobin cutoffs / anaemia severity.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0089: Anemia macrocítica (Hematología)

- **SI:** Anemia confirmada y VCM >100 fL
- **ENTONCES:** Estudiar B12, folato, tiroides, hígado y fármacos
- **Variables:** hb_gdl, vcm_fl; disponibilidad OPCIONAL.
- **Ventana:** Misma BH; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON.
- **Confirmación necesaria:** B12, folato, TSH.
- **Fuente declarada v03:** WHO_HB24 — https://www.ncbi.nlm.nih.gov/books/NBK602183/table/fm-ch1.tab2/.
- **Pasaje breve relacionado:** S08; **ubicación:** OMS 2024, Table 3: Haemoglobin cutoffs / anaemia severity.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0090: Caída acelerada de Hb (Hematología)

- **SI:** Disminución significativa de Hb en análisis consecutivos
- **ENTONCES:** Valoración según magnitud y síntomas
- **Variables:** hb_gdl_serie; disponibilidad OPCIONAL.
- **Ventana:** Días-semanas; **Población:** Adultos >=18 años.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON.
- **Confirmación necesaria:** Repetir BH/estudio hemorragia.
- **Fuente declarada v03:** WHO_HB24 — https://www.ncbi.nlm.nih.gov/books/NBK602183/table/fm-ch1.tab2/.
- **Pasaje breve relacionado:** S08; **ubicación:** OMS 2024, Table 3: Haemoglobin cutoffs / anaemia severity.
- **Clasificación original:** EXPERIMENTAL_NO_VALIDADA; **revisión v04:** SOLO_INVESTIGACION_DESACTIVADA.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0091: Neutropenia severa (Hematología)

- **SI:** Recuento absoluto de neutrófilos ANC <500/µL
- **ENTONCES:** Evaluación prioritaria del riesgo infeccioso
- **Variables:** anc_celul_uL; disponibilidad OPCIONAL.
- **Ventana:** BH actual; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** BH y evaluación clínica.
- **Fuente declarada v03:** IDSA_NEUTRO — https://www.cancercare.mb.ca/export/sites/default/For-Health-Professionals/.galleries/files/treatment-guidelines-rro-files/practice-guidelines/supportive-care/CCMB-Neutropenia-Protocol-and-Algorithms-2017.pdf.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0092: Neutropenia febril (Hematología)

- **SI:** ANC <500/µL + fiebre oral >=38.3 °C una vez O >=38 °C >=1h
- **ENTONCES:** Urgencia hospitalaria por neutropenia febril
- **Variables:** anc, temperatura_clinica; disponibilidad BASE+OPCIONAL.
- **Ventana:** Mismo episodio; **Población:** Adultos >=18 años.
- **Prioridad:** CRITICA; **Naturaleza:** PATRON.
- **Confirmación necesaria:** Evaluación clínica inmediata.
- **Fuente declarada v03:** IDSA_NEUTRO — https://www.cancercare.mb.ca/export/sites/default/For-Health-Professionals/.galleries/files/treatment-guidelines-rro-files/practice-guidelines/supportive-care/CCMB-Neutropenia-Protocol-and-Algorithms-2017.pdf.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0093: Plaquetopenia notable (Hematología)

- **SI:** Plaquetas <50,000/µL
- **ENTONCES:** Valorar riesgo hemorrágico y causa
- **Variables:** plaquetas_uL; disponibilidad OPCIONAL.
- **Ventana:** BH actual; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** BH repetida y frotis.
- **Fuente declarada v03:** AABB_PLT25 — https://pubmed.ncbi.nlm.nih.gov/40440268/.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0094: Plaquetas extremadamente bajas (Hematología)

- **SI:** Plaquetas <10,000/µL
- **ENTONCES:** Valoración hospitalaria urgente de sangrado y etiología
- **Variables:** plaquetas_uL; disponibilidad OPCIONAL.
- **Ventana:** BH actual; **Población:** Adultos >=18 años.
- **Prioridad:** URGENTE; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** Repetición si pseudotrombocitopenia.
- **Fuente declarada v03:** AABB_PLT25 — https://pubmed.ncbi.nlm.nih.gov/40440268/.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0095: Leucocitosis (Hematología)

- **SI:** Leucocitos >11,000/µL
- **ENTONCES:** Investigar causas según contexto
- **Variables:** leucocitos_uL; disponibilidad OPCIONAL.
- **Ventana:** BH actual; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** BH diferencial, clínica.
- **Fuente declarada v03:** WHO_HB24 — https://www.ncbi.nlm.nih.gov/books/NBK602183/table/fm-ch1.tab2/.
- **Pasaje breve relacionado:** S08; **ubicación:** OMS 2024, Table 3: Haemoglobin cutoffs / anaemia severity.
- **Clasificación original:** EXPERIMENTAL_NO_VALIDADA; **revisión v04:** SOLO_INVESTIGACION_DESACTIVADA.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0096: Leucopenia (Hematología)

- **SI:** Leucocitos <4,000/µL
- **ENTONCES:** Revisar diferencial, fármacos, infecciones
- **Variables:** leucocitos_uL; disponibilidad OPCIONAL.
- **Ventana:** BH actual; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** Repetición BH diferencial.
- **Fuente declarada v03:** WHO_HB24 — https://www.ncbi.nlm.nih.gov/books/NBK602183/table/fm-ch1.tab2/.
- **Pasaje breve relacionado:** S08; **ubicación:** OMS 2024, Table 3: Haemoglobin cutoffs / anaemia severity.
- **Clasificación original:** EXPERIMENTAL_NO_VALIDADA; **revisión v04:** SOLO_INVESTIGACION_DESACTIVADA.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0097: Ferropenia en contexto de anemia (Hematología)

- **SI:** Anemia + ferritina <45 ng/mL
- **ENTONCES:** Investigar ferropenia y etiología
- **Variables:** anemia, ferritina; disponibilidad OPCIONAL.
- **Ventana:** Mismo episodio; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** Perfil férrico, clínica.
- **Fuente declarada v03:** AGA_FERR — https://gastro.org/clinical-guidance/gastrointestinal-evaluation-of-iron-deficiency-anemia/.
- **Pasaje breve relacionado:** S18; **ubicación:** AGA 2020 Guideline, Recommendations point 1.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0098: Deficiencia B12 muy probable (Hematología)

- **SI:** B12 total <180 ng/L (133 pmol/L)
- **ENTONCES:** Evaluar y tratar según criterio clínico
- **Variables:** b12_total_ngL; disponibilidad OPCIONAL.
- **Ventana:** Laboratorio actual; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** Interpretar ensayo; confirmar si procede.
- **Fuente declarada v03:** NICE_B12 — https://www.nice.org.uk/guidance/ng239/chapter/Recommendations.
- **Pasaje breve relacionado:** S17; **ubicación:** NICE NG239, Table 1 total or active B12.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0099: B12 indeterminada (Hematología)

- **SI:** B12 total 180–350 ng/L
- **ENTONCES:** Considerar ácido metilmalónico según clínica
- **Variables:** b12_total_ngL; disponibilidad OPCIONAL.
- **Ventana:** Laboratorio actual; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** MMA y laboratorio.
- **Fuente declarada v03:** NICE_B12 — https://www.nice.org.uk/guidance/ng239/chapter/Recommendations.
- **Pasaje breve relacionado:** S17; **ubicación:** NICE NG239, Table 1 total or active B12.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0100: Hiponatremia leve (Electrolitos)

- **SI:** Na 130–134 mmol/L
- **ENTONCES:** Investigar según síntomas/tiempo/volemia
- **Variables:** sodio_mmolL; disponibilidad OPCIONAL.
- **Ventana:** Actual; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** Repetir sodio; clínica.
- **Fuente declarada v03:** ENDO_NA — https://academic.oup.com/ejendo/article/170/3/G1/6668028.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** revisar hemólisis, recolección, laboratorio y contexto.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0101: Hiponatremia moderada (Electrolitos)

- **SI:** Na 125–129 mmol/L
- **ENTONCES:** Valoración clínica pronta
- **Variables:** sodio_mmolL; disponibilidad OPCIONAL.
- **Ventana:** Actual; **Población:** Adultos >=18 años.
- **Prioridad:** URGENTE; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** Confirmar sodio y osmolalidad.
- **Fuente declarada v03:** ENDO_NA — https://academic.oup.com/ejendo/article/170/3/G1/6668028.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** revisar hemólisis, recolección, laboratorio y contexto.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0102: Hiponatremia profunda (Electrolitos)

- **SI:** Na <125 mmol/L
- **ENTONCES:** Evaluación urgente según síntomas
- **Variables:** sodio_mmolL; disponibilidad OPCIONAL.
- **Ventana:** Actual; **Población:** Adultos >=18 años.
- **Prioridad:** URGENTE; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** Sodio, osmolalidad, evaluación neurológica.
- **Fuente declarada v03:** ENDO_NA — https://academic.oup.com/ejendo/article/170/3/G1/6668028.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** revisar hemólisis, recolección, laboratorio y contexto.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0103: Hipercalemia leve (Electrolitos)

- **SI:** K 5.5–5.9 mmol/L
- **ENTONCES:** Revisar causas, función renal y hemólisis
- **Variables:** potasio_mmolL; disponibilidad OPCIONAL.
- **Ventana:** Actual; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** Repetir K y creatinina.
- **Fuente declarada v03:** UKKA_K23 — https://www.ukkidney.org/sites/renal.org/files/FINAL%20VERSION%20-%20UKKA%20CLINICAL%20PRACTICE%20GUIDELINE%20-%20MANAGEMENT%20OF%20HYPERKALAEMIA%20IN%20ADULTS%20-%20191223.pdf.
- **Pasaje breve relacionado:** S07; **ubicación:** UK Kidney Association 2026, Introduction / Hyperkalaemia severity.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** revisar hemólisis, recolección, laboratorio y contexto.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0104: Hipercalemia moderada (Electrolitos)

- **SI:** K 6.0–6.4 mmol/L
- **ENTONCES:** Evaluación prioritaria, especialmente AKI/enfermedad aguda
- **Variables:** potasio_mmolL; disponibilidad OPCIONAL.
- **Ventana:** Actual; **Población:** Adultos >=18 años.
- **Prioridad:** URGENTE; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** ECG y confirmación si procede.
- **Fuente declarada v03:** UKKA_K23 — https://www.ukkidney.org/sites/renal.org/files/FINAL%20VERSION%20-%20UKKA%20CLINICAL%20PRACTICE%20GUIDELINE%20-%20MANAGEMENT%20OF%20HYPERKALAEMIA%20IN%20ADULTS%20-%20191223.pdf.
- **Pasaje breve relacionado:** S07; **ubicación:** UK Kidney Association 2026, Introduction / Hyperkalaemia severity.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** revisar hemólisis, recolección, laboratorio y contexto.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0105: Hipercalemia grave (Electrolitos)

- **SI:** K >=6.5 mmol/L
- **ENTONCES:** Evaluación hospitalaria urgente
- **Variables:** potasio_mmolL; disponibilidad OPCIONAL.
- **Ventana:** Actual; **Población:** Adultos >=18 años.
- **Prioridad:** CRITICA; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** ECG y laboratorio.
- **Fuente declarada v03:** UKKA_K23 — https://www.ukkidney.org/sites/renal.org/files/FINAL%20VERSION%20-%20UKKA%20CLINICAL%20PRACTICE%20GUIDELINE%20-%20MANAGEMENT%20OF%20HYPERKALAEMIA%20IN%20ADULTS%20-%20191223.pdf.
- **Pasaje breve relacionado:** S07; **ubicación:** UK Kidney Association 2026, Introduction / Hyperkalaemia severity.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** revisar hemólisis, recolección, laboratorio y contexto.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0106: Hipocalemia por laboratorio (Electrolitos)

- **SI:** K <3.5 mmol/L
- **ENTONCES:** Revisar causas y ECG según contexto
- **Variables:** potasio_mmolL; disponibilidad OPCIONAL.
- **Ventana:** Actual; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** Repetir K, Mg, ECG si grave.
- **Fuente declarada v03:** UKKA_K23 — https://www.ukkidney.org/sites/renal.org/files/FINAL%20VERSION%20-%20UKKA%20CLINICAL%20PRACTICE%20GUIDELINE%20-%20MANAGEMENT%20OF%20HYPERKALAEMIA%20IN%20ADULTS%20-%20191223.pdf.
- **Pasaje breve relacionado:** S07; **ubicación:** UK Kidney Association 2026, Introduction / Hyperkalaemia severity.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** revisar hemólisis, recolección, laboratorio y contexto | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0107: Hipocalemia profunda (Electrolitos)

- **SI:** K <2.5 mmol/L
- **ENTONCES:** Evaluación urgente por riesgo de arritmias
- **Variables:** potasio_mmolL; disponibilidad OPCIONAL.
- **Ventana:** Actual; **Población:** Adultos >=18 años.
- **Prioridad:** URGENTE; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** ECG, K, Mg.
- **Fuente declarada v03:** UKKA_K23 — https://www.ukkidney.org/sites/renal.org/files/FINAL%20VERSION%20-%20UKKA%20CLINICAL%20PRACTICE%20GUIDELINE%20-%20MANAGEMENT%20OF%20HYPERKALAEMIA%20IN%20ADULTS%20-%20191223.pdf.
- **Pasaje breve relacionado:** S07; **ubicación:** UK Kidney Association 2026, Introduction / Hyperkalaemia severity.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** revisar hemólisis, recolección, laboratorio y contexto | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0108: Hipotiroidismo primario bioquímico (Tiroides)

- **SI:** TSH elevada y FT4 bajo el rango
- **ENTONCES:** Consulta endocrinológica/clínica
- **Variables:** TSH, FT4, intervalos_lab; disponibilidad OPCIONAL.
- **Ventana:** Misma extracción; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** TSH/FT4 y clínica.
- **Fuente declarada v03:** ATA_TFT — https://www.thyroid.org/thyroid-function-tests/.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0109: Hipertiroidismo bioquímico (Tiroides)

- **SI:** TSH baja y FT4 o T3 elevados
- **ENTONCES:** Evaluar hipertiroidismo y riesgo de arritmia
- **Variables:** TSH, FT4, T3, intervalos_lab; disponibilidad OPCIONAL.
- **Ventana:** Misma extracción; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** TFT e investigación etiológica.
- **Fuente declarada v03:** ATA_TFT — https://www.thyroid.org/thyroid-function-tests/.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0110: TSH elevada FT4 normal (Tiroides)

- **SI:** TSH sobre LSN y FT4 normal, persistente
- **ENTONCES:** Evaluar hipotiroidismo subclínico
- **Variables:** TSH, FT4; disponibilidad OPCIONAL.
- **Ventana:** Repetición laboratorio; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** TSH repetida, anticuerpos según clínica.
- **Fuente declarada v03:** ATA_TFT — https://www.thyroid.org/thyroid-function-tests/.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0111: TSH suprimida FT4 normal (Tiroides)

- **SI:** TSH bajo LIN y FT4 normal
- **ENTONCES:** Evaluar hipertiroidismo subclínico/T3
- **Variables:** TSH, FT4; disponibilidad OPCIONAL.
- **Ventana:** Repetición laboratorio; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** TSH, FT4, T3.
- **Fuente declarada v03:** ATA_TFT — https://www.thyroid.org/thyroid-function-tests/.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0112: Irregularidad menstrual (Reproductivo)

- **SI:** Ciclos <21 o >35 días o <8 ciclos/año (>=3 años posmenarquia)
- **ENTONCES:** Evaluar disfunción ovulatoria, posible SOP y causas
- **Variables:** longitud_ciclos, años_postmenarquia; disponibilidad CONTEXTO_ADICIONAL.
- **Ventana:** Múltiples ciclos; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON.
- **Confirmación necesaria:** Historial menstrual y valoración.
- **Fuente declarada v03:** PCOS23 — https://pmc.ncbi.nlm.nih.gov/articles/PMC10505534/.
- **Pasaje breve relacionado:** S20; **ubicación:** PCOS International Guideline 2023, diagnostic criteria.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** fase del ciclo observada/estimada ≠ prueba diagnóstica hormonal.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0113: Amenorrea prolongada no explicada (Reproductivo)

- **SI:** Ausencia de ciclo >90 días en contexto aplicable, embarazo descartado
- **ENTONCES:** Revisión de causas endocrinas y reproductivas
- **Variables:** fecha_ultima_regla, embarazo; disponibilidad CONTEXTO_ADICIONAL.
- **Ventana:** >90 días; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON.
- **Confirmación necesaria:** Prueba embarazo, TSH, prolactina etc..
- **Fuente declarada v03:** PCOS23 — https://pmc.ncbi.nlm.nih.gov/articles/PMC10505534/.
- **Pasaje breve relacionado:** S20; **ubicación:** PCOS International Guideline 2023, diagnostic criteria.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** fase del ciclo observada/estimada ≠ prueba diagnóstica hormonal.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0114: SOP a evaluar con hiperandrogenismo (Reproductivo)

- **SI:** Disfunción ovulatoria + hiperandrogenismo bioquímico comprobado
- **ENTONCES:** Evaluación de SOP y descarte de otras causas
- **Variables:** irregularidad_menstrual, testosterona; disponibilidad OPCIONAL.
- **Ventana:** Múltiples ciclos y laboratorio; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** SOSPECHA.
- **Confirmación necesaria:** Clínica y pruebas específicas.
- **Fuente declarada v03:** PCOS23 — https://pmc.ncbi.nlm.nih.gov/articles/PMC10505534/.
- **Pasaje breve relacionado:** S20; **ubicación:** PCOS International Guideline 2023, diagnostic criteria.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** fase del ciclo observada/estimada ≠ prueba diagnóstica hormonal.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0115: Hipertensión obstétrica (Embarazo)

- **SI:** Embarazo confirmado >=20 sem y PAS >=140 o PAD >=90 confirmada en 2 mediciones separadas >=4h
- **ENTONCES:** Valoración obstétrica pronta
- **Variables:** embarazo_confirmado, semana_gestacional, pa_validada; disponibilidad CONTEXTO_ADICIONAL.
- **Ventana:** >=4h; **Población:** Adultos >=18 años.
- **Prioridad:** URGENTE; **Naturaleza:** CRITERIO_CLINICO.
- **Confirmación necesaria:** Evaluación obstétrica.
- **Fuente declarada v03:** ACOG_BP — https://www.acog.org/womens-health/faqs/preeclampsia-and-high-blood-pressure-during-pregnancy.
- **Pasaje breve relacionado:** S22; **ubicación:** ACC/AHA 2025, Table 21, hypertension pregnancy.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0116: Hipertensión severa obstétrica (Embarazo)

- **SI:** Embarazo confirmado y PAS >=160 O PAD >=110
- **ENTONCES:** Evaluación obstétrica inmediata
- **Variables:** embarazo_confirmado, pa_validada; disponibilidad CONTEXTO_ADICIONAL.
- **Ventana:** Confirmación en intervalo corto; **Población:** Adultos >=18 años.
- **Prioridad:** CRITICA; **Naturaleza:** CRITERIO_CLINICO.
- **Confirmación necesaria:** Valoración obstétrica.
- **Fuente declarada v03:** ACOG_BP — https://www.acog.org/womens-health/faqs/preeclampsia-and-high-blood-pressure-during-pregnancy.
- **Pasaje breve relacionado:** S22; **ubicación:** ACC/AHA 2025, Table 21, hypertension pregnancy.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0117: Sospecha de preeclampsia por proteinuria (Embarazo)

- **SI:** Embarazo >=20 sem con HTA nueva + proteinuria >=300 mg/24h o proteína/creatinina >=0.3
- **ENTONCES:** Evaluación obstétrica urgente
- **Variables:** embarazo, sem_gest, pa_validada, proteina_orina; disponibilidad OPCIONAL.
- **Ventana:** Actual; **Población:** Adultos >=18 años.
- **Prioridad:** URGENTE; **Naturaleza:** SOSPECHA.
- **Confirmación necesaria:** Pruebas de órgano blanco.
- **Fuente declarada v03:** ACOG_BP — https://www.acog.org/womens-health/faqs/preeclampsia-and-high-blood-pressure-during-pregnancy.
- **Pasaje breve relacionado:** S22; **ubicación:** ACC/AHA 2025, Table 21, hypertension pregnancy.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0118: Posibles datos de preeclampsia con daño de órgano (Embarazo)

- **SI:** Embarazo >=20 sem con HTA + plaquetas <100k o creatinina >1.1 o >=2x basal, o enzimas hepáticas >=2x LSN
- **ENTONCES:** Evaluación obstétrica inmediata
- **Variables:** embarazo, pa_validada, plaquetas, creatinina, ALT/AST; disponibilidad OPCIONAL.
- **Ventana:** Actual; **Población:** Adultos >=18 años.
- **Prioridad:** CRITICA; **Naturaleza:** SOSPECHA.
- **Confirmación necesaria:** Pruebas obstétricas y clínica.
- **Fuente declarada v03:** ACOG_BP — https://www.acog.org/womens-health/faqs/preeclampsia-and-high-blood-pressure-during-pregnancy.
- **Pasaje breve relacionado:** S22; **ubicación:** ACC/AHA 2025, Table 21, hypertension pregnancy.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0119: Cribado diabetes gestacional (Embarazo)

- **SI:** Embarazo 24–28 semanas y sin cribado documentado
- **ENTONCES:** Solicitar cribado según protocolo obstétrico
- **Variables:** embarazo, semanas_gestacion; disponibilidad CONTEXTO_ADICIONAL.
- **Ventana:** 24–28 semanas; **Población:** Adultos >=18 años.
- **Prioridad:** CRIBADO; **Naturaleza:** RIESGO.
- **Confirmación necesaria:** OGTT en laboratorio.
- **Fuente declarada v03:** ADA_GDM26 — https://diabetesjournals.org/care/article/49/Supplement_1/S27/163926/2-Diagnosis-and-Classification-of-Diabetes.
- **Pasaje breve relacionado:** S01; **ubicación:** ADA Standards of Care 2026, Section 2 / Table 2.1.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0120: GDM por OGTT 75g (Embarazo)

- **SI:** Embarazo: ayuno >=92 o 1h >=180 o 2h >=153 mg/dL según estrategia de un paso
- **ENTONCES:** Valoración obstétrica de diabetes gestacional
- **Variables:** embarazo, OGTT_0, OGTT_1, OGTT_2; disponibilidad OPCIONAL.
- **Ventana:** Mismo OGTT; **Población:** Adultos >=18 años.
- **Prioridad:** CONSULTA; **Naturaleza:** CRITERIO_LAB.
- **Confirmación necesaria:** OGTT laboratorio.
- **Fuente declarada v03:** ADA_GDM26 — https://diabetesjournals.org/care/article/49/Supplement_1/S27/163926/2-Diagnosis-and-Classification-of-Diabetes.
- **Pasaje breve relacionado:** S01; **ubicación:** ADA Standards of Care 2026, Section 2 / Table 2.1.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0121: No interpretar PA cuffless como diagnóstica (Seguridad lógica)

- **SI:** Si PA procede de estimación cuffless sin validación diagnóstica
- **ENTONCES:** Permitir observación exploratoria; desactivar decisiones diagnósticas basadas en PA
- **Variables:** tipo_sensor_PA; disponibilidad BASE.
- **Ventana:** Cada medición; **Población:** Adultos >=18 años.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** ABSTENCION.
- **Confirmación necesaria:** Manguito validado/ABPM.
- **Fuente declarada v03:** AHA_BP25 — https://www.jacc.org/doi/10.1016/j.jacc.2025.05.007.
- **Pasaje breve relacionado:** S03; **ubicación:** ACC/AHA 2025 hipertensión, categorías PA, Table 4.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0122: No interpretar CGM como diagnóstico diabetes (Seguridad lógica)

- **SI:** Si fuente es CGM intersticial y no hay analítica confirmatoria
- **ENTONCES:** Abstener diagnóstico diabetes/prediabetes
- **Variables:** tipo_glucosa; disponibilidad BASE.
- **Ventana:** Cada evento; **Población:** Adultos >=18 años.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** ABSTENCION.
- **Confirmación necesaria:** HbA1c/FPG/OGTT laboratorio.
- **Fuente declarada v03:** ADA26 — https://diabetesjournals.org/care/article/49/Supplement_1/S27/163926/2-Diagnosis-and-Classification-of-Diabetes.
- **Pasaje breve relacionado:** S01; **ubicación:** ADA Standards of Care 2026, Section 2 / Table 2.1.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0123: No diagnosticar FA sin ECG (Seguridad lógica)

- **SI:** Irregularidad PPG sin registro ECG
- **ENTONCES:** Clasificar como sospecha, recomendar ECG
- **Variables:** tipo_registro_ritmo; disponibilidad BASE.
- **Ventana:** Cada episodio; **Población:** Adultos >=18 años.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** ABSTENCION.
- **Confirmación necesaria:** ECG interpretado.
- **Fuente declarada v03:** ESC_AF24 — https://academic.oup.com/eurheartj/article/45/36/3314/7738779.
- **Pasaje breve relacionado:** S21; **ubicación:** ESC 2024 AF guideline, key message 10.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0124: No calcular NEWS2 incompleto (Seguridad lógica)

- **SI:** Falta cualquier componente requerido del NEWS2
- **ENTONCES:** Abstenerse de presentar score como NEWS2
- **Variables:** RR, consciencia, oxigeno_suplementario, SpO2, FC, PA, temperatura; disponibilidad BASE.
- **Ventana:** Cada evento; **Población:** Adultos >=18 años.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** ABSTENCION.
- **Confirmación necesaria:** NEWS2 con variables completas.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0125: No diagnosticar infarto ni ictus con biometría base (Seguridad lógica)

- **SI:** Solo FC, SpO2, PA, glucosa y antropometría sin signos clínicos
- **ENTONCES:** Sin detector específico; informar limitación y permitir alertas generales
- **Variables:** sin_ECG_troponinas_neurologia; disponibilidad BASE.
- **Ventana:** Cada evento; **Población:** Adultos >=18 años.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** ABSTENCION.
- **Confirmación necesaria:** ECG/troponina/exploración neurológica.
- **Fuente declarada v03:** ESC_AF24 — https://academic.oup.com/eurheartj/article/45/36/3314/7738779.
- **Pasaje breve relacionado:** S21; **ubicación:** ESC 2024 AF guideline, key message 10.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0126: Pedir embarazo antes de reglas obstétricas (Seguridad lógica)

- **SI:** Embarazo desconocido
- **ENTONCES:** No activar diagnósticos gestacionales ni aplicar rangos fisiológicos de embarazo
- **Variables:** estado_embarazo; disponibilidad CONTEXTO_ADICIONAL.
- **Ventana:** Cada intento; **Población:** Adultos >=18 años.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** ABSTENCION.
- **Confirmación necesaria:** Prueba de embarazo/registro.
- **Fuente declarada v03:** ACOG_BP — https://www.acog.org/womens-health/faqs/preeclampsia-and-high-blood-pressure-during-pregnancy.
- **Pasaje breve relacionado:** S22; **ubicación:** ACC/AHA 2025, Table 21, hypertension pregnancy.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0127: No diagnosticar anemia sin BH (Seguridad lógica)

- **SI:** Hemoglobina no disponible
- **ENTONCES:** Anemia=DESCONOCIDA; posible solicitud BH según contexto
- **Variables:** hemoglobina; disponibilidad BASE.
- **Ventana:** Cada intento; **Población:** Adultos >=18 años.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** ABSTENCION.
- **Confirmación necesaria:** Biometría hemática.
- **Fuente declarada v03:** WHO_HB24 — https://www.ncbi.nlm.nih.gov/books/NBK602183/table/fm-ch1.tab2/.
- **Pasaje breve relacionado:** S08; **ubicación:** OMS 2024, Table 3: Haemoglobin cutoffs / anaemia severity.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0128: No calcular FIB4 sin plaquetas/AST/ALT (Seguridad lógica)

- **SI:** Faltan variables o paciente acutamente enfermo
- **ENTONCES:** Desactivar FIB4 y sugerir laboratorio si procede
- **Variables:** edad, AST, ALT, plaquetas; disponibilidad OPCIONAL.
- **Ventana:** Cada intento; **Población:** Adultos >=18 años.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** ABSTENCION.
- **Confirmación necesaria:** Perfil hepático y BH.
- **Fuente declarada v03:** AASLD_MASLD — https://pubmed.ncbi.nlm.nih.gov/38445559/.
- **Pasaje breve relacionado:** S15; **ubicación:** AASLD Practice Guidance 2023 (update MASLD 2024), Figure 2.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIO_O_EXPOSICION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0129: Presión sin manguito, no diagnóstica (Calidad de datos)

- **SI:** PA obtenida por estimación cuffless sin validación ni calibración documentada
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** pa_modo_dispositivo; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AHA_CUFFLESS — https://professional.heart.org/en/science-news/cuffless-devices-for-the-measurement-of-blood-pressure/top-things-to-know.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0130: Oximetría sin señal fiable (Calidad de datos)

- **SI:** SpO2 sin índice de perfusión/calidad o con movimiento durante el episodio
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** spo2_calidad;movimiento; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** FDA_SPO2 — https://www.fda.gov/medical-devices/products-and-medical-procedures/pulse-oximeters.
- **Pasaje breve relacionado:** S10; **ubicación:** FDA Pulse Oximeters, February 2021 safety communication.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0131: Oximetría discordante (Calidad de datos)

- **SI:** SpO2 cambia ≥5 pp en <30 s sin correlación clínica o señal estable
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** spo2;spo2_calidad; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** FDA_SPO2 — https://www.fda.gov/medical-devices/products-and-medical-procedures/pulse-oximeters.
- **Pasaje breve relacionado:** S10; **ubicación:** FDA Pulse Oximeters, February 2021 safety communication.
- **Clasificación original:** EXPERIMENTAL_NO_VALIDADA; **revisión v04:** SOLO_INVESTIGACION_DESACTIVADA.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** DELTA_PP; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0132: Glucosa CGM no diagnóstica (Calidad de datos)

- **SI:** Paciente sin diabetes: pretensión de etiquetar diabetes por datos CGM exclusivamente
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** cgm;diabetes_previa; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_DX26 — https://pmc.ncbi.nlm.nih.gov/articles/PMC12690183/.
- **Pasaje breve relacionado:** S01; **ubicación:** ADA Standards of Care 2026, Section 2 / Table 2.1.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0133: Falta ventana basal de FC (Calidad de datos)

- **SI:** Serie FC histórica <7 días útiles para calcular cambio relativo personalizado
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** fc_serie;calidad_fc; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ESC_AF — https://academic.oup.com/eurheartj/article/45/36/3314/7738779.
- **Pasaje breve relacionado:** S21; **ubicación:** ESC 2024 AF guideline, key message 10.
- **Clasificación original:** EXPERIMENTAL_NO_VALIDADA; **revisión v04:** SOLO_INVESTIGACION_DESACTIVADA.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PORCENTAJE_COBERTURA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0134: Falta ventana basal PA (Calidad de datos)

- **SI:** Registro PA basal <7 días protocolizados o dispositivo no validado
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** pa_serie;pa_validada; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AHA_CUFFLESS — https://professional.heart.org/en/science-news/cuffless-devices-for-the-measurement-of-blood-pressure/top-things-to-know.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PORCENTAJE_COBERTURA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0135: Cobertura CGM insuficiente (Calidad de datos)

- **SI:** CGM <70% del tiempo registrado durante 14 días
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** cgm_14d;cgm_cobertura; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ISPAD_CGM24 — https://pmc.ncbi.nlm.nih.gov/articles/PMC11854985/.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PORCENTAJE_COBERTURA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0136: Falta sitio de temperatura (Calidad de datos)

- **SI:** Temperatura anormal pero sin método ni sitio de medición
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** temperatura;tipo_termometro; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0137: Posible seudohipercalemia (Calidad de datos)

- **SI:** K sérico elevado y muestra hemolizada
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** potasio;indice_hemolisis; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** UKKA_K26 — https://guidelines.ukkidney.org/hyperkalaemia/.
- **Pasaje breve relacionado:** S07; **ubicación:** UK Kidney Association 2026, Introduction / Hyperkalaemia severity.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0138: ALT/AST de diferente extracción (Calidad de datos)

- **SI:** AST y ALT pertenecen a muestras de distinta fecha: evitar FIB-4
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** ast;alt;fecha_muestra; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AASLD_FIB4 — https://pmc.ncbi.nlm.nih.gov/articles/PMC10735173/.
- **Pasaje breve relacionado:** S15; **ubicación:** AASLD Practice Guidance 2023 (update MASLD 2024), Figure 2.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0139: Dos creatininas incomparables (Calidad de datos)

- **SI:** Creatininas proceden de laboratorios/métodos no comparables o unidades sin unificar
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** creatinina;unidad_creatinina;laboratorio; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NIDDK_EGFR — https://www.niddk.nih.gov/research-funding/research-programs/kidney-clinical-research-epidemiology/laboratory/glomerular-filtration-rate-equations/adults.
- **Pasaje breve relacionado:** S13; **ubicación:** NIDDK, eGFR Equations for Adults / 2021 CKD-EPI.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0140: HbA1c con interferencias posibles (Calidad de datos)

- **SI:** HbA1c discordante respecto de glucosa plasmática o anemia/hemoglobinopatía
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** hba1c;hemoglobina;hemoglobinopatia; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_DX26 — https://pmc.ncbi.nlm.nih.gov/articles/PMC12690183/.
- **Pasaje breve relacionado:** S01; **ubicación:** ADA Standards of Care 2026, Section 2 / Table 2.1.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0141: Estado de embarazo desconocido (Calidad de datos)

- **SI:** Regla no embarazada requiere exclusión de embarazo y no existe dato
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** embarazo_estado; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACOG_PREE — https://www.acog.org/womens-health/faqs/preeclampsia-and-high-blood-pressure-during-pregnancy.
- **Pasaje breve relacionado:** S22; **ubicación:** ACC/AHA 2025, Table 21, hypertension pregnancy.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0142: Fase ovulatoria inferida, no medida (Calidad de datos)

- **SI:** Fase menstrual derivada de calendario sin documentación de ovulación
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** fase_ciclo;origen_fase; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** PCOS_GUIDE23 — https://academic.oup.com/jcem/article/108/10/2447/7242360.
- **Pasaje breve relacionado:** S20; **ubicación:** PCOS International Guideline 2023, diagnostic criteria.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0143: Unidades no verificadas (Calidad de datos)

- **SI:** Umbral depende de mmol/L vs mg/dL o ng/mL vs nmol/L y unidad ausente
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** laboratorio_unidad; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_B12_24 — https://www.nice.org.uk/guidance/ng239/chapter/recommendations.
- **Pasaje breve relacionado:** S17; **ubicación:** NICE NG239, Table 1 total or active B12.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0144: Antecedente familiar no disponible (Calidad de datos)

- **SI:** Algoritmo exige familia de primer grado pero historial no registra ese dato
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** antecedente_familiar; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_DX26 — https://pmc.ncbi.nlm.nih.gov/articles/PMC12690183/.
- **Pasaje breve relacionado:** S01; **ubicación:** ADA Standards of Care 2026, Section 2 / Table 2.1.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0145: Medicaciones no disponibles (Calidad de datos)

- **SI:** PREVENT exige estatinas y tratamiento antihipertensivo pero no se han recopilado
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** medicacion_estatinas;medicacion_hipertension; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AHA_PREVENT — https://professional.heart.org/en/guidelines-and-statements/prevent-calculator.
- **Pasaje breve relacionado:** S30; **ubicación:** AHA Professional PREVENT calculator.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0146: Tabaquismo no disponible (Calidad de datos)

- **SI:** PREVENT requiere tabaquismo actual y no está registrado
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** fuma_actual; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AHA_PREVENT — https://professional.heart.org/en/guidelines-and-statements/prevent-calculator.
- **Pasaje breve relacionado:** S30; **ubicación:** AHA Professional PREVENT calculator.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0147: Sexo de fórmula no disponible (Calidad de datos)

- **SI:** Modelo clínico requiere sexo de coeficientes y no se puede inferir a partir del origen étnico
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** sexo_modelo; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AHA_PREVENT — https://professional.heart.org/en/guidelines-and-statements/prevent-calculator.
- **Pasaje breve relacionado:** S30; **ubicación:** AHA Professional PREVENT calculator.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0148: Riesgo explícitamente no calibrado (Calidad de datos)

- **SI:** Estimación fuera de población o región de desarrollo/validación
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** region_modelo;poblacion_modelo; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** KFRE_TANGRI16 — https://jamanetwork.com/journals/jama/fullarticle/2481005.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0149: No confundir porcentaje de umbral con riesgo (Calidad de datos)

- **SI:** Cociente medida/umbral no se debe rotular probabilidad de enfermedad
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** ratio_umbral; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** KDIGO24 — https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf.
- **Pasaje breve relacionado:** S05; **ubicación:** KDIGO 2024 ERC, Practice Point 2.2.1, página S156.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0150: Datos biométricos fuera de edad adulta (Calidad de datos)

- **SI:** Edad <18 años con reglas marcadas sólo para adultos
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** edad; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_DX26 — https://pmc.ncbi.nlm.nih.gov/articles/PMC12690183/.
- **Pasaje breve relacionado:** S01; **ubicación:** ADA Standards of Care 2026, Section 2 / Table 2.1.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0151: No calcular NEWS2 incompleto (Calidad de datos)

- **SI:** No se dispone de frecuencia respiratoria, conciencia o aporte de oxígeno para NEWS2 íntegro
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** fr;conciencia;oxigenoterapia; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0152: No calcular STOP-Bang incompleto (Calidad de datos)

- **SI:** Faltan ronquido, cansancio, apneas presenciadas y/o cuello medido
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** ronquido;somnolencia;apnea_observada;cuello_cm; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AASM_SLEEPMED — https://aasm.org/resources/clinicalguidelines/diagnostic-testing-osa.pdf.
- **Pasaje breve relacionado:** S09; **ubicación:** AASM 2017, Good Practice Statements / Recommendations 1–2.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0153: No diagnosticar FA por PPG (Calidad de datos)

- **SI:** Irregularidad PPG sin ECG
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** ppg_irregular;ecg_fa_confirmada; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ESC_AF — https://academic.oup.com/eurheartj/article/45/36/3314/7738779.
- **Pasaje breve relacionado:** S21; **ubicación:** ESC 2024 AF guideline, key message 10.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0154: No inferir sepsis de signos aislados (Calidad de datos)

- **SI:** FC alta y T elevada sin sospecha de infección ni signos clínicos suficientes
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** fc;temperatura;infeccion_sospechada; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0155: Ventana menstrual inadecuada (Calidad de datos)

- **SI:** Biomarcador hormonal interpretado sin día de ciclo o anticoncepción conocida
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** fase_ciclo;hormona;anticonceptivos; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** PCOS_GUIDE23 — https://academic.oup.com/jcem/article/108/10/2447/7242360.
- **Pasaje breve relacionado:** S20; **ubicación:** PCOS International Guideline 2023, diagnostic criteria.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0156: FC sin etiqueta de reposo (Calidad de datos)

- **SI:** FC elevada registrada durante ejercicio y clasificada como FC de reposo
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** fc;actividad; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ESC_AF — https://academic.oup.com/eurheartj/article/45/36/3314/7738779.
- **Pasaje breve relacionado:** S21; **ubicación:** ESC 2024 AF guideline, key message 10.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0157: PA sin protocolo (Calidad de datos)

- **SI:** Media de PA incluye mediciones durante movimiento o con manguito mal ajustado
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** pa;calidad_pa; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AHA_CUFFLESS — https://professional.heart.org/en/science-news/cuffless-devices-for-the-measurement-of-blood-pressure/top-things-to-know.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0158: SpO2 modificada por altitud (Calidad de datos)

- **SI:** Comparación SpO2 con umbral de nivel mar sin considerar residencia/altura
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** spo2;altitud_m; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ATS_OXYGEN — https://academic.oup.com/ajrccm/article/202/10/e121/8495596.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0159: Bajo peso con pérdida reciente (Antropometría)

- **SI:** IMC <18.5 y pérdida involuntaria reportada ≥5% en 6 meses
- **ENTONCES:** Evaluación nutricional y cardiometabólica contextualizada.
- **Variables:** imc;peso_historial;intencionalidad; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** WHO_BMI — https://www.cdc.gov/bmi/adult-calculator/bmi-categories.html.
- **Pasaje breve relacionado:** S27; **ubicación:** CDC Adult BMI categories.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PORCENTAJE_CAMBIO; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0160: Obesidad abdominal central moderada (Antropometría)

- **SI:** 0.50 ≤ cintura/altura <0.60 y IMC <35, adulto
- **ENTONCES:** Evaluación nutricional y cardiometabólica contextualizada.
- **Variables:** cintura_cm;altura_cm;imc; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_OBESITY — https://www.nice.org.uk/guidance/ng246/chapter/Identifying-and-assessing-overweight-obesity-and-central-adiposity.
- **Pasaje breve relacionado:** S14; **ubicación:** NICE NG246, 1.9.14–1.9.15.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** COCIENTE; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0161: Obesidad abdominal central muy elevada (Antropometría)

- **SI:** cintura/altura ≥0.60 y IMC <35, adulto
- **ENTONCES:** Evaluación nutricional y cardiometabólica contextualizada.
- **Variables:** cintura_cm;altura_cm;imc; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_OBESITY — https://www.nice.org.uk/guidance/ng246/chapter/Identifying-and-assessing-overweight-obesity-and-central-adiposity.
- **Pasaje breve relacionado:** S14; **ubicación:** NICE NG246, 1.9.14–1.9.15.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** COCIENTE; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0162: Cintura/altura saludable (Antropometría)

- **SI:** cintura/altura <0.50 en adulto, interpretar con BMI y contexto
- **ENTONCES:** Evaluación nutricional y cardiometabólica contextualizada.
- **Variables:** cintura_cm;altura_cm; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_OBESITY — https://www.nice.org.uk/guidance/ng246/chapter/Identifying-and-assessing-overweight-obesity-and-central-adiposity.
- **Pasaje breve relacionado:** S14; **ubicación:** NICE NG246, 1.9.14–1.9.15.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** COCIENTE; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0163: Obesidad clase 1 con HTA corroborada (Antropometría)

- **SI:** 30≤IMC<35 y HTA confirmada por manguito
- **ENTONCES:** Evaluación nutricional y cardiometabólica contextualizada.
- **Variables:** imc;hipertension_confirmada; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AHA_BP25 — https://www.jacc.org/doi/10.1016/j.jacc.2025.05.007.
- **Pasaje breve relacionado:** S03; **ubicación:** ACC/AHA 2025 hipertensión, categorías PA, Table 4.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0164: Obesidad clase 2 con prediabetes (Antropometría)

- **SI:** 35≤IMC<40 y HbA1c 5.7–6.4%
- **ENTONCES:** Evaluación nutricional y cardiometabólica contextualizada.
- **Variables:** imc;hba1c; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_DX26 — https://pmc.ncbi.nlm.nih.gov/articles/PMC12690183/.
- **Pasaje breve relacionado:** S01; **ubicación:** ADA Standards of Care 2026, Section 2 / Table 2.1.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0165: Obesidad clase 3 con diabetes conocida (Antropometría)

- **SI:** IMC≥40 y diabetes establecida en historia clínica
- **ENTONCES:** Evaluación nutricional y cardiometabólica contextualizada.
- **Variables:** imc;diabetes_previa; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_DX26 — https://pmc.ncbi.nlm.nih.gov/articles/PMC12690183/.
- **Pasaje breve relacionado:** S01; **ubicación:** ADA Standards of Care 2026, Section 2 / Table 2.1.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0166: Delgadez con anemia (Antropometría)

- **SI:** IMC<18.5 y hemoglobina bajo criterio OMS por sexo/gestación
- **ENTONCES:** Evaluación nutricional y cardiometabólica contextualizada.
- **Variables:** imc;hb;sexo_modelo; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** WHO_HB24 — https://www.ncbi.nlm.nih.gov/books/NBK602183/table/fm-ch1.tab2/.
- **Pasaje breve relacionado:** S08; **ubicación:** OMS 2024, Table 3: Haemoglobin cutoffs / anaemia severity.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0167: Pérdida de peso sostenida lenta (Antropometría)

- **SI:** Pérdida no intencional ≥5% del peso previo durante 6–12 meses
- **ENTONCES:** Evaluación nutricional y cardiometabólica contextualizada.
- **Variables:** peso_historial;intencionalidad; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** WHO_BMI — https://www.cdc.gov/bmi/adult-calculator/bmi-categories.html.
- **Pasaje breve relacionado:** S27; **ubicación:** CDC Adult BMI categories.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PORCENTAJE_CAMBIO; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0168: Incremento de cintura (Antropometría)

- **SI:** Cintura aumenta ≥5 cm en 6 meses medidos mismo método
- **ENTONCES:** Evaluación nutricional y cardiometabólica contextualizada.
- **Variables:** cintura_historial; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_OBESITY — https://www.nice.org.uk/guidance/ng246/chapter/Identifying-and-assessing-overweight-obesity-and-central-adiposity.
- **Pasaje breve relacionado:** S14; **ubicación:** NICE NG246, 1.9.14–1.9.15.
- **Clasificación original:** EXPERIMENTAL_NO_VALIDADA; **revisión v04:** SOLO_INVESTIGACION_DESACTIVADA.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** DELTA_CM; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0169: Elevación de IMC persistente (Antropometría)

- **SI:** IMC≥30 en al menos 2 mediciones separadas≥30 días
- **ENTONCES:** Evaluación nutricional y cardiometabólica contextualizada.
- **Variables:** imc_historial; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** WHO_BMI — https://www.cdc.gov/bmi/adult-calculator/bmi-categories.html.
- **Pasaje breve relacionado:** S27; **ubicación:** CDC Adult BMI categories.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PORCENTAJE_TIEMPO; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0170: Peso en aumento con HTA (Antropometría)

- **SI:** Aumento ≥5% peso en 6 meses y PAS promedio ≥140 validada
- **ENTONCES:** Evaluación nutricional y cardiometabólica contextualizada.
- **Variables:** peso_historial;pas_validada; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AHA_BP25 — https://www.jacc.org/doi/10.1016/j.jacc.2025.05.007.
- **Pasaje breve relacionado:** S03; **ubicación:** ACC/AHA 2025 hipertensión, categorías PA, Table 4.
- **Clasificación original:** EXPERIMENTAL_NO_VALIDADA; **revisión v04:** SOLO_INVESTIGACION_DESACTIVADA.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0171: Peso en caída con hiperglucemia (Antropometría)

- **SI:** Pérdida no intencional ≥5% en 6 meses y glucosa plasmática ayuno≥126
- **ENTONCES:** Evaluación nutricional y cardiometabólica contextualizada.
- **Variables:** peso_historial;glucosa_plasmatica_ayuno; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_DX26 — https://pmc.ncbi.nlm.nih.gov/articles/PMC12690183/.
- **Pasaje breve relacionado:** S01; **ubicación:** ADA Standards of Care 2026, Section 2 / Table 2.1.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0172: Peso en caída con TSH suprimida (Antropometría)

- **SI:** Pérdida involuntaria y TSH <0.1 con FT4 alta para el laboratorio
- **ENTONCES:** Evaluación nutricional y cardiometabólica contextualizada.
- **Variables:** peso_historial;tsh;ft4; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_TSH — https://www.nice.org.uk/guidance/ng145/chapter/recommendations.
- **Pasaje breve relacionado:** S19; **ubicación:** NICE NG145, recommendation 1.2.8.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0173: Aumento peso y TSH alta (Antropometría)

- **SI:** Aumento ≥5% y TSH sobre rango del laboratorio con FT4 baja
- **ENTONCES:** Evaluación nutricional y cardiometabólica contextualizada.
- **Variables:** peso_historial;tsh;ft4; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_TSH — https://www.nice.org.uk/guidance/ng145/chapter/recommendations.
- **Pasaje breve relacionado:** S19; **ubicación:** NICE NG145, recommendation 1.2.8.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0174: Riesgo cardiometabólico combinatorio 3 factores (Antropometría)

- **SI:** Cintura/altura≥0.5 + PA≥130/80 validada + HbA1c≥5.7%
- **ENTONCES:** Evaluación nutricional y cardiometabólica contextualizada.
- **Variables:** cintura_cm;altura_cm;pas_validada;pad_validada;hba1c; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_DX26 — https://pmc.ncbi.nlm.nih.gov/articles/PMC12690183/.
- **Pasaje breve relacionado:** S01; **ubicación:** ADA Standards of Care 2026, Section 2 / Table 2.1.
- **Clasificación original:** EXPERIMENTAL_NO_VALIDADA; **revisión v04:** SOLO_INVESTIGACION_DESACTIVADA.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0175: Riesgo cardiometabólico combinatorio 4 factores (Antropometría)

- **SI:** Regla anterior + TG≥150 mg/dL o HDL bajo según sexo
- **ENTONCES:** Evaluación nutricional y cardiometabólica contextualizada.
- **Variables:** cintura_cm;altura_cm;pa_validada;hba1c;tg;hdl; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACC_LIP26 — https://www.jacc.org/doi/10.1016/j.jacc.2025.11.016.
- **Pasaje breve relacionado:** S12; **ubicación:** ACC/AHA Dyslipidemia 2026, Section 4.2.3.7.
- **Clasificación original:** EXPERIMENTAL_NO_VALIDADA; **revisión v04:** SOLO_INVESTIGACION_DESACTIVADA.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0176: Aumento rápido peso con IC previa (Antropometría)

- **SI:** IC conocida y +2 kg dentro de 3 días, báscula comparable
- **ENTONCES:** Evaluación nutricional y cardiometabólica contextualizada.
- **Variables:** peso_historial;ic_previa; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ESC_HF21 — https://academic.oup.com/eurheartj/article/42/36/3599/6358045.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** DELTA_KG; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0177: Caída ponderal y presión (Antropometría)

- **SI:** Peso disminuye≥3% en 7 días y PAS basal baja≥15 mmHg
- **ENTONCES:** Evaluación nutricional y cardiometabólica contextualizada.
- **Variables:** peso_historial;pas_historial; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** EXPERIMENTAL_NO_VALIDADA; **revisión v04:** SOLO_INVESTIGACION_DESACTIVADA.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0178: Peso bajo y ferritina baja (Antropometría)

- **SI:** IMC<18.5 y ferritina<45 ng/mL con anemia
- **ENTONCES:** Evaluación nutricional y cardiometabólica contextualizada.
- **Variables:** imc;ferritina;hb; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AGA_IRON20 — https://gastro.org/clinical-guidance/gastrointestinal-evaluation-of-iron-deficiency-anemia/.
- **Pasaje breve relacionado:** S18; **ubicación:** AGA 2020 Guideline, Recommendations point 1.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0179: HTA aislada sistólica según ESC (Presión arterial)

- **SI:** PAS consulta≥140 y PAD<90; ≥2 ocasiones validadas
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** pas_consulta;pad_consulta; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ESC_BP24 — https://academic.oup.com/eurheartj/article/45/38/3912/7741010.
- **Pasaje breve relacionado:** S04; **ubicación:** NICE NG136, 1.2.7–1.2.8.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MMHG; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0180: HTA aislada diastólica (Presión arterial)

- **SI:** PAS consulta<140 y PAD≥90; ≥2 ocasiones validadas
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** pas_consulta;pad_consulta; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ESC_BP24 — https://academic.oup.com/eurheartj/article/45/38/3912/7741010.
- **Pasaje breve relacionado:** S04; **ubicación:** NICE NG136, 1.2.7–1.2.8.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MMHG; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0181: PA elevada ACC/AHA (Presión arterial)

- **SI:** 120≤PAS≤129 y PAD<80, promedio de≥2 visitas
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** pas_consulta;pad_consulta; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AHA_BP25 — https://www.jacc.org/doi/10.1016/j.jacc.2025.05.007.
- **Pasaje breve relacionado:** S03; **ubicación:** ACC/AHA 2025 hipertensión, categorías PA, Table 4.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MMHG; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0182: PA normal ACC/AHA (Presión arterial)

- **SI:** PAS<120 y PAD<80 promedio válido
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** pas_consulta;pad_consulta; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AHA_BP25 — https://www.jacc.org/doi/10.1016/j.jacc.2025.05.007.
- **Pasaje breve relacionado:** S03; **ubicación:** ACC/AHA 2025 hipertensión, categorías PA, Table 4.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MMHG; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0183: HTA estadio 1 ACC/AHA persistente (Presión arterial)

- **SI:** PAS130–139 o PAD80–89; promedio≥2 lecturas≥2 visitas
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** pas_consulta;pad_consulta; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AHA_BP25 — https://www.jacc.org/doi/10.1016/j.jacc.2025.05.007.
- **Pasaje breve relacionado:** S03; **ubicación:** ACC/AHA 2025 hipertensión, categorías PA, Table 4.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MMHG; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0184: HTA estadio 2 ACC/AHA persistente (Presión arterial)

- **SI:** PAS≥140 o PAD≥90; promedio≥2 lecturas≥2 visitas
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** pas_consulta;pad_consulta; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AHA_BP25 — https://www.jacc.org/doi/10.1016/j.jacc.2025.05.007.
- **Pasaje breve relacionado:** S03; **ubicación:** ACC/AHA 2025 hipertensión, categorías PA, Table 4.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MMHG; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0185: Criterio HTA HBPM (Presión arterial)

- **SI:** Promedio domiciliario ≥135 PAS o ≥85 PAD en protocolo validado
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** pas_hbpm;pad_hbpm; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ESC_BP24 — https://academic.oup.com/eurheartj/article/45/38/3912/7741010.
- **Pasaje breve relacionado:** S04; **ubicación:** NICE NG136, 1.2.7–1.2.8.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MMHG; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0186: Criterio HTA ABPM 24h (Presión arterial)

- **SI:** Promedio 24h ≥130 PAS o ≥80 PAD; ABPM de manguito validado
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** pas_abpm24;pad_abpm24; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ESC_BP24 — https://academic.oup.com/eurheartj/article/45/38/3912/7741010.
- **Pasaje breve relacionado:** S04; **ubicación:** NICE NG136, 1.2.7–1.2.8.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MMHG; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0187: Criterio HTA nocturna ABPM (Presión arterial)

- **SI:** Promedio nocturno ≥120 PAS o ≥70 PAD; sueño identificado
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** pas_abpm_noche;pad_abpm_noche;sueño_segmentado; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ESC_BP24 — https://academic.oup.com/eurheartj/article/45/38/3912/7741010.
- **Pasaje breve relacionado:** S04; **ubicación:** NICE NG136, 1.2.7–1.2.8.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MMHG; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0188: Criterio HTA diurna ABPM (Presión arterial)

- **SI:** Promedio diurno ≥135 PAS o ≥85 PAD; ABPM validado
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** pas_abpm_dia;pad_abpm_dia; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ESC_BP24 — https://academic.oup.com/eurheartj/article/45/38/3912/7741010.
- **Pasaje breve relacionado:** S04; **ubicación:** NICE NG136, 1.2.7–1.2.8.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MMHG; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0189: Hipertensión de bata blanca posible (Presión arterial)

- **SI:** PA consulta≥140/90 y media domiciliaria<135/85 validada
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** pa_consulta;pa_hbpm; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ESC_BP24 — https://academic.oup.com/eurheartj/article/45/38/3912/7741010.
- **Pasaje breve relacionado:** S04; **ubicación:** NICE NG136, 1.2.7–1.2.8.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** DELTA_MMHG; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0190: HTA enmascarada posible (Presión arterial)

- **SI:** PA consulta<140/90 y media domiciliaria≥135/85 validada
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** pa_consulta;pa_hbpm; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ESC_BP24 — https://academic.oup.com/eurheartj/article/45/38/3912/7741010.
- **Pasaje breve relacionado:** S04; **ubicación:** NICE NG136, 1.2.7–1.2.8.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** DELTA_MMHG; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0191: Sistólica extremadamente elevada (Presión arterial)

- **SI:** PAS≥180 mmHg en manguito validado, reconfirmar inmediatamente
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** pas_validada; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AHA_BP25 — https://www.jacc.org/doi/10.1016/j.jacc.2025.05.007.
- **Pasaje breve relacionado:** S03; **ubicación:** ACC/AHA 2025 hipertensión, categorías PA, Table 4.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MMHG; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0192: Diastólica extremadamente elevada (Presión arterial)

- **SI:** PAD≥120 mmHg en manguito validado, reconfirmar inmediatamente
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** pad_validada; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AHA_BP25 — https://www.jacc.org/doi/10.1016/j.jacc.2025.05.007.
- **Pasaje breve relacionado:** S03; **ubicación:** ACC/AHA 2025 hipertensión, categorías PA, Table 4.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MMHG; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0193: Sistólica baja persistente (Presión arterial)

- **SI:** PAS≤90 validada en repetición inmediata, nueva o fuera de basal
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** pas_validada;pas_baseline; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MMHG; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0194: Hipotensión relativa infección (Presión arterial)

- **SI:** PAS actual >40 mmHg inferior a basal con infección sospechada
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** pas_validada;pas_baseline;infeccion_sospechada; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** DELTA_MMHG; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0195: PA sistólica 91–100 en infección (Presión arterial)

- **SI:** Infección sospechada y PAS entre 91 y 100 mmHg
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** pas_validada;infeccion_sospechada; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MMHG; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0196: FC mayor 130 ante infección (Presión arterial)

- **SI:** Infección sospechada y FC reposo>130, confirmada
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** fc_reposo;infeccion_sospechada; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** BPM; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0197: Caída ortostática sistólica (Presión arterial)

- **SI:** PAS baja≥20 mmHg en los primeros 3 min de bipedestación validada
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** pas_supina;pas_de_pie;postura_hora; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ESC_BP24 — https://academic.oup.com/eurheartj/article/45/38/3912/7741010.
- **Pasaje breve relacionado:** S04; **ubicación:** NICE NG136, 1.2.7–1.2.8.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** DELTA_MMHG; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0198: Caída ortostática diastólica (Presión arterial)

- **SI:** PAD baja≥10 mmHg en primeros 3 min tras bipedestación validada
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** pad_supina;pad_de_pie;postura_hora; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ESC_BP24 — https://academic.oup.com/eurheartj/article/45/38/3912/7741010.
- **Pasaje breve relacionado:** S04; **ubicación:** NICE NG136, 1.2.7–1.2.8.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** DELTA_MMHG; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0199: Exceso variabilidad intraindividual (Presión arterial)

- **SI:** SD de PAS diaria >percentil95 cohorte validada local, sin umbral universal
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** serie_pas;cohorte_local; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AHA_BP25 — https://www.jacc.org/doi/10.1016/j.jacc.2025.05.007.
- **Pasaje breve relacionado:** S03; **ubicación:** ACC/AHA 2025 hipertensión, categorías PA, Table 4.
- **Clasificación original:** EXPERIMENTAL_NO_VALIDADA; **revisión v04:** SOLO_INVESTIGACION_DESACTIVADA.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** SD_MMHG; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0200: Pérdida dipping nocturno (Presión arterial)

- **SI:** Descenso nocturno relativo PAS<10% (diurna vs nocturna ABPM)
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** pas_abpm_dia;pas_abpm_noche; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ESC_BP24 — https://academic.oup.com/eurheartj/article/45/38/3912/7741010.
- **Pasaje breve relacionado:** S04; **ubicación:** NICE NG136, 1.2.7–1.2.8.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PORCENTAJE_DESCENSO; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0201: Reverse dipping (Presión arterial)

- **SI:** PAS media nocturna >PAS media diurna en ABPM validada
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** pas_abpm_dia;pas_abpm_noche; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ESC_BP24 — https://academic.oup.com/eurheartj/article/45/38/3912/7741010.
- **Pasaje breve relacionado:** S04; **ubicación:** NICE NG136, 1.2.7–1.2.8.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PORCENTAJE_DESCENSO; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0202: Dipping extremo (Presión arterial)

- **SI:** Descenso PAS nocturna≥20% ABPM; interpretación clínica individual
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** pas_abpm_dia;pas_abpm_noche; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ESC_BP24 — https://academic.oup.com/eurheartj/article/45/38/3912/7741010.
- **Pasaje breve relacionado:** S04; **ubicación:** NICE NG136, 1.2.7–1.2.8.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PORCENTAJE_DESCENSO; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0203: HTA + diabetes conocida (Presión arterial)

- **SI:** Media PA≥130/80 validada y diabetes establecida
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** pa_validada;diabetes_previa; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AHA_BP25 — https://www.jacc.org/doi/10.1016/j.jacc.2025.05.007.
- **Pasaje breve relacionado:** S03; **ubicación:** ACC/AHA 2025 hipertensión, categorías PA, Table 4.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0204: HTA + nefropatía (Presión arterial)

- **SI:** Media PA≥130/80 validada y ERC conocida
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** pa_validada;erc_previa; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AHA_BP25 — https://www.jacc.org/doi/10.1016/j.jacc.2025.05.007.
- **Pasaje breve relacionado:** S03; **ubicación:** ACC/AHA 2025 hipertensión, categorías PA, Table 4.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0205: HTA + ictus anterior (Presión arterial)

- **SI:** Media PA≥130/80 validada e ictus previo
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** pa_validada;ictus_previo; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AHA_BP25 — https://www.jacc.org/doi/10.1016/j.jacc.2025.05.007.
- **Pasaje breve relacionado:** S03; **ubicación:** ACC/AHA 2025 hipertensión, categorías PA, Table 4.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0206: HTA + PREVENT≥7.5% (Presión arterial)

- **SI:** PA media≥130/80 y PREVENT-CVD10≥7.5% correctamente calculado
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** pa_validada;prevent_10y; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AHA_BP25 — https://www.jacc.org/doi/10.1016/j.jacc.2025.05.007.
- **Pasaje breve relacionado:** S03; **ubicación:** ACC/AHA 2025 hipertensión, categorías PA, Table 4.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado | comparar salida del modelo con calculadora original y calibración local; no porcentaje arbitrario.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PROBABILIDAD_10_ANOS; horizonte: 10 años; porcentaje calibrado: true.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0207: Hipertensión resistente potencial (Presión arterial)

- **SI:** HTA persistente y ≥3 antihipertensivos incluyendo diurético documentado
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** pa_validada;medicacion_hipertension; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AHA_BP25 — https://www.jacc.org/doi/10.1016/j.jacc.2025.05.007.
- **Pasaje breve relacionado:** S03; **ubicación:** ACC/AHA 2025 hipertensión, categorías PA, Table 4.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FARMACOS; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0208: HTA y potasio bajo (Presión arterial)

- **SI:** HTA validada e hipopotasemia<3.5 mmol/L; considerar hiperaldosteronismo
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** pa_validada;potasio; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AHA_BP25 — https://www.jacc.org/doi/10.1016/j.jacc.2025.05.007.
- **Pasaje breve relacionado:** S03; **ubicación:** ACC/AHA 2025 hipertensión, categorías PA, Table 4.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0209: PA elevada nueva respecto basal (Presión arterial)

- **SI:** ΔPAS media semanal ≥20 mmHg comparando semanas de medición equivalente
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** pas_semana;pas_baseline; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AHA_BP25 — https://www.jacc.org/doi/10.1016/j.jacc.2025.05.007.
- **Pasaje breve relacionado:** S03; **ubicación:** ACC/AHA 2025 hipertensión, categorías PA, Table 4.
- **Clasificación original:** EXPERIMENTAL_NO_VALIDADA; **revisión v04:** SOLO_INVESTIGACION_DESACTIVADA.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** DELTA_MMHG; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0210: FC reposo elevada persistente (Ritmo cardiaco)

- **SI:** FC>100 lpm en ≥3 segmentos de reposo corroborados
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** fc_serie;actividad; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ESC_AF — https://academic.oup.com/eurheartj/article/45/36/3314/7738779.
- **Pasaje breve relacionado:** S21; **ubicación:** ESC 2024 AF guideline, key message 10.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** ECG requerido para diagnosticar fibrilación auricular | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** BPM; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0211: FC reposo 120 persistente (Ritmo cardiaco)

- **SI:** FC≥120 lpm en reposo sostenida y confirmada; valorar contexto
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** fc_reposo;actividad; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** ECG requerido para diagnosticar fibrilación auricular | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** BPM; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0212: FC 130 + sospecha infección (Ritmo cardiaco)

- **SI:** FC>130 lpm y sospecha de infección; criterio NICE alto riesgo
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** fc_reposo;infeccion_sospechada; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** ECG requerido para diagnosticar fibrilación auricular.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** BPM; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0213: FC nocturna 40–50 basal estable (Ritmo cardiaco)

- **SI:** FC nocturna 40–50 sin nueva desviación; no alertar sola
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** fc_nocturna;fc_baseline; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ESC_AF — https://academic.oup.com/eurheartj/article/45/36/3314/7738779.
- **Pasaje breve relacionado:** S21; **ubicación:** ESC 2024 AF guideline, key message 10.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** ECG requerido para diagnosticar fibrilación auricular | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** BPM; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0214: Bradicardia marcada nueva (Ritmo cardiaco)

- **SI:** FC<40 reposo corroborada y no habitual; verificar sensor y perfusión
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** fc_reposo;fc_baseline; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ESC_AF — https://academic.oup.com/eurheartj/article/45/36/3314/7738779.
- **Pasaje breve relacionado:** S21; **ubicación:** ESC 2024 AF guideline, key message 10.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** ECG requerido para diagnosticar fibrilación auricular | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** BPM; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0215: Respuesta febril FC desproporcionada (Ritmo cardiaco)

- **SI:** FC reposo>110 y T≥38 clínica; priorizar evaluación etiológica
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** fc_reposo;temperatura_clinica; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** EXPERIMENTAL_NO_VALIDADA; **revisión v04:** SOLO_INVESTIGACION_DESACTIVADA.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** ECG requerido para diagnosticar fibrilación auricular | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0216: FC aumenta frente basal (Ritmo cardiaco)

- **SI:** FC descanso mediana 7d +≥15 lpm respecto 30d, ≥3 días
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** fc_7d;fc_30d; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ESC_AF — https://academic.oup.com/eurheartj/article/45/36/3314/7738779.
- **Pasaje breve relacionado:** S21; **ubicación:** ESC 2024 AF guideline, key message 10.
- **Clasificación original:** EXPERIMENTAL_NO_VALIDADA; **revisión v04:** SOLO_INVESTIGACION_DESACTIVADA.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** ECG requerido para diagnosticar fibrilación auricular | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** DELTA_BPM; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0217: FC nocturna aumenta >20% (Ritmo cardiaco)

- **SI:** FC nocturna≥1.2× mediana de 30 noches, ≥3 noches sin fiebre documentada
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** fc_nocturna;fc_nocturna_baseline; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ESC_AF — https://academic.oup.com/eurheartj/article/45/36/3314/7738779.
- **Pasaje breve relacionado:** S21; **ubicación:** ESC 2024 AF guideline, key message 10.
- **Clasificación original:** EXPERIMENTAL_NO_VALIDADA; **revisión v04:** SOLO_INVESTIGACION_DESACTIVADA.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** ECG requerido para diagnosticar fibrilación auricular | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PORCENTAJE_CAMBIO; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0218: Pulso irregular PPG repetido (Ritmo cardiaco)

- **SI:** ≥2 avisos PPG de irregularidad con calidad aceptable en 7 días
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** ppg_eventos;ppg_calidad; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ESC_AF — https://academic.oup.com/eurheartj/article/45/36/3314/7738779.
- **Pasaje breve relacionado:** S21; **ubicación:** ESC 2024 AF guideline, key message 10.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** ECG requerido para diagnosticar fibrilación auricular | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_EVENTOS; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0219: FA ECG documentada (Ritmo cardiaco)

- **SI:** ECG de episodio interpretado y confirmado como FA por profesional
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** ecg_interpretado; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ESC_AF — https://academic.oup.com/eurheartj/article/45/36/3314/7738779.
- **Pasaje breve relacionado:** S21; **ubicación:** ESC 2024 AF guideline, key message 10.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** ECG requerido para diagnosticar fibrilación auricular.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CONFIRMACION_ECG; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0220: FA + CHA2DS2-VA 0 (Ritmo cardiaco)

- **SI:** FA ECG confirmada y CHA2DS2-VA=0 en datos completos
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** fa_confirmada;chads_va_datos; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ESC_AF — https://academic.oup.com/eurheartj/article/45/36/3314/7738779.
- **Pasaje breve relacionado:** S21; **ubicación:** ESC 2024 AF guideline, key message 10.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** ECG requerido para diagnosticar fibrilación auricular.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PUNTUACION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0221: FA + CHA2DS2-VA 1 (Ritmo cardiaco)

- **SI:** FA ECG confirmada y CHA2DS2-VA=1 en datos completos
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** fa_confirmada;chads_va_datos; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ESC_AF — https://academic.oup.com/eurheartj/article/45/36/3314/7738779.
- **Pasaje breve relacionado:** S21; **ubicación:** ESC 2024 AF guideline, key message 10.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** ECG requerido para diagnosticar fibrilación auricular.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PUNTUACION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0222: FA + CHA2DS2-VA≥2 (Ritmo cardiaco)

- **SI:** FA ECG confirmada y CHA2DS2-VA≥2 en datos completos
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** fa_confirmada;chads_va_datos; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ESC_AF — https://academic.oup.com/eurheartj/article/45/36/3314/7738779.
- **Pasaje breve relacionado:** S21; **ubicación:** ESC 2024 AF guideline, key message 10.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** ECG requerido para diagnosticar fibrilación auricular.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PUNTUACION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0223: ECG con FC auricular irregular (Ritmo cardiaco)

- **SI:** ECG de episodio sugiere FA: exigir valoración profesional para diagnóstico
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** ecg_onda; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ESC_AF — https://academic.oup.com/eurheartj/article/45/36/3314/7738779.
- **Pasaje breve relacionado:** S21; **ubicación:** ESC 2024 AF guideline, key message 10.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** ECG requerido para diagnosticar fibrilación auricular | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CONFIRMACION_ECG; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0224: Descenso HRV personal persistente (Ritmo cardiaco)

- **SI:** RMSSD nocturno cae≥30% vs 30 noches durante≥3 noches, sensor comparable
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** hrv_rmssd_serie;calidad_hrv; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ESC_AF — https://academic.oup.com/eurheartj/article/45/36/3314/7738779.
- **Pasaje breve relacionado:** S21; **ubicación:** ESC 2024 AF guideline, key message 10.
- **Clasificación original:** EXPERIMENTAL_NO_VALIDADA; **revisión v04:** SOLO_INVESTIGACION_DESACTIVADA.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** ECG requerido para diagnosticar fibrilación auricular | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PORCENTAJE_CAMBIO; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0225: HRV baja y FC alta (Ritmo cardiaco)

- **SI:** HRV RMSSD ≤0.7× basal y FC nocturna≥1.15× basal≥3 noches
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** hrv_rmssd;fc_nocturna; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ESC_AF — https://academic.oup.com/eurheartj/article/45/36/3314/7738779.
- **Pasaje breve relacionado:** S21; **ubicación:** ESC 2024 AF guideline, key message 10.
- **Clasificación original:** EXPERIMENTAL_NO_VALIDADA; **revisión v04:** SOLO_INVESTIGACION_DESACTIVADA.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** ECG requerido para diagnosticar fibrilación auricular | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0226: Pico FC sobre sensor (Ritmo cardiaco)

- **SI:** FC>180 de pulsera sin ECG, exigir verificación no etiquetar TSV
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** fc_ppg;calidad_ppg; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ESC_AF — https://academic.oup.com/eurheartj/article/45/36/3314/7738779.
- **Pasaje breve relacionado:** S21; **ubicación:** ESC 2024 AF guideline, key message 10.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** ECG requerido para diagnosticar fibrilación auricular | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** BPM; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0227: FC elevada y TSH baja (Ritmo cardiaco)

- **SI:** FC reposo>100 + TSH<0.1 mUI/L confirmado
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** fc_reposo;tsh; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_TSH — https://www.nice.org.uk/guidance/ng145/chapter/recommendations.
- **Pasaje breve relacionado:** S19; **ubicación:** NICE NG145, recommendation 1.2.8.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** ECG requerido para diagnosticar fibrilación auricular | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0228: FC elevada y anemia (Ritmo cardiaco)

- **SI:** FC reposo>100 + Hb bajo umbral OMS
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** fc_reposo;hb;sexo_modelo; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** WHO_HB24 — https://www.ncbi.nlm.nih.gov/books/NBK602183/table/fm-ch1.tab2/.
- **Pasaje breve relacionado:** S08; **ubicación:** OMS 2024, Table 3: Haemoglobin cutoffs / anaemia severity.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** ECG requerido para diagnosticar fibrilación auricular | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0229: FC elevada y hipoxemia (Ritmo cardiaco)

- **SI:** FC reposo>110 + SpO2<90 clínica repetida
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** fc_reposo;spo2_clinica; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ATS_OXYGEN — https://academic.oup.com/ajrccm/article/202/10/e121/8495596.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** ECG requerido para diagnosticar fibrilación auricular | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0230: PREVENT 10 años disponible (Cardiovascular)

- **SI:** 30≤edad≤79 sin ECV y todos predictores obligatorios completos
- **ENTONCES:** Evaluar prevención cardiovascular y confirmar según score o prueba indicada.
- **Variables:** edad;sexo_modelo;pa_validada;colesterol_total;hdl;egfr;diabetes_previa;fuma_actual;medicacion_estatinas;medicacion_hipertension; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CRIBADO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AHA_PREVENT — https://professional.heart.org/en/guidelines-and-statements/prevent-calculator.
- **Pasaje breve relacionado:** S30; **ubicación:** AHA Professional PREVENT calculator.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** comparar salida del modelo con calculadora original y calibración local; no porcentaje arbitrario.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PROBABILIDAD_10_ANOS; horizonte: 10 años; porcentaje calibrado: true.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0231: PREVENT no calculable por tabaquismo (Cardiovascular)

- **SI:** Ausencia de fuma_actual aunque todos los demás datos completos
- **ENTONCES:** Evaluar prevención cardiovascular y confirmar según score o prueba indicada.
- **Variables:** fuma_actual; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AHA_PREVENT — https://professional.heart.org/en/guidelines-and-statements/prevent-calculator.
- **Pasaje breve relacionado:** S30; **ubicación:** AHA Professional PREVENT calculator.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0232: PREVENT no calculable por medicación (Cardiovascular)

- **SI:** Falta uso estatinas y/o antihipertensivos declarado
- **ENTONCES:** Evaluar prevención cardiovascular y confirmar según score o prueba indicada.
- **Variables:** medicacion_estatinas;medicacion_hipertension; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AHA_PREVENT — https://professional.heart.org/en/guidelines-and-statements/prevent-calculator.
- **Pasaje breve relacionado:** S30; **ubicación:** AHA Professional PREVENT calculator.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0233: PREVENT no aplicable enfermedad previa (Cardiovascular)

- **SI:** Infarto/ictus/PAD previa documentada; pasar prevención secundaria
- **ENTONCES:** Evaluar prevención cardiovascular y confirmar según score o prueba indicada.
- **Variables:** ecv_previa; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AHA_PREVENT — https://professional.heart.org/en/guidelines-and-statements/prevent-calculator.
- **Pasaje breve relacionado:** S30; **ubicación:** AHA Professional PREVENT calculator.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0234: PREVENT fuera de edad (Cardiovascular)

- **SI:** Edad <30 o >79 años: no extrapolar sin validación
- **ENTONCES:** Evaluar prevención cardiovascular y confirmar según score o prueba indicada.
- **Variables:** edad; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AHA_PREVENT — https://professional.heart.org/en/guidelines-and-statements/prevent-calculator.
- **Pasaje breve relacionado:** S30; **ubicación:** AHA Professional PREVENT calculator.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0235: PREVENT 10y CVD≥7.5% + PA≥130 (Cardiovascular)

- **SI:** PREVENT-CVD10≥7.5% y PA promedio≥130/80: discutir tratamiento con clínico
- **ENTONCES:** Evaluar prevención cardiovascular y confirmar según score o prueba indicada.
- **Variables:** prevent_cvd_10y;pa_validada; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AHA_BP25 — https://www.jacc.org/doi/10.1016/j.jacc.2025.05.007.
- **Pasaje breve relacionado:** S03; **ubicación:** ACC/AHA 2025 hipertensión, categorías PA, Table 4.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** comparar salida del modelo con calculadora original y calibración local; no porcentaje arbitrario.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PROBABILIDAD_10_ANOS; horizonte: 10 años; porcentaje calibrado: true.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0236: SCORE2 no calibrado para México (Cardiovascular)

- **SI:** SCORE2 europeo en población mexicana sin validación regional
- **ENTONCES:** Evaluar prevención cardiovascular y confirmar según score o prueba indicada.
- **Variables:** pais;poblacion_score; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ESC_SCORE — https://www.escardio.org/guidelines/practice-tools/cvd-prevention-toolbox/score2-and-score2-op-calculators/.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0237: ECV establecida con LDL alto (Cardiovascular)

- **SI:** Infarto/ictus aterotrombótico/PAD previa y LDL≥70 mg/dL: consultar estrategia individual
- **ENTONCES:** Evaluar prevención cardiovascular y confirmar según score o prueba indicada.
- **Variables:** ecv_previa;ldl; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACC_LIP26 — https://www.jacc.org/doi/10.1016/j.jacc.2025.11.016.
- **Pasaje breve relacionado:** S12; **ubicación:** ACC/AHA Dyslipidemia 2026, Section 4.2.3.7.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MG_DL; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0238: Insuficiencia cardiaca conocida + peso (Cardiovascular)

- **SI:** IC previa y peso+2kg/3d en báscula comparable
- **ENTONCES:** Evaluar prevención cardiovascular y confirmar según score o prueba indicada.
- **Variables:** ic_previa;peso_serie; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ESC_HF21 — https://academic.oup.com/eurheartj/article/42/36/3599/6358045.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** DELTA_KG; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0239: IC conocida + frecuencia elevada (Cardiovascular)

- **SI:** IC previa y FC reposo mediana semanal ≥15% sobre basal, ≥3d
- **ENTONCES:** Evaluar prevención cardiovascular y confirmar según score o prueba indicada.
- **Variables:** ic_previa;fc_baseline;fc_semana; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ESC_HF21 — https://academic.oup.com/eurheartj/article/42/36/3599/6358045.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** EXPERIMENTAL_NO_VALIDADA; **revisión v04:** SOLO_INVESTIGACION_DESACTIVADA.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PORCENTAJE_CAMBIO; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0240: IC conocida + presión baja (Cardiovascular)

- **SI:** IC previa y PAS≤90 medida validada y nueva
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** ic_previa;pas_validada; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ESC_HF21 — https://academic.oup.com/eurheartj/article/42/36/3599/6358045.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MMHG; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0241: IC conocida + desaturación (Cardiovascular)

- **SI:** IC previa y SpO2 clínica ≤92% repetida diferente basal
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** ic_previa;spo2_clinica;spo2_baseline; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ESC_HF21 — https://academic.oup.com/eurheartj/article/42/36/3599/6358045.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0242: ABI sospecha PAD (Cardiovascular)

- **SI:** Índice tobillo-brazo≤0.90 en evaluación estandarizada
- **ENTONCES:** Evaluar prevención cardiovascular y confirmar según score o prueba indicada.
- **Variables:** abi; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACC_PAD24 — https://www.jacc.org/doi/10.1016/j.jacc.2024.02.013.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** COCIENTE; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0243: ABI limítrofe (Cardiovascular)

- **SI:** 0.91≤ABI≤0.99; correlacionar con síntomas/antecedentes si existen
- **ENTONCES:** Evaluar prevención cardiovascular y confirmar según score o prueba indicada.
- **Variables:** abi; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACC_PAD24 — https://www.jacc.org/doi/10.1016/j.jacc.2024.02.013.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** COCIENTE; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0244: ABI normal (Cardiovascular)

- **SI:** 1.00≤ABI≤1.40 en contexto clínico apropiado
- **ENTONCES:** Evaluar prevención cardiovascular y confirmar según score o prueba indicada.
- **Variables:** abi; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACC_PAD24 — https://www.jacc.org/doi/10.1016/j.jacc.2024.02.013.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** COCIENTE; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0245: ABI no compresible (Cardiovascular)

- **SI:** ABI>1.40: utilizar índice dedo-brazo si PAD sospechada
- **ENTONCES:** Evaluar prevención cardiovascular y confirmar según score o prueba indicada.
- **Variables:** abi; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACC_PAD24 — https://www.jacc.org/doi/10.1016/j.jacc.2024.02.013.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** COCIENTE; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0246: EAP alto riesgo por diabetes (Cardiovascular)

- **SI:** Diabetes establecida y edad≥65: considerar evaluación arterial si hallazgos o riesgo
- **ENTONCES:** Evaluar prevención cardiovascular y confirmar según score o prueba indicada.
- **Variables:** diabetes_previa;edad; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CRIBADO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACC_PAD24 — https://www.jacc.org/doi/10.1016/j.jacc.2024.02.013.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0247: EAP alto riesgo con tabaquismo (Cardiovascular)

- **SI:** Edad≥50 + tabaquismo actual o antecedente; si hay dato
- **ENTONCES:** Evaluar prevención cardiovascular y confirmar según score o prueba indicada.
- **Variables:** edad;fuma_actual; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CRIBADO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACC_PAD24 — https://www.jacc.org/doi/10.1016/j.jacc.2024.02.013.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0248: Pérdida pulmonar y cardiovascular combinada (Cardiovascular)

- **SI:** SpO2↓≥4pp vs basal + FC↑≥20% vs basal en reposo,≥10 min
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** spo2_baseline;spo2;fc_baseline;fc; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ATS_OXYGEN — https://academic.oup.com/ajrccm/article/202/10/e121/8495596.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** EXPERIMENTAL_NO_VALIDADA; **revisión v04:** SOLO_INVESTIGACION_DESACTIVADA.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0249: Hipoglucemia CGM nivel 1 (Glucosa)

- **SI:** 54≤CGM<70 mg/dL por≥15 min y señal válida
- **ENTONCES:** Revisión clínica del control glucémico; distinguir CGM de plasma diagnóstico.
- **Variables:** cgm;calidad_cgm; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_GLY26 — https://doi.org/10.2337/dc26-s006.
- **Pasaje breve relacionado:** S02; **ubicación:** ADA Standards of Care 2026, Section 6 / Table 6.2.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MINUTOS_BAJO_RANGO; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0250: Hipoglucemia CGM nivel 2 (Glucosa)

- **SI:** CGM<54 mg/dL y señal válida: comprobar glucemia capilar si factible sin retrasar atención
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** cgm;calidad_cgm; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_GLY26 — https://doi.org/10.2337/dc26-s006.
- **Pasaje breve relacionado:** S02; **ubicación:** ADA Standards of Care 2026, Section 6 / Table 6.2.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MINUTOS_BAJO_RANGO; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0251: Hipoglucemia nivel 3 clínica (Glucosa)

- **SI:** Ayuda de tercera persona por alteración física/mental atribuible a hipoglucemia, independiente del valor
- **ENTONCES:** Solicitar evaluación médica inmediata; no administrar tratamientos automáticamente.
- **Variables:** evento_ayuda_tercero;hipoglucemia_clinica; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CRITICA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_GLY26 — https://doi.org/10.2337/dc26-s006.
- **Pasaje breve relacionado:** S02; **ubicación:** ADA Standards of Care 2026, Section 6 / Table 6.2.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_EVENTOS; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0252: TBR bajo 70 elevado (Glucosa)

- **SI:** Diabetes con CGM 14d≥70% cobertura y TBR<70≥4%
- **ENTONCES:** Revisión clínica del control glucémico; distinguir CGM de plasma diagnóstico.
- **Variables:** diabetes_previa;cgm_14d;cgm_cobertura; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_GLY26 — https://doi.org/10.2337/dc26-s006.
- **Pasaje breve relacionado:** S02; **ubicación:** ADA Standards of Care 2026, Section 6 / Table 6.2.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PORCENTAJE_TIEMPO; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0253: TBR bajo 54 elevado (Glucosa)

- **SI:** Diabetes con CGM 14d≥70% cobertura y TBR<54≥1%
- **ENTONCES:** Revisión clínica del control glucémico; distinguir CGM de plasma diagnóstico.
- **Variables:** diabetes_previa;cgm_14d;cgm_cobertura; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_GLY26 — https://doi.org/10.2337/dc26-s006.
- **Pasaje breve relacionado:** S02; **ubicación:** ADA Standards of Care 2026, Section 6 / Table 6.2.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PORCENTAJE_TIEMPO; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0254: TIR 70–180 bajo (Glucosa)

- **SI:** Diabetes no embarazada; CGM 14d cobertura≥70% y tiempo 70–180≤70%
- **ENTONCES:** Revisión clínica del control glucémico; distinguir CGM de plasma diagnóstico.
- **Variables:** diabetes_previa;embarazo_estado;cgm_14d;cgm_cobertura; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_GLY26 — https://doi.org/10.2337/dc26-s006.
- **Pasaje breve relacionado:** S02; **ubicación:** ADA Standards of Care 2026, Section 6 / Table 6.2.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PORCENTAJE_TIEMPO; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0255: TAR 181–250 elevado (Glucosa)

- **SI:** Diabetes no embarazada; >25% tiempo CGM entre 181 y 250 mg/dL
- **ENTONCES:** Revisión clínica del control glucémico; distinguir CGM de plasma diagnóstico.
- **Variables:** diabetes_previa;cgm_14d;cgm_cobertura; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_GLY24 — https://pmc.ncbi.nlm.nih.gov/articles/PMC10725808/.
- **Pasaje breve relacionado:** S02; **ubicación:** ADA Standards of Care 2026, Section 6 / Table 6.2.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PORCENTAJE_TIEMPO; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0256: TAR>250 elevado (Glucosa)

- **SI:** Diabetes no embarazada; >5% tiempo CGM>250 mg/dL
- **ENTONCES:** Revisión clínica del control glucémico; distinguir CGM de plasma diagnóstico.
- **Variables:** diabetes_previa;cgm_14d;cgm_cobertura; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_GLY24 — https://pmc.ncbi.nlm.nih.gov/articles/PMC10725808/.
- **Pasaje breve relacionado:** S02; **ubicación:** ADA Standards of Care 2026, Section 6 / Table 6.2.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PORCENTAJE_TIEMPO; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0257: Variabilidad CGM elevada (Glucosa)

- **SI:** Diabetes; coeficiente de variación glucosa >36% en 14d válidos
- **ENTONCES:** Revisión clínica del control glucémico; distinguir CGM de plasma diagnóstico.
- **Variables:** diabetes_previa;cgm_14d;cgm_cobertura; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_GLY24 — https://pmc.ncbi.nlm.nih.gov/articles/PMC10725808/.
- **Pasaje breve relacionado:** S02; **ubicación:** ADA Standards of Care 2026, Section 6 / Table 6.2.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** COEF_VARIACION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0258: Prediabetes A1c tramo inferior (Glucosa)

- **SI:** HbA1c laboratorio 5.7–5.9% en no embarazadas
- **ENTONCES:** Revisión clínica del control glucémico; distinguir CGM de plasma diagnóstico.
- **Variables:** hba1c;embarazo_estado; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_DX26 — https://pmc.ncbi.nlm.nih.gov/articles/PMC12690183/.
- **Pasaje breve relacionado:** S01; **ubicación:** ADA Standards of Care 2026, Section 2 / Table 2.1.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PORCENTAJE_A1C; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0259: Prediabetes A1c tramo intermedio (Glucosa)

- **SI:** HbA1c laboratorio 6.0–6.2% en no embarazadas
- **ENTONCES:** Revisión clínica del control glucémico; distinguir CGM de plasma diagnóstico.
- **Variables:** hba1c;embarazo_estado; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_DX26 — https://pmc.ncbi.nlm.nih.gov/articles/PMC12690183/.
- **Pasaje breve relacionado:** S01; **ubicación:** ADA Standards of Care 2026, Section 2 / Table 2.1.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PORCENTAJE_A1C; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0260: Prediabetes A1c tramo superior (Glucosa)

- **SI:** HbA1c laboratorio 6.3–6.4% en no embarazadas
- **ENTONCES:** Revisión clínica del control glucémico; distinguir CGM de plasma diagnóstico.
- **Variables:** hba1c;embarazo_estado; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_DX26 — https://pmc.ncbi.nlm.nih.gov/articles/PMC12690183/.
- **Pasaje breve relacionado:** S01; **ubicación:** ADA Standards of Care 2026, Section 2 / Table 2.1.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PORCENTAJE_A1C; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0261: Diabetes A1c criterio laboratorio (Glucosa)

- **SI:** HbA1c laboratorio ≥6.5% y no embarazo; repetir si no hay hiperglucemia inequívoca
- **ENTONCES:** Revisión clínica del control glucémico; distinguir CGM de plasma diagnóstico.
- **Variables:** hba1c;embarazo_estado; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_DX26 — https://pmc.ncbi.nlm.nih.gov/articles/PMC12690183/.
- **Pasaje breve relacionado:** S01; **ubicación:** ADA Standards of Care 2026, Section 2 / Table 2.1.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PORCENTAJE_A1C; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0262: Diabetes glucosa ayuno criterio (Glucosa)

- **SI:** Plasma en ayuno ≥126 mg/dL, ≥8h y no embarazo; confirmación según ADA
- **ENTONCES:** Revisión clínica del control glucémico; distinguir CGM de plasma diagnóstico.
- **Variables:** glucosa_plasmatica_ayuno;ayuno_horas;embarazo_estado; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_DX26 — https://pmc.ncbi.nlm.nih.gov/articles/PMC12690183/.
- **Pasaje breve relacionado:** S01; **ubicación:** ADA Standards of Care 2026, Section 2 / Table 2.1.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MG_DL; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0263: Prediabetes glucosa ayuno (Glucosa)

- **SI:** 100≤glucosa plasmática ayuno≤125 mg/dL; ≥8h no embarazada
- **ENTONCES:** Revisión clínica del control glucémico; distinguir CGM de plasma diagnóstico.
- **Variables:** glucosa_plasmatica_ayuno;ayuno_horas;embarazo_estado; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_DX26 — https://pmc.ncbi.nlm.nih.gov/articles/PMC12690183/.
- **Pasaje breve relacionado:** S01; **ubicación:** ADA Standards of Care 2026, Section 2 / Table 2.1.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MG_DL; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0264: Intolerancia glucosa OGTT (Glucosa)

- **SI:** OGTT 75g a 2h 140–199 mg/dL, plasma, no embarazo
- **ENTONCES:** Revisión clínica del control glucémico; distinguir CGM de plasma diagnóstico.
- **Variables:** ogtt_2h;embarazo_estado; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_DX26 — https://pmc.ncbi.nlm.nih.gov/articles/PMC12690183/.
- **Pasaje breve relacionado:** S01; **ubicación:** ADA Standards of Care 2026, Section 2 / Table 2.1.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MG_DL; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0265: Criterio diabetes OGTT (Glucosa)

- **SI:** OGTT 75g a 2h ≥200 mg/dL, plasma, no embarazo
- **ENTONCES:** Revisión clínica del control glucémico; distinguir CGM de plasma diagnóstico.
- **Variables:** ogtt_2h;embarazo_estado; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_DX26 — https://pmc.ncbi.nlm.nih.gov/articles/PMC12690183/.
- **Pasaje breve relacionado:** S01; **ubicación:** ADA Standards of Care 2026, Section 2 / Table 2.1.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MG_DL; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0266: Diabetes al azar con síntomas (Glucosa)

- **SI:** Glucosa plasmática aleatoria≥200 mg/dL + síntomas clásicos
- **ENTONCES:** Revisión clínica del control glucémico; distinguir CGM de plasma diagnóstico.
- **Variables:** glucosa_plasmatica_azar;sintomas_hiperglucemia; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_DX26 — https://pmc.ncbi.nlm.nih.gov/articles/PMC12690183/.
- **Pasaje breve relacionado:** S01; **ubicación:** ADA Standards of Care 2026, Section 2 / Table 2.1.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MG_DL; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0267: Diabetes al azar sin síntomas (Glucosa)

- **SI:** Glucosa plasmática aleatoria≥200 sin síntomas reportados; solicitar confirmación
- **ENTONCES:** Revisión clínica del control glucémico; distinguir CGM de plasma diagnóstico.
- **Variables:** glucosa_plasmatica_azar;sintomas_hiperglucemia; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_DX26 — https://pmc.ncbi.nlm.nih.gov/articles/PMC12690183/.
- **Pasaje breve relacionado:** S01; **ubicación:** ADA Standards of Care 2026, Section 2 / Table 2.1.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MG_DL; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0268: A1c 6.5 confirmada dos veces (Glucosa)

- **SI:** ≥2 pruebas HbA1c laboratorio ≥6.5% en fechas distintas, sin interferencia significativa
- **ENTONCES:** Revisión clínica del control glucémico; distinguir CGM de plasma diagnóstico.
- **Variables:** hba1c_historial;embarazo_estado; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_DX26 — https://pmc.ncbi.nlm.nih.gov/articles/PMC12690183/.
- **Pasaje breve relacionado:** S01; **ubicación:** ADA Standards of Care 2026, Section 2 / Table 2.1.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_PRUEBAS; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0269: Discordancia A1c vs plasma (Glucosa)

- **SI:** HbA1c por encima umbral diagnóstico y glucosa plasmática no concordante
- **ENTONCES:** Revisión clínica del control glucémico; distinguir CGM de plasma diagnóstico.
- **Variables:** hba1c;glucosa_plasmatica_ayuno; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_DX26 — https://pmc.ncbi.nlm.nih.gov/articles/PMC12690183/.
- **Pasaje breve relacionado:** S01; **ubicación:** ADA Standards of Care 2026, Section 2 / Table 2.1.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0270: Hiperglucemia CGM sostenida no diagnóstica (Glucosa)

- **SI:** CGM>180 mg/dL más de 25% de 14 días en no diagnosticado
- **ENTONCES:** Revisión clínica del control glucémico; distinguir CGM de plasma diagnóstico.
- **Variables:** cgm_14d;diabetes_previa; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CRIBADO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_DX26 — https://pmc.ncbi.nlm.nih.gov/articles/PMC12690183/.
- **Pasaje breve relacionado:** S01; **ubicación:** ADA Standards of Care 2026, Section 2 / Table 2.1.
- **Clasificación original:** EXPERIMENTAL_NO_VALIDADA; **revisión v04:** SOLO_INVESTIGACION_DESACTIVADA.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PORCENTAJE_TIEMPO; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0271: Hiperglucemia CGM matutina no diagnóstica (Glucosa)

- **SI:** Mediana CGM 06:00–09:00 >125 mg/dL ≥7 de 14 días en no diagnosticado
- **ENTONCES:** Revisión clínica del control glucémico; distinguir CGM de plasma diagnóstico.
- **Variables:** cgm_14d;diabetes_previa; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CRIBADO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_DX26 — https://pmc.ncbi.nlm.nih.gov/articles/PMC12690183/.
- **Pasaje breve relacionado:** S01; **ubicación:** ADA Standards of Care 2026, Section 2 / Table 2.1.
- **Clasificación original:** EXPERIMENTAL_NO_VALIDADA; **revisión v04:** SOLO_INVESTIGACION_DESACTIVADA.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MG_DL; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0272: Glucosa nocturna baja recurrente (Glucosa)

- **SI:** CGM <70 mg/dL durante≥15 min ≥3 noches/14, corroborar compresión
- **ENTONCES:** Revisión clínica del control glucémico; distinguir CGM de plasma diagnóstico.
- **Variables:** cgm_14d;cgm_calidad; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_GLY26 — https://doi.org/10.2337/dc26-s006.
- **Pasaje breve relacionado:** S02; **ubicación:** ADA Standards of Care 2026, Section 6 / Table 6.2.
- **Clasificación original:** EXPERIMENTAL_NO_VALIDADA; **revisión v04:** SOLO_INVESTIGACION_DESACTIVADA.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_EPISODIOS; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0273: Hipoglucemia repetida en diabetes (Glucosa)

- **SI:** CGM <54 mg/dL ≥2 episodios/14d con señal validada
- **ENTONCES:** Revisión clínica del control glucémico; distinguir CGM de plasma diagnóstico.
- **Variables:** cgm_14d;diabetes_previa; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_GLY26 — https://doi.org/10.2337/dc26-s006.
- **Pasaje breve relacionado:** S02; **ubicación:** ADA Standards of Care 2026, Section 6 / Table 6.2.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_EPISODIOS; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0274: Hiperglucemia con pérdida de peso (Glucosa)

- **SI:** Glucosa plasmática ayuno≥126 y caída peso no intencional≥5%/6meses
- **ENTONCES:** Revisión clínica del control glucémico; distinguir CGM de plasma diagnóstico.
- **Variables:** glucosa_plasmatica_ayuno;peso_historial; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_DX26 — https://pmc.ncbi.nlm.nih.gov/articles/PMC12690183/.
- **Pasaje breve relacionado:** S01; **ubicación:** ADA Standards of Care 2026, Section 2 / Table 2.1.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0275: Hiperglucemia + eGFR bajo (Glucosa)

- **SI:** Diabetes conocida + HbA1c fuera de objetivo individual + eGFR<60
- **ENTONCES:** Revisión clínica del control glucémico; distinguir CGM de plasma diagnóstico.
- **Variables:** diabetes_previa;hba1c;egfr; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** KDIGO24 — https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf.
- **Pasaje breve relacionado:** S05; **ubicación:** KDIGO 2024 ERC, Practice Point 2.2.1, página S156.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0276: Hiperglucemia + albuminuria A2 (Glucosa)

- **SI:** Diabetes conocida + ACR urinario 30–300 mg/g persistente
- **ENTONCES:** Revisión clínica del control glucémico; distinguir CGM de plasma diagnóstico.
- **Variables:** diabetes_previa;acr_orina;acr_historial; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** KDIGO24 — https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf.
- **Pasaje breve relacionado:** S05; **ubicación:** KDIGO 2024 ERC, Practice Point 2.2.1, página S156.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MG_G; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0277: Hiperglucemia + albuminuria A3 (Glucosa)

- **SI:** Diabetes conocida + ACR urinario >300 mg/g persistente
- **ENTONCES:** Revisión clínica del control glucémico; distinguir CGM de plasma diagnóstico.
- **Variables:** diabetes_previa;acr_orina;acr_historial; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** KDIGO24 — https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf.
- **Pasaje breve relacionado:** S05; **ubicación:** KDIGO 2024 ERC, Practice Point 2.2.1, página S156.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MG_G; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0278: Control CGM especialmente conservador anciano (Glucosa)

- **SI:** Edad≥65 diabetes y TBR<70 ≥1% (objetivos adaptables)
- **ENTONCES:** Revisión clínica del control glucémico; distinguir CGM de plasma diagnóstico.
- **Variables:** edad;diabetes_previa;cgm_14d; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_GLY26 — https://doi.org/10.2337/dc26-s006.
- **Pasaje breve relacionado:** S02; **ubicación:** ADA Standards of Care 2026, Section 6 / Table 6.2.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PORCENTAJE_TIEMPO; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0279: Tiempo CGM 14 días insuficiente (Glucosa)

- **SI:** CGM activo <70% o menos de 14 días para perfil de patrón
- **ENTONCES:** Revisión clínica del control glucémico; distinguir CGM de plasma diagnóstico.
- **Variables:** cgm_serie;cgm_cobertura; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ISPAD_CGM24 — https://pmc.ncbi.nlm.nih.gov/articles/PMC11854985/.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PORCENTAJE_COBERTURA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0280: GMI discrepante con A1c (Glucosa)

- **SI:** Distancia absoluta GMI−HbA1c ≥0.5pp en control; verificar causas
- **ENTONCES:** Revisión clínica del control glucémico; distinguir CGM de plasma diagnóstico.
- **Variables:** gmi;hba1c; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_GLY24 — https://pmc.ncbi.nlm.nih.gov/articles/PMC10725808/.
- **Pasaje breve relacionado:** S02; **ubicación:** ADA Standards of Care 2026, Section 6 / Table 6.2.
- **Clasificación original:** EXPERIMENTAL_NO_VALIDADA; **revisión v04:** SOLO_INVESTIGACION_DESACTIVADA.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** DELTA_PP; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0281: Diabetes previa y severa hipoglucemia histórica (Glucosa)

- **SI:** Diabetes + antecedente nivel 3 requiere revisión plan aunque TIR actual adecuado
- **ENTONCES:** Revisión clínica del control glucémico; distinguir CGM de plasma diagnóstico.
- **Variables:** diabetes_previa;hipoglucemia_severa_previa; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_GLY26 — https://doi.org/10.2337/dc26-s006.
- **Pasaje breve relacionado:** S02; **ubicación:** ADA Standards of Care 2026, Section 6 / Table 6.2.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_EVENTOS; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0282: Diabetes previa con enfermedad CV (Glucosa)

- **SI:** Diabetes + ECV establecida: prevención secundaria cardiometabólica
- **ENTONCES:** Revisión clínica del control glucémico; distinguir CGM de plasma diagnóstico.
- **Variables:** diabetes_previa;ecv_previa; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACC_LIP26 — https://www.jacc.org/doi/10.1016/j.jacc.2025.11.016.
- **Pasaje breve relacionado:** S12; **ubicación:** ACC/AHA Dyslipidemia 2026, Section 4.2.3.7.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0283: Diabetes con HbA1c >9 (Glucosa)

- **SI:** Diabetes conocida + HbA1c>9%: tratamiento y causas a revisar clínicamente
- **ENTONCES:** Revisión clínica del control glucémico; distinguir CGM de plasma diagnóstico.
- **Variables:** diabetes_previa;hba1c; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_GLY26 — https://doi.org/10.2337/dc26-s006.
- **Pasaje breve relacionado:** S02; **ubicación:** ADA Standards of Care 2026, Section 6 / Table 6.2.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PORCENTAJE_A1C; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0284: Prediabetes recurrente a 12 meses (Glucosa)

- **SI:** HbA1c 5.7–6.4% en al menos dos mediciones separadas≥12 meses
- **ENTONCES:** Revisión clínica del control glucémico; distinguir CGM de plasma diagnóstico.
- **Variables:** hba1c_historial; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_DX26 — https://pmc.ncbi.nlm.nih.gov/articles/PMC12690183/.
- **Pasaje breve relacionado:** S01; **ubicación:** ADA Standards of Care 2026, Section 2 / Table 2.1.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_PRUEBAS; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0285: LDL colesterol muy alto (Lípidos)

- **SI:** LDL-C ≥190 mg/dL en muestra validada; evaluar hipercolesterolemia familiar
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** ldl; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACC_LIP26 — https://www.jacc.org/doi/10.1016/j.jacc.2025.11.016.
- **Pasaje breve relacionado:** S12; **ubicación:** ACC/AHA Dyslipidemia 2026, Section 4.2.3.7.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MG_DL; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0286: LDL alto con diabetes (Lípidos)

- **SI:** Diabetes establecida + LDL≥100 mg/dL; valorar plan por riesgo individual
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** ldl;diabetes_previa; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACC_LIP26 — https://www.jacc.org/doi/10.1016/j.jacc.2025.11.016.
- **Pasaje breve relacionado:** S12; **ubicación:** ACC/AHA Dyslipidemia 2026, Section 4.2.3.7.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0287: LDL alto con ECV aterosclerótica previa (Lípidos)

- **SI:** ECV documentada + LDL≥70 mg/dL; revisar objetivo aplicable
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** ldl;ecv_previa; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACC_LIP26 — https://www.jacc.org/doi/10.1016/j.jacc.2025.11.016.
- **Pasaje breve relacionado:** S12; **ubicación:** ACC/AHA Dyslipidemia 2026, Section 4.2.3.7.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MG_DL; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0288: Triglicéridos 150-499 (Lípidos)

- **SI:** TG 150–499 mg/dL persistentes en adulto
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** trigliceridos; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACC_LIP26 — https://www.jacc.org/doi/10.1016/j.jacc.2025.11.016.
- **Pasaje breve relacionado:** S12; **ubicación:** ACC/AHA Dyslipidemia 2026, Section 4.2.3.7.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MG_DL; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0289: Triglicéridos 500-999 (Lípidos)

- **SI:** TG 500–999 mg/dL: riesgo de pancreatitis aumenta
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** trigliceridos; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACC_LIP26 — https://www.jacc.org/doi/10.1016/j.jacc.2025.11.016.
- **Pasaje breve relacionado:** S12; **ubicación:** ACC/AHA Dyslipidemia 2026, Section 4.2.3.7.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MG_DL; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0290: Triglicéridos ≥1000 (Lípidos)

- **SI:** TG≥1000 mg/dL; evaluación pronta por riesgo importante pancreatitis
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** trigliceridos; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACC_LIP26 — https://www.jacc.org/doi/10.1016/j.jacc.2025.11.016.
- **Pasaje breve relacionado:** S12; **ubicación:** ACC/AHA Dyslipidemia 2026, Section 4.2.3.7.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MG_DL; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0291: Colesterol no HDL derivable (Lípidos)

- **SI:** No-HDL = colesterol total − HDL; reportar continuo
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** colesterol_total;hdl; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACC_LIP26 — https://www.jacc.org/doi/10.1016/j.jacc.2025.11.016.
- **Pasaje breve relacionado:** S12; **ubicación:** ACC/AHA Dyslipidemia 2026, Section 4.2.3.7.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MG_DL; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0292: No-HDL y TG elevados (Lípidos)

- **SI:** TG≥150 y no-HDL elevado según objetivo individual calculado
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** trigliceridos;colesterol_no_hdl;objetivo_no_hdl; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACC_LIP26 — https://www.jacc.org/doi/10.1016/j.jacc.2025.11.016.
- **Pasaje breve relacionado:** S12; **ubicación:** ACC/AHA Dyslipidemia 2026, Section 4.2.3.7.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MG_DL; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0293: ApoB elevado en contexto TG alto (Lípidos)

- **SI:** TG≥150 y apoB sobre objetivo individual establecido
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** trigliceridos;apoB;objetivo_apoB; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACC_LIP26 — https://www.jacc.org/doi/10.1016/j.jacc.2025.11.016.
- **Pasaje breve relacionado:** S12; **ubicación:** ACC/AHA Dyslipidemia 2026, Section 4.2.3.7.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MG_DL; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0294: TG alto con A1c diagnóstica (Lípidos)

- **SI:** TG≥500 y HbA1c≥6.5%, sin confirmación de ambos no atribuir causa
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** trigliceridos;hba1c; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACC_LIP26 — https://www.jacc.org/doi/10.1016/j.jacc.2025.11.016.
- **Pasaje breve relacionado:** S12; **ubicación:** ACC/AHA Dyslipidemia 2026, Section 4.2.3.7.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0295: TG alto con TSH elevada (Lípidos)

- **SI:** TG≥150 y TSH superior referencia: investigar causa secundaria
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** trigliceridos;tsh; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACC_LIP26 — https://www.jacc.org/doi/10.1016/j.jacc.2025.11.016.
- **Pasaje breve relacionado:** S12; **ubicación:** ACC/AHA Dyslipidemia 2026, Section 4.2.3.7.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0296: TG alto con ERC (Lípidos)

- **SI:** TG≥150 y ERC conocida: seguimiento cardiovascular y renal
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** trigliceridos;erc_previa; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACC_LIP26 — https://www.jacc.org/doi/10.1016/j.jacc.2025.11.016.
- **Pasaje breve relacionado:** S12; **ubicación:** ACC/AHA Dyslipidemia 2026, Section 4.2.3.7.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0297: Dislipidemia mixta (Lípidos)

- **SI:** TG≥150 + LDL elevado según laboratorio/objetivo clínico
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** trigliceridos;ldl;objetivo_ldl; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACC_LIP26 — https://www.jacc.org/doi/10.1016/j.jacc.2025.11.016.
- **Pasaje breve relacionado:** S12; **ubicación:** ACC/AHA Dyslipidemia 2026, Section 4.2.3.7.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0298: Perfil lipídico discordante (Lípidos)

- **SI:** LDL calculado por Friedewald con TG≥400, solicitar método apropiado
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** trigliceridos;ldl_metodo; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACC_LIP26 — https://www.jacc.org/doi/10.1016/j.jacc.2025.11.016.
- **Pasaje breve relacionado:** S12; **ubicación:** ACC/AHA Dyslipidemia 2026, Section 4.2.3.7.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0299: LDL <55 para ECV alto riesgo (Lípidos)

- **SI:** ECV muy alto riesgo y LDL≥55 según manejo intensivo individual
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** ldl;ecv_previa;estrato_riesgo; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACC_LIP26 — https://www.jacc.org/doi/10.1016/j.jacc.2025.11.016.
- **Pasaje breve relacionado:** S12; **ubicación:** ACC/AHA Dyslipidemia 2026, Section 4.2.3.7.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MG_DL; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0300: Cambio LDL a 3 meses (Lípidos)

- **SI:** LDL aumenta ≥20% frente análisis comparables, verificar adherencia/causas
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** ldl_historial; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACC_LIP26 — https://www.jacc.org/doi/10.1016/j.jacc.2025.11.016.
- **Pasaje breve relacionado:** S12; **ubicación:** ACC/AHA Dyslipidemia 2026, Section 4.2.3.7.
- **Clasificación original:** EXPERIMENTAL_NO_VALIDADA; **revisión v04:** SOLO_INVESTIGACION_DESACTIVADA.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PORCENTAJE_CAMBIO; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0301: Lipoproteína(a) alta (Lípidos)

- **SI:** Lp(a)≥125 nmol/L o ≥50 mg/dL, no convertir unidades con factor fijo
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** lp_a;unidad_lp_a; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACC_LIP26 — https://www.jacc.org/doi/10.1016/j.jacc.2025.11.016.
- **Pasaje breve relacionado:** S12; **ubicación:** ACC/AHA Dyslipidemia 2026, Section 4.2.3.7.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** UNIDAD_SEGUN_METODO; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0302: ApoB 130 y contexto (Lípidos)

- **SI:** ApoB≥130 mg/dL en laboratorio confiable, valorar modificador riesgo
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** apoB; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACC_LIP26 — https://www.jacc.org/doi/10.1016/j.jacc.2025.11.016.
- **Pasaje breve relacionado:** S12; **ubicación:** ACC/AHA Dyslipidemia 2026, Section 4.2.3.7.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MG_DL; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0303: Elevación TG aislada transitoria (Lípidos)

- **SI:** TG≥150 durante enfermedad aguda: repetir al recuperarse
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** trigliceridos;enfermedad_aguda; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACC_LIP26 — https://www.jacc.org/doi/10.1016/j.jacc.2025.11.016.
- **Pasaje breve relacionado:** S12; **ubicación:** ACC/AHA Dyslipidemia 2026, Section 4.2.3.7.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MG_DL; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0304: Dislipidemia sin perfil completo (Lípidos)

- **SI:** Sólo colesterol total disponible: no calcular PREVENT ni LDL derivado
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** colesterol_total;hdl; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AHA_PREVENT — https://professional.heart.org/en/guidelines-and-statements/prevent-calculator.
- **Pasaje breve relacionado:** S30; **ubicación:** AHA Professional PREVENT calculator.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0305: ERC G1 si daño persistente (Riñón)

- **SI:** eGFR≥90 y ACR≥30 persistente≥3 meses: ERC con daño renal
- **ENTONCES:** Revisión clínica nefrológica o general según cronicidad; comprobar analítica y tendencia.
- **Variables:** egfr;acr_orina;acr_historial; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** KDIGO24 — https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf.
- **Pasaje breve relacionado:** S05; **ubicación:** KDIGO 2024 ERC, Practice Point 2.2.1, página S156.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CGACAT; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0306: ERC G2 si daño persistente (Riñón)

- **SI:** 60≤eGFR<90 y ACR≥30 persistente≥3 meses
- **ENTONCES:** Revisión clínica nefrológica o general según cronicidad; comprobar analítica y tendencia.
- **Variables:** egfr;acr_orina;acr_historial; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** KDIGO24 — https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf.
- **Pasaje breve relacionado:** S05; **ubicación:** KDIGO 2024 ERC, Practice Point 2.2.1, página S156.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CGACAT; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0307: ERC G3a potencial (Riñón)

- **SI:** 45≤eGFR<60 persistente≥3 meses; investigar daño renal y causa
- **ENTONCES:** Revisión clínica nefrológica o general según cronicidad; comprobar analítica y tendencia.
- **Variables:** egfr_historial; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** KDIGO24 — https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf.
- **Pasaje breve relacionado:** S05; **ubicación:** KDIGO 2024 ERC, Practice Point 2.2.1, página S156.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CGACAT; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0308: ERC G3b potencial (Riñón)

- **SI:** 30≤eGFR<45 persistente≥3 meses
- **ENTONCES:** Revisión clínica nefrológica o general según cronicidad; comprobar analítica y tendencia.
- **Variables:** egfr_historial; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** KDIGO24 — https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf.
- **Pasaje breve relacionado:** S05; **ubicación:** KDIGO 2024 ERC, Practice Point 2.2.1, página S156.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CGACAT; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0309: ERC G4 potencial (Riñón)

- **SI:** 15≤eGFR<30 persistente≥3 meses
- **ENTONCES:** Revisión clínica nefrológica o general según cronicidad; comprobar analítica y tendencia.
- **Variables:** egfr_historial; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** KDIGO24 — https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf.
- **Pasaje breve relacionado:** S05; **ubicación:** KDIGO 2024 ERC, Practice Point 2.2.1, página S156.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CGACAT; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0310: ERC G5 potencial (Riñón)

- **SI:** eGFR<15 persistente o alteración grave actual; atención especializada
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** egfr_historial; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** KDIGO24 — https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf.
- **Pasaje breve relacionado:** S05; **ubicación:** KDIGO 2024 ERC, Practice Point 2.2.1, página S156.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CGACAT; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0311: Albuminuria A1 (Riñón)

- **SI:** ACR<30 mg/g, reportar categoría sin deducir ausencia ERC
- **ENTONCES:** Revisión clínica nefrológica o general según cronicidad; comprobar analítica y tendencia.
- **Variables:** acr_orina; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** KDIGO24 — https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf.
- **Pasaje breve relacionado:** S05; **ubicación:** KDIGO 2024 ERC, Practice Point 2.2.1, página S156.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CGACAT; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0312: Albuminuria A2 (Riñón)

- **SI:** 30≤ACR≤300 mg/g, confirmar persistencia según contexto
- **ENTONCES:** Revisión clínica nefrológica o general según cronicidad; comprobar analítica y tendencia.
- **Variables:** acr_orina; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** KDIGO24 — https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf.
- **Pasaje breve relacionado:** S05; **ubicación:** KDIGO 2024 ERC, Practice Point 2.2.1, página S156.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CGACAT; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0313: Albuminuria A3 (Riñón)

- **SI:** ACR>300 mg/g, confirmar y derivar según riesgo
- **ENTONCES:** Revisión clínica nefrológica o general según cronicidad; comprobar analítica y tendencia.
- **Variables:** acr_orina; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** KDIGO24 — https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf.
- **Pasaje breve relacionado:** S05; **ubicación:** KDIGO 2024 ERC, Practice Point 2.2.1, página S156.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CGACAT; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0314: eGFR cambia >20% (Riñón)

- **SI:** En ERC establecida eGFR varía >20% entre pruebas comparables
- **ENTONCES:** Revisión clínica nefrológica o general según cronicidad; comprobar analítica y tendencia.
- **Variables:** erc_previa;egfr_historial; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** KDIGO24 — https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf.
- **Pasaje breve relacionado:** S05; **ubicación:** KDIGO 2024 ERC, Practice Point 2.2.1, página S156.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PORCENTAJE_CAMBIO; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0315: ACR se duplica (Riñón)

- **SI:** En ERC ACR urinario ≥2× valor anterior comparable
- **ENTONCES:** Revisión clínica nefrológica o general según cronicidad; comprobar analítica y tendencia.
- **Variables:** erc_previa;acr_historial; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** KDIGO24 — https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf.
- **Pasaje breve relacionado:** S05; **ubicación:** KDIGO 2024 ERC, Practice Point 2.2.1, página S156.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** COCIENTE; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0316: Descenso post fármaco >30% (Riñón)

- **SI:** Terapia hemodinámicamente activa iniciada y eGFR disminuye>30%
- **ENTONCES:** Revisión clínica nefrológica o general según cronicidad; comprobar analítica y tendencia.
- **Variables:** egfr_historial;medicacion_renal_fecha; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** KDIGO24 — https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf.
- **Pasaje breve relacionado:** S05; **ubicación:** KDIGO 2024 ERC, Practice Point 2.2.1, página S156.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PORCENTAJE_CAMBIO; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0317: AKI por 0.3 mg/dL (Riñón)

- **SI:** Creatinina sérica aumenta≥0.3 mg/dL dentro de 48h
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** creatinina_historial; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_AKI — https://www.nice.org.uk/guidance/ng148/chapter/Recommendations.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** DELTA_MG_DL; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0318: AKI por 1.5× creatinina (Riñón)

- **SI:** Creatinina sérica≥1.5× basal en ≤7d
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** creatinina_historial; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_AKI — https://www.nice.org.uk/guidance/ng148/chapter/Recommendations.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** COCIENTE; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0319: AKI estadio2 por creatinina (Riñón)

- **SI:** Creatinina 2.0–2.9× basal dentro de 7 días
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** creatinina_historial; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_AKI — https://www.nice.org.uk/guidance/ng148/chapter/Recommendations.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** COCIENTE; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0320: AKI estadio3 por creatinina (Riñón)

- **SI:** Creatinina≥3× basal o ≥4 mg/dL con incremento agudo según criterios
- **ENTONCES:** Solicitar evaluación médica inmediata; no administrar tratamientos automáticamente.
- **Variables:** creatinina_historial; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CRITICA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_AKI — https://www.nice.org.uk/guidance/ng148/chapter/Recommendations.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** COCIENTE; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0321: Oliguria AKI por diuresis (Riñón)

- **SI:** Volumen urinario<0.5 mL/kg/h durante>6h, dato opcional
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** diuresis_horas;peso_kg; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_AKI — https://www.nice.org.uk/guidance/ng148/chapter/Recommendations.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** ML_KG_H; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0322: KFRE 2y calculable (Riñón)

- **SI:** ERC G3–G5 confirmada + edad/sexo/eGFR/ACR completos, modelo regional explícito
- **ENTONCES:** Revisión clínica nefrológica o general según cronicidad; comprobar analítica y tendencia.
- **Variables:** edad;sexo_modelo;egfr;acr_orina;erc_previa; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** KFRE_TANGRI16 — https://jamanetwork.com/journals/jama/fullarticle/2481005.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5 | comparar salida del modelo con calculadora original y calibración local; no porcentaje arbitrario.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PROBABILIDAD_2_ANOS; horizonte: 2 años; porcentaje calibrado: true.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0323: KFRE 5y calculable (Riñón)

- **SI:** ERC G3–G5 confirmada + edad/sexo/eGFR/ACR completos, modelo regional explícito
- **ENTONCES:** Revisión clínica nefrológica o general según cronicidad; comprobar analítica y tendencia.
- **Variables:** edad;sexo_modelo;egfr;acr_orina;erc_previa; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** KFRE_TANGRI16 — https://jamanetwork.com/journals/jama/fullarticle/2481005.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5 | comparar salida del modelo con calculadora original y calibración local; no porcentaje arbitrario.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PROBABILIDAD_5_ANOS; horizonte: 5 años; porcentaje calibrado: true.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0324: KFRE 5y ≥3% (Riñón)

- **SI:** KFRE 5 años≥3%: valorar derivación a nefrología según criterios KDIGO
- **ENTONCES:** Revisión clínica nefrológica o general según cronicidad; comprobar analítica y tendencia.
- **Variables:** kfre_5y; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** KDIGO24 — https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf.
- **Pasaje breve relacionado:** S05; **ubicación:** KDIGO 2024 ERC, Practice Point 2.2.1, página S156.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5 | comparar salida del modelo con calculadora original y calibración local; no porcentaje arbitrario.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PROBABILIDAD_5_ANOS; horizonte: 5 años; porcentaje calibrado: true.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0325: KFRE 5y ≥5% (Riñón)

- **SI:** KFRE 5 años≥5%: reforzar consideración de derivación
- **ENTONCES:** Revisión clínica nefrológica o general según cronicidad; comprobar analítica y tendencia.
- **Variables:** kfre_5y; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** KDIGO24 — https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf.
- **Pasaje breve relacionado:** S05; **ubicación:** KDIGO 2024 ERC, Practice Point 2.2.1, página S156.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5 | comparar salida del modelo con calculadora original y calibración local; no porcentaje arbitrario.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PROBABILIDAD_5_ANOS; horizonte: 5 años; porcentaje calibrado: true.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0326: KFRE 2y >10% (Riñón)

- **SI:** KFRE 2 años>10%: considerar equipo multidisciplinario
- **ENTONCES:** Revisión clínica nefrológica o general según cronicidad; comprobar analítica y tendencia.
- **Variables:** kfre_2y; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** KDIGO24 — https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf.
- **Pasaje breve relacionado:** S05; **ubicación:** KDIGO 2024 ERC, Practice Point 2.2.1, página S156.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5 | comparar salida del modelo con calculadora original y calibración local; no porcentaje arbitrario.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PROBABILIDAD_2_ANOS; horizonte: 2 años; porcentaje calibrado: true.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0327: KFRE 2y >40% (Riñón)

- **SI:** KFRE 2 años>40%: planificar preparación terapia sustitutiva renal
- **ENTONCES:** Revisión clínica nefrológica o general según cronicidad; comprobar analítica y tendencia.
- **Variables:** kfre_2y; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** KDIGO24 — https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf.
- **Pasaje breve relacionado:** S05; **ubicación:** KDIGO 2024 ERC, Practice Point 2.2.1, página S156.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5 | comparar salida del modelo con calculadora original y calibración local; no porcentaje arbitrario.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PROBABILIDAD_2_ANOS; horizonte: 2 años; porcentaje calibrado: true.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0328: KFRE inaplicable sin ERC G3–G5 (Riñón)

- **SI:** eGFR≥60 o ERC G3–5 no confirmada: no usar KFRE estándar
- **ENTONCES:** Revisión clínica nefrológica o general según cronicidad; comprobar analítica y tendencia.
- **Variables:** egfr;erc_previa; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** KDIGO24 — https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf.
- **Pasaje breve relacionado:** S05; **ubicación:** KDIGO 2024 ERC, Practice Point 2.2.1, página S156.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0329: Creatinina elevada descontextualizada (Riñón)

- **SI:** Creatinina fuera rango local sin tendencia: no concluir ERC
- **ENTONCES:** Revisión clínica nefrológica o general según cronicidad; comprobar analítica y tendencia.
- **Variables:** creatinina;edad;sexo_modelo; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NIDDK_EGFR — https://www.niddk.nih.gov/research-funding/research-programs/kidney-clinical-research-epidemiology/laboratory/glomerular-filtration-rate-equations/adults.
- **Pasaje breve relacionado:** S13; **ubicación:** NIDDK, eGFR Equations for Adults / 2021 CKD-EPI.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5 | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MG_DL; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0330: CKD-EPI 2021 requiere sexo fórmula (Riñón)

- **SI:** Edad≥18, creatinina estandarizada y coeficiente sexo adecuado
- **ENTONCES:** Revisión clínica nefrológica o general según cronicidad; comprobar analítica y tendencia.
- **Variables:** edad;creatinina;sexo_modelo; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NIDDK_EGFR — https://www.niddk.nih.gov/research-funding/research-programs/kidney-clinical-research-epidemiology/laboratory/glomerular-filtration-rate-equations/adults.
- **Pasaje breve relacionado:** S13; **ubicación:** NIDDK, eGFR Equations for Adults / 2021 CKD-EPI.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** ML_MIN_173; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0331: Bicarbonato bajo en ERC (Riñón)

- **SI:** ERC conocida + bicarbonato plasmático<18 mmol/L
- **ENTONCES:** Revisión clínica nefrológica o general según cronicidad; comprobar analítica y tendencia.
- **Variables:** erc_previa;bicarbonato; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** KDIGO24 — https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf.
- **Pasaje breve relacionado:** S05; **ubicación:** KDIGO 2024 ERC, Practice Point 2.2.1, página S156.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MMOL_L; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0332: ERC más hiperpotasemia moderada (Riñón)

- **SI:** ERC + K 6.0–6.4 mmol/L confirmado no hemolizado
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** erc_previa;potasio; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** UKKA_K26 — https://guidelines.ukkidney.org/hyperkalaemia/.
- **Pasaje breve relacionado:** S07; **ubicación:** UK Kidney Association 2026, Introduction / Hyperkalaemia severity.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MMOL_L; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0333: ERC más hiperpotasemia grave (Riñón)

- **SI:** ERC + K≥6.5 mmol/L confirmado no hemolizado
- **ENTONCES:** Solicitar evaluación médica inmediata; no administrar tratamientos automáticamente.
- **Variables:** erc_previa;potasio; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CRITICA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** UKKA_K26 — https://guidelines.ukkidney.org/hyperkalaemia/.
- **Pasaje breve relacionado:** S07; **ubicación:** UK Kidney Association 2026, Introduction / Hyperkalaemia severity.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MMOL_L; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0334: Diabetes más albuminuria (Riñón)

- **SI:** Diabetes establecida y ACR≥30 mg/g persistente
- **ENTONCES:** Revisión clínica nefrológica o general según cronicidad; comprobar analítica y tendencia.
- **Variables:** diabetes_previa;acr_historial; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** KDIGO24 — https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf.
- **Pasaje breve relacionado:** S05; **ubicación:** KDIGO 2024 ERC, Practice Point 2.2.1, página S156.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MG_G; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0335: HTA más albuminuria (Riñón)

- **SI:** HTA establecida y ACR≥30 mg/g persistente
- **ENTONCES:** Revisión clínica nefrológica o general según cronicidad; comprobar analítica y tendencia.
- **Variables:** hipertension_confirmada;acr_historial; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** KDIGO24 — https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf.
- **Pasaje breve relacionado:** S05; **ubicación:** KDIGO 2024 ERC, Practice Point 2.2.1, página S156.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5 | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MG_G; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0336: Control renal por ERC sin analíticas (Riñón)

- **SI:** Antecedente ERC y sin eGFR/ACR en≥12 meses: recomendar pruebas
- **ENTONCES:** Revisión clínica nefrológica o general según cronicidad; comprobar analítica y tendencia.
- **Variables:** erc_previa;fecha_egfr;fecha_acr; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CRIBADO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** KDIGO24 — https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf.
- **Pasaje breve relacionado:** S05; **ubicación:** KDIGO 2024 ERC, Practice Point 2.2.1, página S156.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** repetir valores para establecer ERC persistente; riesgo KFRE sólo G3-G5.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MESES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0337: FIB-4 bajo riesgo adulto 35–64 (Hígado)

- **SI:** Edad35–64, FIB-4<1.3 en contexto MASLD aplicable
- **ENTONCES:** Revisión clínica de riesgo hepatometabólico y, si corresponde, elastografía u otra prueba.
- **Variables:** edad;ast;alt;plaquetas; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AASLD_FIB4 — https://pmc.ncbi.nlm.nih.gov/articles/PMC10735173/.
- **Pasaje breve relacionado:** S15; **ubicación:** AASLD Practice Guidance 2023 (update MASLD 2024), Figure 2.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** FIB-4 no es porcentaje; no durante enfermedad aguda; ajustar por edad.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PUNTUACION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0338: FIB-4 indeterminado adulto 35–64 (Hígado)

- **SI:** Edad35–64, 1.3≤FIB-4≤2.67 en contexto MASLD
- **ENTONCES:** Revisión clínica de riesgo hepatometabólico y, si corresponde, elastografía u otra prueba.
- **Variables:** edad;ast;alt;plaquetas; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AASLD_FIB4 — https://pmc.ncbi.nlm.nih.gov/articles/PMC10735173/.
- **Pasaje breve relacionado:** S15; **ubicación:** AASLD Practice Guidance 2023 (update MASLD 2024), Figure 2.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** FIB-4 no es porcentaje; no durante enfermedad aguda; ajustar por edad.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PUNTUACION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0339: FIB-4 alto adulto 35–64 (Hígado)

- **SI:** Edad35–64, FIB-4>2.67 en contexto MASLD
- **ENTONCES:** Revisión clínica de riesgo hepatometabólico y, si corresponde, elastografía u otra prueba.
- **Variables:** edad;ast;alt;plaquetas; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AASLD_FIB4 — https://pmc.ncbi.nlm.nih.gov/articles/PMC10735173/.
- **Pasaje breve relacionado:** S15; **ubicación:** AASLD Practice Guidance 2023 (update MASLD 2024), Figure 2.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** FIB-4 no es porcentaje; no durante enfermedad aguda; ajustar por edad.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PUNTUACION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0340: FIB-4 edad≥65 bajo 2.0 (Hígado)

- **SI:** Edad≥65, FIB-4<2.0: límite ajustado baja probabilidad
- **ENTONCES:** Revisión clínica de riesgo hepatometabólico y, si corresponde, elastografía u otra prueba.
- **Variables:** edad;ast;alt;plaquetas; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AASLD_FIB4 — https://pmc.ncbi.nlm.nih.gov/articles/PMC10735173/.
- **Pasaje breve relacionado:** S15; **ubicación:** AASLD Practice Guidance 2023 (update MASLD 2024), Figure 2.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** FIB-4 no es porcentaje; no durante enfermedad aguda; ajustar por edad.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PUNTUACION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0341: FIB-4 edad≥65 supera 2.0 (Hígado)

- **SI:** Edad≥65, FIB-4≥2.0, considerar pruebas secundarias
- **ENTONCES:** Revisión clínica de riesgo hepatometabólico y, si corresponde, elastografía u otra prueba.
- **Variables:** edad;ast;alt;plaquetas; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AASLD_FIB4 — https://pmc.ncbi.nlm.nih.gov/articles/PMC10735173/.
- **Pasaje breve relacionado:** S15; **ubicación:** AASLD Practice Guidance 2023 (update MASLD 2024), Figure 2.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** FIB-4 no es porcentaje; no durante enfermedad aguda; ajustar por edad.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PUNTUACION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0342: FIB-4 no aplicable en <35 (Hígado)

- **SI:** Edad<35: FIB-4 no es confiable para estratificación habitual
- **ENTONCES:** Revisión clínica de riesgo hepatometabólico y, si corresponde, elastografía u otra prueba.
- **Variables:** edad;ast;alt;plaquetas; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AASLD_FIB4 — https://pmc.ncbi.nlm.nih.gov/articles/PMC10735173/.
- **Pasaje breve relacionado:** S15; **ubicación:** AASLD Practice Guidance 2023 (update MASLD 2024), Figure 2.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** FIB-4 no es porcentaje; no durante enfermedad aguda; ajustar por edad.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0343: FIB-4 en agudización no válido (Hígado)

- **SI:** Enfermedad aguda con AST/ALT alteradas, diferir cálculo MASLD
- **ENTONCES:** Revisión clínica de riesgo hepatometabólico y, si corresponde, elastografía u otra prueba.
- **Variables:** ast;alt;enfermedad_aguda; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AASLD_FIB4 — https://pmc.ncbi.nlm.nih.gov/articles/PMC10735173/.
- **Pasaje breve relacionado:** S15; **ubicación:** AASLD Practice Guidance 2023 (update MASLD 2024), Figure 2.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** FIB-4 no es porcentaje; no durante enfermedad aguda; ajustar por edad.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0344: MASLD riesgo metabólico sin laboratorio (Hígado)

- **SI:** Obesidad+diabetes; recomendar valoración hepática sin inferir fibrosis
- **ENTONCES:** Revisión clínica de riesgo hepatometabólico y, si corresponde, elastografía u otra prueba.
- **Variables:** imc;diabetes_previa; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CRIBADO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AASLD_FIB4 — https://pmc.ncbi.nlm.nih.gov/articles/PMC10735173/.
- **Pasaje breve relacionado:** S15; **ubicación:** AASLD Practice Guidance 2023 (update MASLD 2024), Figure 2.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** FIB-4 no es porcentaje; no durante enfermedad aguda; ajustar por edad | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0345: AST/ALT >2x límite local (Hígado)

- **SI:** AST o ALT >2× límite superior de referencia ajustado al laboratorio
- **ENTONCES:** Revisión clínica de riesgo hepatometabólico y, si corresponde, elastografía u otra prueba.
- **Variables:** ast;alt;limites_lab; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AASLD_FIB4 — https://pmc.ncbi.nlm.nih.gov/articles/PMC10735173/.
- **Pasaje breve relacionado:** S15; **ubicación:** AASLD Practice Guidance 2023 (update MASLD 2024), Figure 2.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** FIB-4 no es porcentaje; no durante enfermedad aguda; ajustar por edad | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** RELACION_ULN; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0346: AST/ALT >5x límite local (Hígado)

- **SI:** AST o ALT >5× límite superior de referencia local
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** ast;alt;limites_lab; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AASLD_FIB4 — https://pmc.ncbi.nlm.nih.gov/articles/PMC10735173/.
- **Pasaje breve relacionado:** S15; **ubicación:** AASLD Practice Guidance 2023 (update MASLD 2024), Figure 2.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** FIB-4 no es porcentaje; no durante enfermedad aguda; ajustar por edad | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** RELACION_ULN; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0347: AST/ALT >10x límite local (Hígado)

- **SI:** AST o ALT >10× límite superior de referencia; pronta valoración etiológica
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** ast;alt;limites_lab; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AASLD_FIB4 — https://pmc.ncbi.nlm.nih.gov/articles/PMC10735173/.
- **Pasaje breve relacionado:** S15; **ubicación:** AASLD Practice Guidance 2023 (update MASLD 2024), Figure 2.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** FIB-4 no es porcentaje; no durante enfermedad aguda; ajustar por edad | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** RELACION_ULN; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0348: Bilirrubina elevada y enzimas (Hígado)

- **SI:** Bilirrubina total elevada y ALT/AST fuera de referencia; no establecer etiología
- **ENTONCES:** Revisión clínica de riesgo hepatometabólico y, si corresponde, elastografía u otra prueba.
- **Variables:** bilirrubina;ast;alt;limites_lab; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AASLD_FIB4 — https://pmc.ncbi.nlm.nih.gov/articles/PMC10735173/.
- **Pasaje breve relacionado:** S15; **ubicación:** AASLD Practice Guidance 2023 (update MASLD 2024), Figure 2.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** FIB-4 no es porcentaje; no durante enfermedad aguda; ajustar por edad | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0349: Albúmina baja más INR alto (Hígado)

- **SI:** Albúmina baja y INR elevado en paciente con hepatopatía conocida
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** albumina;inr;hepatopatia_previa; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AASLD_FIB4 — https://pmc.ncbi.nlm.nih.gov/articles/PMC10735173/.
- **Pasaje breve relacionado:** S15; **ubicación:** AASLD Practice Guidance 2023 (update MASLD 2024), Figure 2.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** FIB-4 no es porcentaje; no durante enfermedad aguda; ajustar por edad | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0350: Plaquetopenia más FIB-4 alto (Hígado)

- **SI:** Plaquetas<150×10⁹/L + FIB-4>2.67 en persona elegible
- **ENTONCES:** Revisión clínica de riesgo hepatometabólico y, si corresponde, elastografía u otra prueba.
- **Variables:** plaquetas;fib4; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AASLD_FIB4 — https://pmc.ncbi.nlm.nih.gov/articles/PMC10735173/.
- **Pasaje breve relacionado:** S15; **ubicación:** AASLD Practice Guidance 2023 (update MASLD 2024), Figure 2.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** FIB-4 no es porcentaje; no durante enfermedad aguda; ajustar por edad | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0351: Hepatopatía crónica sin vigilancia (Hígado)

- **SI:** Hepatopatía conocida y sin analítica hepática reciente
- **ENTONCES:** Revisión clínica de riesgo hepatometabólico y, si corresponde, elastografía u otra prueba.
- **Variables:** hepatopatia_previa;fecha_funcion_hepatica; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CRIBADO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AASLD_FIB4 — https://pmc.ncbi.nlm.nih.gov/articles/PMC10735173/.
- **Pasaje breve relacionado:** S15; **ubicación:** AASLD Practice Guidance 2023 (update MASLD 2024), Figure 2.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** FIB-4 no es porcentaje; no durante enfermedad aguda; ajustar por edad | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MESES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0352: Obesidad con ALT persistente (Hígado)

- **SI:** IMC≥30 + ALT sobre referencia en dos pruebas separadas≥3 meses
- **ENTONCES:** Revisión clínica de riesgo hepatometabólico y, si corresponde, elastografía u otra prueba.
- **Variables:** imc;alt_historial; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AASLD_FIB4 — https://pmc.ncbi.nlm.nih.gov/articles/PMC10735173/.
- **Pasaje breve relacionado:** S15; **ubicación:** AASLD Practice Guidance 2023 (update MASLD 2024), Figure 2.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** FIB-4 no es porcentaje; no durante enfermedad aguda; ajustar por edad | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0353: Diabetes + FIB4≥1.3 (Hígado)

- **SI:** Diabetes establecida y FIB4≥1.3 edad35–64: priorizar elastografía
- **ENTONCES:** Revisión clínica de riesgo hepatometabólico y, si corresponde, elastografía u otra prueba.
- **Variables:** diabetes_previa;fib4;edad; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AASLD_FIB4 — https://pmc.ncbi.nlm.nih.gov/articles/PMC10735173/.
- **Pasaje breve relacionado:** S15; **ubicación:** AASLD Practice Guidance 2023 (update MASLD 2024), Figure 2.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** FIB-4 no es porcentaje; no durante enfermedad aguda; ajustar por edad.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PUNTUACION; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0354: Diabetes + FIB4 baja repetir (Hígado)

- **SI:** Diabetes establecida y FIB4 baja: reevaluar cada 1–2 años si riesgo lo justifica
- **ENTONCES:** Revisión clínica de riesgo hepatometabólico y, si corresponde, elastografía u otra prueba.
- **Variables:** diabetes_previa;fib4;fecha_fib4; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AASLD_FIB4 — https://pmc.ncbi.nlm.nih.gov/articles/PMC10735173/.
- **Pasaje breve relacionado:** S15; **ubicación:** AASLD Practice Guidance 2023 (update MASLD 2024), Figure 2.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** FIB-4 no es porcentaje; no durante enfermedad aguda; ajustar por edad.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MESES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0355: Divergencia plaquetas y AST (Hígado)

- **SI:** FIB4 cambia≥50% en 12 meses por cambio AST/ALT/plaquetas; revisar causas
- **ENTONCES:** Revisión clínica de riesgo hepatometabólico y, si corresponde, elastografía u otra prueba.
- **Variables:** fib4_historial; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AASLD_FIB4 — https://pmc.ncbi.nlm.nih.gov/articles/PMC10735173/.
- **Pasaje breve relacionado:** S15; **ubicación:** AASLD Practice Guidance 2023 (update MASLD 2024), Figure 2.
- **Clasificación original:** EXPERIMENTAL_NO_VALIDADA; **revisión v04:** SOLO_INVESTIGACION_DESACTIVADA.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** FIB-4 no es porcentaje; no durante enfermedad aguda; ajustar por edad | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PORCENTAJE_CAMBIO; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0356: FIB4 no diagnóstico cirrosis (Hígado)

- **SI:** FIB4 elevado sin elastografía/biopsia no permite rotular cirrosis
- **ENTONCES:** Revisión clínica de riesgo hepatometabólico y, si corresponde, elastografía u otra prueba.
- **Variables:** fib4; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AASLD_FIB4 — https://pmc.ncbi.nlm.nih.gov/articles/PMC10735173/.
- **Pasaje breve relacionado:** S15; **ubicación:** AASLD Practice Guidance 2023 (update MASLD 2024), Figure 2.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** FIB-4 no es porcentaje; no durante enfermedad aguda; ajustar por edad.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0357: Anemia OMS mujer no embarazada (Hematología)

- **SI:** Mujer adulta no embarazada con Hb<12.0 g/dL
- **ENTONCES:** Evaluar hemograma repetido y etiología clínica; interpretar según embarazo y edad.
- **Variables:** hb;sexo_modelo;embarazo_estado; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** WHO_HB24 — https://www.ncbi.nlm.nih.gov/books/NBK602183/table/fm-ch1.tab2/.
- **Pasaje breve relacionado:** S08; **ubicación:** OMS 2024, Table 3: Haemoglobin cutoffs / anaemia severity.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** G_DL; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0358: Anemia OMS varón (Hematología)

- **SI:** Varón adulto con Hb<13.0 g/dL
- **ENTONCES:** Evaluar hemograma repetido y etiología clínica; interpretar según embarazo y edad.
- **Variables:** hb;sexo_modelo; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** WHO_HB24 — https://www.ncbi.nlm.nih.gov/books/NBK602183/table/fm-ch1.tab2/.
- **Pasaje breve relacionado:** S08; **ubicación:** OMS 2024, Table 3: Haemoglobin cutoffs / anaemia severity.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** G_DL; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0359: Anemia leve mujer OMS (Hematología)

- **SI:** Mujer 15-65 no gestante Hb 11.0–11.9 g/dL
- **ENTONCES:** Evaluar hemograma repetido y etiología clínica; interpretar según embarazo y edad.
- **Variables:** hb;sexo_modelo;edad;embarazo_estado; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** WHO_HB24 — https://www.ncbi.nlm.nih.gov/books/NBK602183/table/fm-ch1.tab2/.
- **Pasaje breve relacionado:** S08; **ubicación:** OMS 2024, Table 3: Haemoglobin cutoffs / anaemia severity.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** G_DL; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0360: Anemia leve varón OMS (Hematología)

- **SI:** Varón 15-65 Hb 11.0–12.9 g/dL
- **ENTONCES:** Evaluar hemograma repetido y etiología clínica; interpretar según embarazo y edad.
- **Variables:** hb;sexo_modelo;edad; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** WHO_HB24 — https://www.ncbi.nlm.nih.gov/books/NBK602183/table/fm-ch1.tab2/.
- **Pasaje breve relacionado:** S08; **ubicación:** OMS 2024, Table 3: Haemoglobin cutoffs / anaemia severity.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** G_DL; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0361: Anemia moderada OMS adultos (Hematología)

- **SI:** Hb 8.0–10.9 g/dL en 15–65 años no gestante
- **ENTONCES:** Evaluar hemograma repetido y etiología clínica; interpretar según embarazo y edad.
- **Variables:** hb;edad;embarazo_estado; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** WHO_HB24 — https://www.ncbi.nlm.nih.gov/books/NBK602183/table/fm-ch1.tab2/.
- **Pasaje breve relacionado:** S08; **ubicación:** OMS 2024, Table 3: Haemoglobin cutoffs / anaemia severity.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** G_DL; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0362: Anemia grave OMS adultos (Hematología)

- **SI:** Hb<8.0 g/dL en 15–65 años no gestante; valorar urgencia clínica
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** hb;edad;embarazo_estado; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** WHO_HB24 — https://www.ncbi.nlm.nih.gov/books/NBK602183/table/fm-ch1.tab2/.
- **Pasaje breve relacionado:** S08; **ubicación:** OMS 2024, Table 3: Haemoglobin cutoffs / anaemia severity.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** G_DL; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0363: Anemia embarazo 1T (Hematología)

- **SI:** Gestante primer trimestre Hb<11.0 g/dL
- **ENTONCES:** Evaluar hemograma repetido y etiología clínica; interpretar según embarazo y edad.
- **Variables:** hb;embarazo_estado;trimestre; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** WHO_HB24 — https://www.ncbi.nlm.nih.gov/books/NBK602183/table/fm-ch1.tab2/.
- **Pasaje breve relacionado:** S08; **ubicación:** OMS 2024, Table 3: Haemoglobin cutoffs / anaemia severity.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** G_DL; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0364: Anemia embarazo 2T (Hematología)

- **SI:** Gestante segundo trimestre Hb<10.5 g/dL
- **ENTONCES:** Evaluar hemograma repetido y etiología clínica; interpretar según embarazo y edad.
- **Variables:** hb;embarazo_estado;trimestre; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** WHO_HB24 — https://www.ncbi.nlm.nih.gov/books/NBK602183/table/fm-ch1.tab2/.
- **Pasaje breve relacionado:** S08; **ubicación:** OMS 2024, Table 3: Haemoglobin cutoffs / anaemia severity.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** G_DL; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0365: Anemia embarazo 3T (Hematología)

- **SI:** Gestante tercer trimestre Hb<11.0 g/dL
- **ENTONCES:** Evaluar hemograma repetido y etiología clínica; interpretar según embarazo y edad.
- **Variables:** hb;embarazo_estado;trimestre; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** WHO_HB24 — https://www.ncbi.nlm.nih.gov/books/NBK602183/table/fm-ch1.tab2/.
- **Pasaje breve relacionado:** S08; **ubicación:** OMS 2024, Table 3: Haemoglobin cutoffs / anaemia severity.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** G_DL; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0366: Ferritina menor de 45 con anemia (Hematología)

- **SI:** Hb bajo umbral OMS y ferritina<45 ng/mL
- **ENTONCES:** Evaluar hemograma repetido y etiología clínica; interpretar según embarazo y edad.
- **Variables:** hb;ferritina;sexo_modelo; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AGA_IRON20 — https://gastro.org/clinical-guidance/gastrointestinal-evaluation-of-iron-deficiency-anemia/.
- **Pasaje breve relacionado:** S18; **ubicación:** AGA 2020 Guideline, Recommendations point 1.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NG_ML; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0367: Ferritina <15 probable ferropenia (Hematología)

- **SI:** Ferritina<15 ng/mL, con o sin anemia; revisar inflamación
- **ENTONCES:** Evaluar hemograma repetido y etiología clínica; interpretar según embarazo y edad.
- **Variables:** ferritina; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AGA_IRON20 — https://gastro.org/clinical-guidance/gastrointestinal-evaluation-of-iron-deficiency-anemia/.
- **Pasaje breve relacionado:** S18; **ubicación:** AGA 2020 Guideline, Recommendations point 1.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NG_ML; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0368: Anemia y sangrado GI potencial (Hematología)

- **SI:** Varón/posmenopáusica con anemia ferropénica confirmada
- **ENTONCES:** Evaluar hemograma repetido y etiología clínica; interpretar según embarazo y edad.
- **Variables:** hb;ferritina;sexo_modelo;menopausia_estado; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AGA_IRON20 — https://gastro.org/clinical-guidance/gastrointestinal-evaluation-of-iron-deficiency-anemia/.
- **Pasaje breve relacionado:** S18; **ubicación:** AGA 2020 Guideline, Recommendations point 1.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0369: Anemia con MCV bajo (Hematología)

- **SI:** Hb baja + VCM<80 fL: microcitosis, investigar hierro/hemoglobinopatías
- **ENTONCES:** Evaluar hemograma repetido y etiología clínica; interpretar según embarazo y edad.
- **Variables:** hb;vcm; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AGA_IRON20 — https://gastro.org/clinical-guidance/gastrointestinal-evaluation-of-iron-deficiency-anemia/.
- **Pasaje breve relacionado:** S18; **ubicación:** AGA 2020 Guideline, Recommendations point 1.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** FL; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0370: Anemia con MCV alto (Hematología)

- **SI:** Hb baja + VCM>100 fL: macrocitosis, investigar B12/folato/causas
- **ENTONCES:** Evaluar hemograma repetido y etiología clínica; interpretar según embarazo y edad.
- **Variables:** hb;vcm; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_B12_24 — https://www.nice.org.uk/guidance/ng239/chapter/recommendations.
- **Pasaje breve relacionado:** S17; **ubicación:** NICE NG239, Table 1 total or active B12.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** FL; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0371: Macrocitosis con B12 baja (Hematología)

- **SI:** VCM>100 y B12 total<180 ng/L, según laboratorio
- **ENTONCES:** Evaluar hemograma repetido y etiología clínica; interpretar según embarazo y edad.
- **Variables:** vcm;b12_total; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_B12_24 — https://www.nice.org.uk/guidance/ng239/chapter/recommendations.
- **Pasaje breve relacionado:** S17; **ubicación:** NICE NG239, Table 1 total or active B12.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0372: B12 muy probablemente baja (Hematología)

- **SI:** B12 total<180 ng/L en laboratorio, sin interferencias relevantes
- **ENTONCES:** Evaluar hemograma repetido y etiología clínica; interpretar según embarazo y edad.
- **Variables:** b12_total; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_B12_24 — https://www.nice.org.uk/guidance/ng239/chapter/recommendations.
- **Pasaje breve relacionado:** S17; **ubicación:** NICE NG239, Table 1 total or active B12.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NG_L; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0373: B12 indeterminada (Hematología)

- **SI:** B12 total 180–350 ng/L: solicitar MMA si indicado
- **ENTONCES:** Evaluar hemograma repetido y etiología clínica; interpretar según embarazo y edad.
- **Variables:** b12_total; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_B12_24 — https://www.nice.org.uk/guidance/ng239/chapter/recommendations.
- **Pasaje breve relacionado:** S17; **ubicación:** NICE NG239, Table 1 total or active B12.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NG_L; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0374: B12 menos probable (Hematología)

- **SI:** B12 total>350 ng/L: deficiencia menos probable, no excluye todos casos
- **ENTONCES:** Evaluar hemograma repetido y etiología clínica; interpretar según embarazo y edad.
- **Variables:** b12_total; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_B12_24 — https://www.nice.org.uk/guidance/ng239/chapter/recommendations.
- **Pasaje breve relacionado:** S17; **ubicación:** NICE NG239, Table 1 total or active B12.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NG_L; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0375: Pancitopenia (Hematología)

- **SI:** Hb bajo, plaquetas bajas y neutrófilos bajos según límites laboratorio
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** hb;plaquetas;neutrofilos;limites_lab; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** WHO_HB24 — https://www.ncbi.nlm.nih.gov/books/NBK602183/table/fm-ch1.tab2/.
- **Pasaje breve relacionado:** S08; **ubicación:** OMS 2024, Table 3: Haemoglobin cutoffs / anaemia severity.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_SERIES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0376: Bicitopenia (Hematología)

- **SI:** Dos de tres series sanguíneas fuera de rango en hemograma confirmado
- **ENTONCES:** Evaluar hemograma repetido y etiología clínica; interpretar según embarazo y edad.
- **Variables:** hb;plaquetas;neutrofilos;limites_lab; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** WHO_HB24 — https://www.ncbi.nlm.nih.gov/books/NBK602183/table/fm-ch1.tab2/.
- **Pasaje breve relacionado:** S08; **ubicación:** OMS 2024, Table 3: Haemoglobin cutoffs / anaemia severity.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_SERIES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0377: Leucocitos elevados (Hematología)

- **SI:** Leucocitos>11×10⁹/L en adulto, verificar rango local/causa
- **ENTONCES:** Evaluar hemograma repetido y etiología clínica; interpretar según embarazo y edad.
- **Variables:** leucocitos; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** IDSA_FN — https://www.idsociety.org/practice-guideline/neutropenic-patients-with-cancer/.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** X10E9_L; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0378: Leucocitos bajos (Hematología)

- **SI:** Leucocitos<4×10⁹/L, verificar rango local/causa
- **ENTONCES:** Evaluar hemograma repetido y etiología clínica; interpretar según embarazo y edad.
- **Variables:** leucocitos; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** IDSA_FN — https://www.idsociety.org/practice-guideline/neutropenic-patients-with-cancer/.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** X10E9_L; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0379: Neutropenia (Hematología)

- **SI:** Recuento absoluto neutrófilos <1.5×10⁹/L
- **ENTONCES:** Evaluar hemograma repetido y etiología clínica; interpretar según embarazo y edad.
- **Variables:** neutrofilos; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** IDSA_FN — https://www.idsociety.org/practice-guideline/neutropenic-patients-with-cancer/.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** X10E9_L; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0380: Neutropenia grave (Hematología)

- **SI:** Recuento absoluto neutrófilos <0.5×10⁹/L
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** neutrofilos; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** IDSA_FN — https://www.idsociety.org/practice-guideline/neutropenic-patients-with-cancer/.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** X10E9_L; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0381: Fiebre neutropénica (Hematología)

- **SI:** T≥38.3 una vez o ≥38.0 sostenida1h + ANC<0.5 o se prevé caída
- **ENTONCES:** Solicitar evaluación médica inmediata; no administrar tratamientos automáticamente.
- **Variables:** temperatura_clinica;neutrofilos; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CRITICA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** IDSA_FN — https://www.idsociety.org/practice-guideline/neutropenic-patients-with-cancer/.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0382: Trombocitopenia (Hematología)

- **SI:** Plaquetas <150×10⁹/L confirmadas; investigar etiología
- **ENTONCES:** Evaluar hemograma repetido y etiología clínica; interpretar según embarazo y edad.
- **Variables:** plaquetas; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AABB_PLT25 — https://pubmed.ncbi.nlm.nih.gov/40440268/.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** X10E9_L; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0383: Trombocitopenia severa (Hematología)

- **SI:** Plaquetas <50×10⁹/L confirmado; riesgo hemorragia depende de contexto
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** plaquetas; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AABB_PLT25 — https://pubmed.ncbi.nlm.nih.gov/40440268/.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** X10E9_L; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0384: Plaquetas muy bajas (Hematología)

- **SI:** Plaquetas <20×10⁹/L confirmadas: evaluación rápida
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** plaquetas; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AABB_PLT25 — https://pubmed.ncbi.nlm.nih.gov/40440268/.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** X10E9_L; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0385: Plaquetas críticas (Hematología)

- **SI:** Plaquetas <10×10⁹/L confirmadas: evaluación urgente
- **ENTONCES:** Solicitar evaluación médica inmediata; no administrar tratamientos automáticamente.
- **Variables:** plaquetas; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CRITICA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AABB_PLT25 — https://pubmed.ncbi.nlm.nih.gov/40440268/.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** X10E9_L; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0386: Plaquetas altas persistentes (Hematología)

- **SI:** Plaquetas>450×10⁹/L persistentes en dos hemogramas
- **ENTONCES:** Evaluar hemograma repetido y etiología clínica; interpretar según embarazo y edad.
- **Variables:** plaquetas_historial; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AABB_PLT25 — https://pubmed.ncbi.nlm.nih.gov/40440268/.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** X10E9_L; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0387: Hemoglobina cae rápidamente (Hematología)

- **SI:** Hb cae ≥2 g/dL en ≤7d y muestras comparables
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** hb_historial; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** WHO_HB24 — https://www.ncbi.nlm.nih.gov/books/NBK602183/table/fm-ch1.tab2/.
- **Pasaje breve relacionado:** S08; **ubicación:** OMS 2024, Table 3: Haemoglobin cutoffs / anaemia severity.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** DELTA_G_DL; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0388: Hb elevada por encima referencia (Hematología)

- **SI:** Hb > límite superior laboratorio ajustado por sexo/altura/estado
- **ENTONCES:** Evaluar hemograma repetido y etiología clínica; interpretar según embarazo y edad.
- **Variables:** hb;sexo_modelo;altitud_m;limites_lab; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** WHO_HB24 — https://www.ncbi.nlm.nih.gov/books/NBK602183/table/fm-ch1.tab2/.
- **Pasaje breve relacionado:** S08; **ubicación:** OMS 2024, Table 3: Haemoglobin cutoffs / anaemia severity.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** G_DL; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0389: Anemia con taquicardia (Hematología)

- **SI:** Hb por debajo criterio OMS y FC reposo>100 lpm
- **ENTONCES:** Evaluar hemograma repetido y etiología clínica; interpretar según embarazo y edad.
- **Variables:** hb;fc_reposo;sexo_modelo; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** WHO_HB24 — https://www.ncbi.nlm.nih.gov/books/NBK602183/table/fm-ch1.tab2/.
- **Pasaje breve relacionado:** S08; **ubicación:** OMS 2024, Table 3: Haemoglobin cutoffs / anaemia severity.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0390: Anemia con desaturación (Hematología)

- **SI:** Hb baja y SpO2 baja verificada: investigar factores independientes
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** hb;spo2_clinica; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** WHO_HB24 — https://www.ncbi.nlm.nih.gov/books/NBK602183/table/fm-ch1.tab2/.
- **Pasaje breve relacionado:** S08; **ubicación:** OMS 2024, Table 3: Haemoglobin cutoffs / anaemia severity.
- **Clasificación original:** EXPERIMENTAL_NO_VALIDADA; **revisión v04:** SOLO_INVESTIGACION_DESACTIVADA.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0391: B12 baja con neurosecuela (Hematología)

- **SI:** B12 total <180 ng/L con neuropatía registrada requiere evaluación pronta
- **ENTONCES:** Evaluar hemograma repetido y etiología clínica; interpretar según embarazo y edad.
- **Variables:** b12_total;neuropatia_previa; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_B12_24 — https://www.nice.org.uk/guidance/ng239/chapter/recommendations.
- **Pasaje breve relacionado:** S17; **ubicación:** NICE NG239, Table 1 total or active B12.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** Hb debe tener referencia de gestación/edad/altitud; la etiología no es inmediata.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0392: Hiperpotasemia leve (Electrolitos)

- **SI:** Potasio sérico 5.5–5.9 mmol/L no hemolizado
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** potasio;indice_hemolisis; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** UKKA_K26 — https://guidelines.ukkidney.org/hyperkalaemia/.
- **Pasaje breve relacionado:** S07; **ubicación:** UK Kidney Association 2026, Introduction / Hyperkalaemia severity.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** revisar hemólisis, recolección, laboratorio y contexto.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MMOL_L; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0393: Hiperpotasemia moderada (Electrolitos)

- **SI:** Potasio 6.0–6.4 mmol/L no hemolizado, evaluación pronta
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** potasio;indice_hemolisis; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** UKKA_K26 — https://guidelines.ukkidney.org/hyperkalaemia/.
- **Pasaje breve relacionado:** S07; **ubicación:** UK Kidney Association 2026, Introduction / Hyperkalaemia severity.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** revisar hemólisis, recolección, laboratorio y contexto.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MMOL_L; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0394: Hiperpotasemia grave (Electrolitos)

- **SI:** Potasio ≥6.5 mmol/L no hemolizado, valoración hospitalaria urgente
- **ENTONCES:** Solicitar evaluación médica inmediata; no administrar tratamientos automáticamente.
- **Variables:** potasio;indice_hemolisis; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CRITICA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** UKKA_K26 — https://guidelines.ukkidney.org/hyperkalaemia/.
- **Pasaje breve relacionado:** S07; **ubicación:** UK Kidney Association 2026, Introduction / Hyperkalaemia severity.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** revisar hemólisis, recolección, laboratorio y contexto.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MMOL_L; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0395: Potasiemia elevada y bradicardia (Electrolitos)

- **SI:** K≥6.0 no hemolizado + FC<50 nueva; ECG urgente
- **ENTONCES:** Solicitar evaluación médica inmediata; no administrar tratamientos automáticamente.
- **Variables:** potasio;fc_reposo; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CRITICA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** UKKA_K26 — https://guidelines.ukkidney.org/hyperkalaemia/.
- **Pasaje breve relacionado:** S07; **ubicación:** UK Kidney Association 2026, Introduction / Hyperkalaemia severity.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** revisar hemólisis, recolección, laboratorio y contexto | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0396: Potasiemia elevada con ERC (Electrolitos)

- **SI:** K≥5.5 y ERC conocida; ampliar evaluación y medicación
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** potasio;erc_previa; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** UKKA_K26 — https://guidelines.ukkidney.org/hyperkalaemia/.
- **Pasaje breve relacionado:** S07; **ubicación:** UK Kidney Association 2026, Introduction / Hyperkalaemia severity.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** revisar hemólisis, recolección, laboratorio y contexto.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0397: Potasio bajo (Electrolitos)

- **SI:** K<3.5 mmol/L no hemolizado; investigar causas
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** potasio; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** UKKA_K26 — https://guidelines.ukkidney.org/hyperkalaemia/.
- **Pasaje breve relacionado:** S07; **ubicación:** UK Kidney Association 2026, Introduction / Hyperkalaemia severity.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** revisar hemólisis, recolección, laboratorio y contexto | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MMOL_L; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0398: Hipopotasemia moderada (Electrolitos)

- **SI:** K 2.5–2.9 mmol/L confirmado; evaluación pronta
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** potasio; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** UKKA_K26 — https://guidelines.ukkidney.org/hyperkalaemia/.
- **Pasaje breve relacionado:** S07; **ubicación:** UK Kidney Association 2026, Introduction / Hyperkalaemia severity.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** revisar hemólisis, recolección, laboratorio y contexto | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MMOL_L; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0399: Hipopotasemia grave (Electrolitos)

- **SI:** K<2.5 mmol/L: evaluación urgente y ECG
- **ENTONCES:** Solicitar evaluación médica inmediata; no administrar tratamientos automáticamente.
- **Variables:** potasio; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CRITICA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** UKKA_K26 — https://guidelines.ukkidney.org/hyperkalaemia/.
- **Pasaje breve relacionado:** S07; **ubicación:** UK Kidney Association 2026, Introduction / Hyperkalaemia severity.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** revisar hemólisis, recolección, laboratorio y contexto | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MMOL_L; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0400: Hipopotasemia y taquicardia (Electrolitos)

- **SI:** K<3.0 y FC>100 reposo; verificar ritmo ECG
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** potasio;fc_reposo; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** UKKA_K26 — https://guidelines.ukkidney.org/hyperkalaemia/.
- **Pasaje breve relacionado:** S07; **ubicación:** UK Kidney Association 2026, Introduction / Hyperkalaemia severity.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** revisar hemólisis, recolección, laboratorio y contexto | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0401: Hiponatremia (Electrolitos)

- **SI:** Na sérico<135 mmol/L, repetir/causa y revisar tonicidad
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** sodio; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ENDO_NA — https://academic.oup.com/ejendo/article/170/3/G1/6668028.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** revisar hemólisis, recolección, laboratorio y contexto.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MMOL_L; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0402: Hiponatremia moderada (Electrolitos)

- **SI:** Na 125–129 mmol/L; revisión pronta según clínica
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** sodio; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ENDO_NA — https://academic.oup.com/ejendo/article/170/3/G1/6668028.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** revisar hemólisis, recolección, laboratorio y contexto.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MMOL_L; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0403: Hiponatremia profunda (Electrolitos)

- **SI:** Na<125 mmol/L confirmado; evaluación urgente especialmente si aguda
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** sodio; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ENDO_NA — https://academic.oup.com/ejendo/article/170/3/G1/6668028.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** revisar hemólisis, recolección, laboratorio y contexto.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MMOL_L; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0404: Hipernatremia (Electrolitos)

- **SI:** Na>145 mmol/L; evaluar balance hídrico y causa
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** sodio; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ENDO_NA — https://academic.oup.com/ejendo/article/170/3/G1/6668028.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** revisar hemólisis, recolección, laboratorio y contexto | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MMOL_L; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0405: Hipernatremia importante (Electrolitos)

- **SI:** Na≥160 mmol/L confirmado, evaluación urgente
- **ENTONCES:** Solicitar evaluación médica inmediata; no administrar tratamientos automáticamente.
- **Variables:** sodio; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CRITICA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ENDO_NA — https://academic.oup.com/ejendo/article/170/3/G1/6668028.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** revisar hemólisis, recolección, laboratorio y contexto | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MMOL_L; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0406: Na corregido por hiperglucemia (Electrolitos)

- **SI:** Na medido bajo + glucosa plasmática elevada; calcular Na corregido con método especificado
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** sodio;glucosa_plasmatica_azar; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ENDO_NA — https://academic.oup.com/ejendo/article/170/3/G1/6668028.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** revisar hemólisis, recolección, laboratorio y contexto | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MMOL_L; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0407: Calcio corregido no confiable (Electrolitos)

- **SI:** Albúmina baja y calcio total anormal; preferir calcio ionizado cuando proceda
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** calcio_total;albumina; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** KDIGO24 — https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf.
- **Pasaje breve relacionado:** S05; **ubicación:** KDIGO 2024 ERC, Practice Point 2.2.1, página S156.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** revisar hemólisis, recolección, laboratorio y contexto | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0408: Calcio ionizado bajo (Electrolitos)

- **SI:** Calcio ionizado debajo de referencia de laboratorio validada
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** calcio_ionizado;limites_lab; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** KDIGO24 — https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf.
- **Pasaje breve relacionado:** S05; **ubicación:** KDIGO 2024 ERC, Practice Point 2.2.1, página S156.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** revisar hemólisis, recolección, laboratorio y contexto | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MMOL_L; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0409: Calcio ionizado alto (Electrolitos)

- **SI:** Calcio ionizado sobre referencia del laboratorio validada
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** calcio_ionizado;limites_lab; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** KDIGO24 — https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf.
- **Pasaje breve relacionado:** S05; **ubicación:** KDIGO 2024 ERC, Practice Point 2.2.1, página S156.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** revisar hemólisis, recolección, laboratorio y contexto | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MMOL_L; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0410: Magnesio bajo (Electrolitos)

- **SI:** Mg por debajo del límite de referencia local, especialmente con K bajo
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** magnesio;limites_lab; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** KDIGO24 — https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf.
- **Pasaje breve relacionado:** S05; **ubicación:** KDIGO 2024 ERC, Practice Point 2.2.1, página S156.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** revisar hemólisis, recolección, laboratorio y contexto | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MMOL_L; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0411: Fósforo elevado/ERC (Electrolitos)

- **SI:** Fosfato sobre referencia y eGFR<60 persistente
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** fosfato;egfr_historial; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** KDIGO24 — https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf.
- **Pasaje breve relacionado:** S05; **ubicación:** KDIGO 2024 ERC, Practice Point 2.2.1, página S156.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** revisar hemólisis, recolección, laboratorio y contexto | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0412: Bicarbonato <18 en ERC (Electrolitos)

- **SI:** ERC y HCO3<18 mmol/L; valorar acidosis metabólica
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** erc_previa;bicarbonato; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** KDIGO24 — https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf.
- **Pasaje breve relacionado:** S05; **ubicación:** KDIGO 2024 ERC, Practice Point 2.2.1, página S156.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** revisar hemólisis, recolección, laboratorio y contexto.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MMOL_L; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0413: Albúmina plasmática baja (Electrolitos)

- **SI:** Albúmina sérica por debajo límite laboratorio; causa multifactorial
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** albumina;limites_lab; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** KDIGO24 — https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf.
- **Pasaje breve relacionado:** S05; **ubicación:** KDIGO 2024 ERC, Practice Point 2.2.1, página S156.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** revisar hemólisis, recolección, laboratorio y contexto | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** G_DL; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0414: Vitamina D deficiente según lab (Electrolitos)

- **SI:** 25-OH vitamina D por debajo referencia clínica seleccionada; no umbral universal
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** vitamina_d;limites_lab; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** KDIGO24 — https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf.
- **Pasaje breve relacionado:** S05; **ubicación:** KDIGO 2024 ERC, Practice Point 2.2.1, página S156.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** revisar hemólisis, recolección, laboratorio y contexto | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NG_ML; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0415: Potasio no evaluable por hemólisis (Electrolitos)

- **SI:** K alto + índice de hemólisis incompatible, solicitar repetición apropiada
- **ENTONCES:** Revisar anomalía con profesional y solicitar la prueba confirmatoria apropiada.
- **Variables:** potasio;indice_hemolisis; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** UKKA_K26 — https://guidelines.ukkidney.org/hyperkalaemia/.
- **Pasaje breve relacionado:** S07; **ubicación:** UK Kidney Association 2026, Introduction / Hyperkalaemia severity.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** revisar hemólisis, recolección, laboratorio y contexto.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0416: TSH alta FT4 baja (Tiroides)

- **SI:** TSH sobre referencia + FT4 por debajo del límite, patrón de hipotiroidismo primario
- **ENTONCES:** Repetir o completar perfil tiroideo según guía, ensayo y contexto.
- **Variables:** tsh;ft4;limites_lab; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_TSH — https://www.nice.org.uk/guidance/ng145/chapter/recommendations.
- **Pasaje breve relacionado:** S19; **ubicación:** NICE NG145, recommendation 1.2.8.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0417: TSH baja FT4 alta (Tiroides)

- **SI:** TSH baja + FT4 sobre rango; patrón tirotoxicosis
- **ENTONCES:** Repetir o completar perfil tiroideo según guía, ensayo y contexto.
- **Variables:** tsh;ft4;limites_lab; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_TSH — https://www.nice.org.uk/guidance/ng145/chapter/recommendations.
- **Pasaje breve relacionado:** S19; **ubicación:** NICE NG145, recommendation 1.2.8.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0418: TSH alta FT4 normal (Tiroides)

- **SI:** TSH alta + FT4 normal: patrón hipotiroidea subclínico
- **ENTONCES:** Repetir o completar perfil tiroideo según guía, ensayo y contexto.
- **Variables:** tsh;ft4;limites_lab; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_TSH — https://www.nice.org.uk/guidance/ng145/chapter/recommendations.
- **Pasaje breve relacionado:** S19; **ubicación:** NICE NG145, recommendation 1.2.8.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0419: TSH baja FT4 normal (Tiroides)

- **SI:** TSH baja + FT4 normal, valorar FT3
- **ENTONCES:** Repetir o completar perfil tiroideo según guía, ensayo y contexto.
- **Variables:** tsh;ft4;limites_lab; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_TSH — https://www.nice.org.uk/guidance/ng145/chapter/recommendations.
- **Pasaje breve relacionado:** S19; **ubicación:** NICE NG145, recommendation 1.2.8.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0420: TSH≥10 persistente (Tiroides)

- **SI:** TSH≥10 mUI/L en dos extracciones separadas≥3 meses, FT4 normal
- **ENTONCES:** Repetir o completar perfil tiroideo según guía, ensayo y contexto.
- **Variables:** tsh_historial;ft4; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_TSH — https://www.nice.org.uk/guidance/ng145/chapter/recommendations.
- **Pasaje breve relacionado:** S19; **ubicación:** NICE NG145, recommendation 1.2.8.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MUI_L; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0421: TSH suprimida persistente (Tiroides)

- **SI:** TSH<0.1 mUI/L en dos extracciones≥3 meses con contexto clínico
- **ENTONCES:** Repetir o completar perfil tiroideo según guía, ensayo y contexto.
- **Variables:** tsh_historial; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_TSH — https://www.nice.org.uk/guidance/ng145/chapter/recommendations.
- **Pasaje breve relacionado:** S19; **ubicación:** NICE NG145, recommendation 1.2.8.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MUI_L; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0422: Sospecha tiroides central (Tiroides)

- **SI:** FT4 bajo y TSH inapropiadamente normal/baja: valorar hipófisis
- **ENTONCES:** Repetir o completar perfil tiroideo según guía, ensayo y contexto.
- **Variables:** ft4;tsh;limites_lab; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_TSH — https://www.nice.org.uk/guidance/ng145/chapter/recommendations.
- **Pasaje breve relacionado:** S19; **ubicación:** NICE NG145, recommendation 1.2.8.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0423: TSH alterada con biotina (Tiroides)

- **SI:** Uso de biotina y TSH/FT4 discordantes: verificar interferencia
- **ENTONCES:** Repetir o completar perfil tiroideo según guía, ensayo y contexto.
- **Variables:** tsh;ft4;biotina_consumo; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_TSH — https://www.nice.org.uk/guidance/ng145/chapter/recommendations.
- **Pasaje breve relacionado:** S19; **ubicación:** NICE NG145, recommendation 1.2.8.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0424: TSH bajo y FC rápida (Tiroides)

- **SI:** TSH<0.1 + FC reposo≥100; ECG/FT4/FT3 si procede
- **ENTONCES:** Repetir o completar perfil tiroideo según guía, ensayo y contexto.
- **Variables:** tsh;fc_reposo; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_TSH — https://www.nice.org.uk/guidance/ng145/chapter/recommendations.
- **Pasaje breve relacionado:** S19; **ubicación:** NICE NG145, recommendation 1.2.8.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0425: TSH elevada y LDL alto (Tiroides)

- **SI:** TSH sobre rango + LDL elevado; considerar trastorno secundario
- **ENTONCES:** Repetir o completar perfil tiroideo según guía, ensayo y contexto.
- **Variables:** tsh;ldl; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_TSH — https://www.nice.org.uk/guidance/ng145/chapter/recommendations.
- **Pasaje breve relacionado:** S19; **ubicación:** NICE NG145, recommendation 1.2.8.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0426: Hipotiroidismo conocido sin control (Tiroides)

- **SI:** Antecedente hipotiroidismo y TSH sin control tras cambios de terapia
- **ENTONCES:** Repetir o completar perfil tiroideo según guía, ensayo y contexto.
- **Variables:** hipotiroidismo_previo;medicacion_tiroides;fecha_tsh; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CRIBADO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_TSH — https://www.nice.org.uk/guidance/ng145/chapter/recommendations.
- **Pasaje breve relacionado:** S19; **ubicación:** NICE NG145, recommendation 1.2.8.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MESES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0427: Hipertiroidismo conocido y FA (Tiroides)

- **SI:** Hipertiroidismo previo + ECG con FA confirmada
- **ENTONCES:** Repetir o completar perfil tiroideo según guía, ensayo y contexto.
- **Variables:** hipertiroidismo_previo;fa_confirmada; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ESC_AF — https://academic.oup.com/eurheartj/article/45/36/3314/7738779.
- **Pasaje breve relacionado:** S21; **ubicación:** ESC 2024 AF guideline, key message 10.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0428: SOP - disfunción ovulatoria e hiperandrogenismo (Reproductivo)

- **SI:** Adulto: irregularidad menstrual documentada + hiperandrogenismo clínico o bioquímico; excluir otras causas
- **ENTONCES:** Revisión ginecoendocrinológica; no usar fase ovulatoria aislada como diagnóstico.
- **Variables:** ciclo_historial;hiperandrogenismo; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** PCOS_GUIDE23 — https://academic.oup.com/jcem/article/108/10/2447/7242360.
- **Pasaje breve relacionado:** S20; **ubicación:** PCOS International Guideline 2023, diagnostic criteria.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** fase del ciclo observada/estimada ≠ prueba diagnóstica hormonal.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIOS_2_DE_3; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0429: SOP - disfunción ovulatoria y ovario poliquístico (Reproductivo)

- **SI:** Adulto: irregularidad menstrual + US/AMH válida de morfología poliquística
- **ENTONCES:** Revisión ginecoendocrinológica; no usar fase ovulatoria aislada como diagnóstico.
- **Variables:** ciclo_historial;eco_ovario_o_amh; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** PCOS_GUIDE23 — https://academic.oup.com/jcem/article/108/10/2447/7242360.
- **Pasaje breve relacionado:** S20; **ubicación:** PCOS International Guideline 2023, diagnostic criteria.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** fase del ciclo observada/estimada ≠ prueba diagnóstica hormonal.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIOS_2_DE_3; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0430: SOP - hiperandrogenismo y ovario poliquístico (Reproductivo)

- **SI:** Adulto: hiperandrogenismo + US/AMH apropiado; excluir otras causas
- **ENTONCES:** Revisión ginecoendocrinológica; no usar fase ovulatoria aislada como diagnóstico.
- **Variables:** hiperandrogenismo;eco_ovario_o_amh; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** PCOS_GUIDE23 — https://academic.oup.com/jcem/article/108/10/2447/7242360.
- **Pasaje breve relacionado:** S20; **ubicación:** PCOS International Guideline 2023, diagnostic criteria.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** fase del ciclo observada/estimada ≠ prueba diagnóstica hormonal.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CRITERIOS_2_DE_3; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0431: No diagnosticar SOP por LH/FSH (Reproductivo)

- **SI:** Relación LH/FSH alterada sola no diagnostica SOP
- **ENTONCES:** Revisión ginecoendocrinológica; no usar fase ovulatoria aislada como diagnóstico.
- **Variables:** lh;fsh; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** PCOS_GUIDE23 — https://academic.oup.com/jcem/article/108/10/2447/7242360.
- **Pasaje breve relacionado:** S20; **ubicación:** PCOS International Guideline 2023, diagnostic criteria.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** fase del ciclo observada/estimada ≠ prueba diagnóstica hormonal.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0432: SOP con prediabetes (Reproductivo)

- **SI:** SOP establecida + HbA1c 5.7–6.4%, recomendar cribado metabólico
- **ENTONCES:** Revisión ginecoendocrinológica; no usar fase ovulatoria aislada como diagnóstico.
- **Variables:** sop_previa;hba1c; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** PCOS_GUIDE23 — https://academic.oup.com/jcem/article/108/10/2447/7242360.
- **Pasaje breve relacionado:** S20; **ubicación:** PCOS International Guideline 2023, diagnostic criteria.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** fase del ciclo observada/estimada ≠ prueba diagnóstica hormonal | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0433: SOP con hipertensión (Reproductivo)

- **SI:** SOP conocida + PA≥130/80 confirmada, evaluar riesgo
- **ENTONCES:** Revisión ginecoendocrinológica; no usar fase ovulatoria aislada como diagnóstico.
- **Variables:** sop_previa;pa_validada; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** PCOS_GUIDE23 — https://academic.oup.com/jcem/article/108/10/2447/7242360.
- **Pasaje breve relacionado:** S20; **ubicación:** PCOS International Guideline 2023, diagnostic criteria.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** fase del ciclo observada/estimada ≠ prueba diagnóstica hormonal | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0434: Amenorrea prolongada probable anovulación (Reproductivo)

- **SI:** Intervalo entre menstruaciones>90 días documentado, sin embarazo y no perimenopausia
- **ENTONCES:** Revisión ginecoendocrinológica; no usar fase ovulatoria aislada como diagnóstico.
- **Variables:** ciclo_historial;embarazo_estado;edad; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** PCOS_GUIDE23 — https://academic.oup.com/jcem/article/108/10/2447/7242360.
- **Pasaje breve relacionado:** S20; **ubicación:** PCOS International Guideline 2023, diagnostic criteria.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** fase del ciclo observada/estimada ≠ prueba diagnóstica hormonal.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** DIAS; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0435: Ciclos irregulares post menarquia tardía (Reproductivo)

- **SI:** ≥3 años tras menarquia, ciclos<21 o>35 días o <8 ciclos/año
- **ENTONCES:** Revisión ginecoendocrinológica; no usar fase ovulatoria aislada como diagnóstico.
- **Variables:** edad_menarquia;ciclo_historial; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** PCOS_GUIDE23 — https://academic.oup.com/jcem/article/108/10/2447/7242360.
- **Pasaje breve relacionado:** S20; **ubicación:** PCOS International Guideline 2023, diagnostic criteria.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** fase del ciclo observada/estimada ≠ prueba diagnóstica hormonal.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** DIAS; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0436: Ciclo cercano al evento ovulatorio no medido (Reproductivo)

- **SI:** Fase ovulatoria calendario sin prueba LH/progesterona: no afirmar ovulación
- **ENTONCES:** Revisión ginecoendocrinológica; no usar fase ovulatoria aislada como diagnóstico.
- **Variables:** fase_ciclo;test_ovulacion; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** PCOS_GUIDE23 — https://academic.oup.com/jcem/article/108/10/2447/7242360.
- **Pasaje breve relacionado:** S20; **ubicación:** PCOS International Guideline 2023, diagnostic criteria.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** fase del ciclo observada/estimada ≠ prueba diagnóstica hormonal | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0437: Progesterona mal temporizada (Reproductivo)

- **SI:** Progesterona baja sin fecha relativa a ovulación, evitar inferir anovulación
- **ENTONCES:** Revisión ginecoendocrinológica; no usar fase ovulatoria aislada como diagnóstico.
- **Variables:** progesterona;fase_ciclo; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** PCOS_GUIDE23 — https://academic.oup.com/jcem/article/108/10/2447/7242360.
- **Pasaje breve relacionado:** S20; **ubicación:** PCOS International Guideline 2023, diagnostic criteria.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** fase del ciclo observada/estimada ≠ prueba diagnóstica hormonal | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0438: Hiperandrogenismo bioquímico (Reproductivo)

- **SI:** Testosterona libre/total >rango específico del ensayo y fase, valorar etiología
- **ENTONCES:** Revisión ginecoendocrinológica; no usar fase ovulatoria aislada como diagnóstico.
- **Variables:** testosterona;sexo_modelo;limites_lab; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** PCOS_GUIDE23 — https://academic.oup.com/jcem/article/108/10/2447/7242360.
- **Pasaje breve relacionado:** S20; **ubicación:** PCOS International Guideline 2023, diagnostic criteria.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** fase del ciclo observada/estimada ≠ prueba diagnóstica hormonal.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** RELACION_ULN; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0439: Amenorrea y TSH alterada (Reproductivo)

- **SI:** Amenorrea y TSH fuera rango: descartar causa tiroidea, embarazo
- **ENTONCES:** Revisión ginecoendocrinológica; no usar fase ovulatoria aislada como diagnóstico.
- **Variables:** ciclo_historial;tsh;embarazo_estado; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_TSH — https://www.nice.org.uk/guidance/ng145/chapter/recommendations.
- **Pasaje breve relacionado:** S19; **ubicación:** NICE NG145, recommendation 1.2.8.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** fase del ciclo observada/estimada ≠ prueba diagnóstica hormonal | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0440: Amenorrea y prolactina elevada (Reproductivo)

- **SI:** Amenorrea + prolactina sobre límite del método, excluir causas
- **ENTONCES:** Revisión ginecoendocrinológica; no usar fase ovulatoria aislada como diagnóstico.
- **Variables:** ciclo_historial;prolactina;limites_lab; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** PCOS_GUIDE23 — https://academic.oup.com/jcem/article/108/10/2447/7242360.
- **Pasaje breve relacionado:** S20; **ubicación:** PCOS International Guideline 2023, diagnostic criteria.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** fase del ciclo observada/estimada ≠ prueba diagnóstica hormonal | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0441: Hiperandrogenismo de rápida aparición (Reproductivo)

- **SI:** Andrógenos elevados marcadamente vs basal en semanas, investigar causas no SOP
- **ENTONCES:** Revisión ginecoendocrinológica; no usar fase ovulatoria aislada como diagnóstico.
- **Variables:** testosterona_historial;tiempo_inicio; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** PCOS_GUIDE23 — https://academic.oup.com/jcem/article/108/10/2447/7242360.
- **Pasaje breve relacionado:** S20; **ubicación:** PCOS International Guideline 2023, diagnostic criteria.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** fase del ciclo observada/estimada ≠ prueba diagnóstica hormonal | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PORCENTAJE_CAMBIO; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0442: Sangrado menstrual y anemia (Reproductivo)

- **SI:** Sangrado abundante documentado + Hb bajo umbral OMS
- **ENTONCES:** Revisión ginecoendocrinológica; no usar fase ovulatoria aislada como diagnóstico.
- **Variables:** sangrado_menstrual;hb; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** WHO_HB24 — https://www.ncbi.nlm.nih.gov/books/NBK602183/table/fm-ch1.tab2/.
- **Pasaje breve relacionado:** S08; **ubicación:** OMS 2024, Table 3: Haemoglobin cutoffs / anaemia severity.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** fase del ciclo observada/estimada ≠ prueba diagnóstica hormonal | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0443: Embarazo no establecido (Reproductivo)

- **SI:** Fase ovulatoria no permite concluir embarazo, solicitar prueba si relevante
- **ENTONCES:** Revisión ginecoendocrinológica; no usar fase ovulatoria aislada como diagnóstico.
- **Variables:** fase_ciclo;embarazo_estado; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACOG_PREE — https://www.acog.org/womens-health/faqs/preeclampsia-and-high-blood-pressure-during-pregnancy.
- **Pasaje breve relacionado:** S22; **ubicación:** ACC/AHA 2025, Table 21, hypertension pregnancy.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** fase del ciclo observada/estimada ≠ prueba diagnóstica hormonal.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0444: Hipertensión gestacional posible (Embarazo)

- **SI:** Gestación≥20 semanas, nueva PA≥140/90 confirmada según protocolo
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** embarazo_confirmado;semanas_gestacion;pa_validada; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACOG_PREE — https://www.acog.org/womens-health/faqs/preeclampsia-and-high-blood-pressure-during-pregnancy.
- **Pasaje breve relacionado:** S22; **ubicación:** ACC/AHA 2025, Table 21, hypertension pregnancy.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MMHG; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0445: Hipertensión gestacional grave PAS (Embarazo)

- **SI:** Gestación≥20 semanas + PAS≥160 confirmada brevemente
- **ENTONCES:** Solicitar evaluación médica inmediata; no administrar tratamientos automáticamente.
- **Variables:** embarazo_confirmado;semanas_gestacion;pas_validada; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CRITICA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACOG_PREE — https://www.acog.org/womens-health/faqs/preeclampsia-and-high-blood-pressure-during-pregnancy.
- **Pasaje breve relacionado:** S22; **ubicación:** ACC/AHA 2025, Table 21, hypertension pregnancy.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MMHG; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0446: Hipertensión gestacional grave PAD (Embarazo)

- **SI:** Gestación≥20 semanas + PAD≥110 confirmada brevemente
- **ENTONCES:** Solicitar evaluación médica inmediata; no administrar tratamientos automáticamente.
- **Variables:** embarazo_confirmado;semanas_gestacion;pad_validada; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CRITICA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACOG_PREE — https://www.acog.org/womens-health/faqs/preeclampsia-and-high-blood-pressure-during-pregnancy.
- **Pasaje breve relacionado:** S22; **ubicación:** ACC/AHA 2025, Table 21, hypertension pregnancy.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** MMHG; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0447: Sospecha preeclampsia proteína (Embarazo)

- **SI:** Gestación≥20 sem PA≥140/90 y proteína/creatinina orina≥0.3
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** embarazo_confirmado;semanas_gestacion;pa_validada;proteina_creatinina_orina; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACOG_PREE — https://www.acog.org/womens-health/faqs/preeclampsia-and-high-blood-pressure-during-pregnancy.
- **Pasaje breve relacionado:** S22; **ubicación:** ACC/AHA 2025, Table 21, hypertension pregnancy.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0448: Sospecha preeclampsia plaquetas (Embarazo)

- **SI:** Gestación≥20 sem PA nueva≥140/90 y plaquetas<100×10⁹/L
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** embarazo_confirmado;semanas_gestacion;pa_validada;plaquetas; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACOG_PREE — https://www.acog.org/womens-health/faqs/preeclampsia-and-high-blood-pressure-during-pregnancy.
- **Pasaje breve relacionado:** S22; **ubicación:** ACC/AHA 2025, Table 21, hypertension pregnancy.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0449: Sospecha preeclampsia renal (Embarazo)

- **SI:** Gestación≥20 sem HTA nueva + creatinina>1.1 mg/dL o doble basal
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** embarazo_confirmado;semanas_gestacion;pa_validada;creatinina_historial; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACOG_PREE — https://www.acog.org/womens-health/faqs/preeclampsia-and-high-blood-pressure-during-pregnancy.
- **Pasaje breve relacionado:** S22; **ubicación:** ACC/AHA 2025, Table 21, hypertension pregnancy.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0450: Sospecha preeclampsia hepática (Embarazo)

- **SI:** Gestación≥20 sem HTA nueva + transaminasas>2× límite referencia
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** embarazo_confirmado;semanas_gestacion;pa_validada;ast;alt;limites_lab; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACOG_PREE — https://www.acog.org/womens-health/faqs/preeclampsia-and-high-blood-pressure-during-pregnancy.
- **Pasaje breve relacionado:** S22; **ubicación:** ACC/AHA 2025, Table 21, hypertension pregnancy.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0451: Anemia gestante 1T (Embarazo)

- **SI:** Primer trimestre y Hb<11.0 g/dL
- **ENTONCES:** Valoración obstétrica específica según semana gestacional y gravedad.
- **Variables:** embarazo_confirmado;trimestre;hb; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** WHO_HB24 — https://www.ncbi.nlm.nih.gov/books/NBK602183/table/fm-ch1.tab2/.
- **Pasaje breve relacionado:** S08; **ubicación:** OMS 2024, Table 3: Haemoglobin cutoffs / anaemia severity.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** G_DL; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0452: Anemia gestante 2T (Embarazo)

- **SI:** Segundo trimestre y Hb<10.5 g/dL
- **ENTONCES:** Valoración obstétrica específica según semana gestacional y gravedad.
- **Variables:** embarazo_confirmado;trimestre;hb; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** WHO_HB24 — https://www.ncbi.nlm.nih.gov/books/NBK602183/table/fm-ch1.tab2/.
- **Pasaje breve relacionado:** S08; **ubicación:** OMS 2024, Table 3: Haemoglobin cutoffs / anaemia severity.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** G_DL; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0453: Anemia gestante 3T (Embarazo)

- **SI:** Tercer trimestre y Hb<11.0 g/dL
- **ENTONCES:** Valoración obstétrica específica según semana gestacional y gravedad.
- **Variables:** embarazo_confirmado;trimestre;hb; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** WHO_HB24 — https://www.ncbi.nlm.nih.gov/books/NBK602183/table/fm-ch1.tab2/.
- **Pasaje breve relacionado:** S08; **ubicación:** OMS 2024, Table 3: Haemoglobin cutoffs / anaemia severity.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** G_DL; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0454: No aplicar umbrales no gestante (Embarazo)

- **SI:** Embarazo confirmado: desactivar rangos HbA1c/IMC/CGM adultos no embarazados cuando no aplican
- **ENTONCES:** Valoración obstétrica específica según semana gestacional y gravedad.
- **Variables:** embarazo_confirmado; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACOG_PREE — https://www.acog.org/womens-health/faqs/preeclampsia-and-high-blood-pressure-during-pregnancy.
- **Pasaje breve relacionado:** S22; **ubicación:** ACC/AHA 2025, Table 21, hypertension pregnancy.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** CGM=intersticial, no prueba diagnóstica de diabetes | PA: manguito validado y protocolo; embarazo separado.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0455: Gestación y FC en sepsis (Embarazo)

- **SI:** Sospecha infección gestante con FC100–130: NICE distingue umbrales
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** embarazo_confirmado;infeccion_sospechada;fc_reposo; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** PA: manguito validado y protocolo; embarazo separado | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** BPM; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0456: Fiebre clínica (Infecciones)

- **SI:** T≥38.0°C medida en sitio válido y adulto; evaluar etiología no necesariamente bacteriana
- **ENTONCES:** Valorar contexto clínico y pruebas de infección, sin diagnosticar sepsis con signos aislados.
- **Variables:** temperatura_clinica; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** no atribuir a sepsis sin sospecha de infección y signos adicionales | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CELSIUS; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0457: Fiebre ≥39.0 (Infecciones)

- **SI:** T≥39.0°C medida clínicamente y persistente, priorizar evaluación contexto
- **ENTONCES:** Valorar contexto clínico y pruebas de infección, sin diagnosticar sepsis con signos aislados.
- **Variables:** temperatura_clinica; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** no atribuir a sepsis sin sospecha de infección y signos adicionales | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CELSIUS; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0458: Fiebre ≥40.0 (Infecciones)

- **SI:** T≥40.0°C confirmada, valoración pronta por diversas causas
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** temperatura_clinica; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** no atribuir a sepsis sin sospecha de infección y signos adicionales | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CELSIUS; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0459: Temperatura central baja (Infecciones)

- **SI:** T central <35°C confirmada, evaluar emergencia hipotermia
- **ENTONCES:** Solicitar evaluación médica inmediata; no administrar tratamientos automáticamente.
- **Variables:** temperatura_central; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CRITICA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** no atribuir a sepsis sin sospecha de infección y signos adicionales | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** CELSIUS; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0460: Infección sospechada y PAS≤90 (Infecciones)

- **SI:** Sospecha clínica infección + PAS≤90 mmHg validada
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** infeccion_sospechada;pas_validada; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** no atribuir a sepsis sin sospecha de infección y signos adicionales.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0461: Infección sospechada y PAS 91–100 (Infecciones)

- **SI:** Sospecha clínica infección + PAS91–100
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** infeccion_sospechada;pas_validada; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** no atribuir a sepsis sin sospecha de infección y signos adicionales.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0462: Infección sospechada y FC>130 (Infecciones)

- **SI:** Sospecha infección + FC>130 en reposo corroborada
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** infeccion_sospechada;fc_reposo; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** no atribuir a sepsis sin sospecha de infección y signos adicionales.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0463: Infección sospechada y FC91–130 (Infecciones)

- **SI:** Sospecha infección + FC91–130 no gestante, valorar conjunto
- **ENTONCES:** Valorar contexto clínico y pruebas de infección, sin diagnosticar sepsis con signos aislados.
- **Variables:** infeccion_sospechada;fc_reposo;embarazo_estado; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** no atribuir a sepsis sin sospecha de infección y signos adicionales.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0464: Infección sospechada y T<36 timpánica (Infecciones)

- **SI:** Sospecha infección + T timpánica<36°C
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** infeccion_sospechada;temp_timpanica; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** no atribuir a sepsis sin sospecha de infección y signos adicionales.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0465: Fiebre neutropénica en cáncer (Infecciones)

- **SI:** T≥38.3 una vez o≥38.0 durante 1h y ANC<0.5
- **ENTONCES:** Solicitar evaluación médica inmediata; no administrar tratamientos automáticamente.
- **Variables:** temperatura_clinica;neutrofilos;cancer_previo; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CRITICA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** IDSA_FN — https://www.idsociety.org/practice-guideline/neutropenic-patients-with-cancer/.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** no atribuir a sepsis sin sospecha de infección y signos adicionales.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0466: Fiebre + hipotensión + FC alta (Infecciones)

- **SI:** T≥38, PAS≤90, FC>100; priorizar deterioro, no etiquetar sepsis
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** temperatura_clinica;pas_validada;fc_reposo; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** no atribuir a sepsis sin sospecha de infección y signos adicionales | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0467: Fiebre + desaturación (Infecciones)

- **SI:** T≥38 y SpO2≤92 clínica confirmada, revisar infección respiratoria/otras causas
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** temperatura_clinica;spo2_clinica; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** no atribuir a sepsis sin sospecha de infección y signos adicionales | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0468: Fiebre + leucocitosis (Infecciones)

- **SI:** T≥38 con leucocitos>11×10⁹/L, no afirmar bacteria por sí sola
- **ENTONCES:** Valorar contexto clínico y pruebas de infección, sin diagnosticar sepsis con signos aislados.
- **Variables:** temperatura_clinica;leucocitos; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** no atribuir a sepsis sin sospecha de infección y signos adicionales | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0469: Fiebre + leucopenia (Infecciones)

- **SI:** T≥38 con leucocitos<4×10⁹/L, valoración etiológica
- **ENTONCES:** Valorar contexto clínico y pruebas de infección, sin diagnosticar sepsis con signos aislados.
- **Variables:** temperatura_clinica;leucocitos; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** no atribuir a sepsis sin sospecha de infección y signos adicionales | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0470: Alerta fiebre fuera de línea basal (Infecciones)

- **SI:** T clínica cambia≥1°C respecto basal individual ≥2 días, no diagnóstico
- **ENTONCES:** Valorar contexto clínico y pruebas de infección, sin diagnosticar sepsis con signos aislados.
- **Variables:** temperatura_clinica_baseline;temperatura_clinica; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** EXPERIMENTAL_NO_VALIDADA; **revisión v04:** SOLO_INVESTIGACION_DESACTIVADA.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** no atribuir a sepsis sin sospecha de infección y signos adicionales | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** DELTA_C; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0471: No clasificar infección por CRP (Infecciones)

- **SI:** CRP elevada sola no identifica infección bacteriana ni sepsis
- **ENTONCES:** Valorar contexto clínico y pruebas de infección, sin diagnosticar sepsis con signos aislados.
- **Variables:** proteina_c_reactiva; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** no atribuir a sepsis sin sospecha de infección y signos adicionales | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0472: Sospecha de infección con función renal alterada (Infecciones)

- **SI:** Infección sospechada + AKI por criterio de creatinina en 48h
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** infeccion_sospechada;creatinina_historial; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** no atribuir a sepsis sin sospecha de infección y signos adicionales | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0473: Fiebre y anticoagulación conocida (Infecciones)

- **SI:** Fiebre en anticoagulado + descenso Hb≥2 g/dL/7d, evaluar posible sangrado
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** temperatura_clinica;anticoagulacion;hb_historial; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** WHO_HB24 — https://www.ncbi.nlm.nih.gov/books/NBK602183/table/fm-ch1.tab2/.
- **Pasaje breve relacionado:** S08; **ubicación:** OMS 2024, Table 3: Haemoglobin cutoffs / anaemia severity.
- **Clasificación original:** EXPERIMENTAL_NO_VALIDADA; **revisión v04:** SOLO_INVESTIGACION_DESACTIVADA.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** no atribuir a sepsis sin sospecha de infección y signos adicionales | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0474: Hipoxemia grave crónica ATS (Respiratorio)

- **SI:** EPOC/ILD estable y SpO2≤88% crónica verificada en reposo a nivel relevante
- **ENTONCES:** Verificar con oxímetro clínico y valorar estudio respiratorio/sueño según proceda.
- **Variables:** spo2_clinica;patologia_pulmonar_previa; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** OBSERVACION.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ATS_OXYGEN — https://academic.oup.com/ajrccm/article/202/10/e121/8495596.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** oxímetro puede producir errores; diagnóstico de SAOS exige estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PORCENTAJE_SPO2; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0475: SpO2 baja nueva 89–92 (Respiratorio)

- **SI:** SpO2 89–92% clínica nueva vs basal, confirmar y evaluar altura/EPOC
- **ENTONCES:** Verificar con oxímetro clínico y valorar estudio respiratorio/sueño según proceda.
- **Variables:** spo2_clinica;spo2_baseline;altitud_m; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ATS_OXYGEN — https://academic.oup.com/ajrccm/article/202/10/e121/8495596.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** oxímetro puede producir errores; diagnóstico de SAOS exige estudio | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PORCENTAJE_SPO2; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0476: SpO2≤88 nueva (Respiratorio)

- **SI:** SpO2≤88% clínica confirmada y nueva, valoración pronta
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** spo2_clinica;spo2_baseline; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ATS_OXYGEN — https://academic.oup.com/ajrccm/article/202/10/e121/8495596.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** oxímetro puede producir errores; diagnóstico de SAOS exige estudio | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** PORCENTAJE_SPO2; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0477: SpO2 nocturna fluctuante (Respiratorio)

- **SI:** Desaturaciones ≥4 pp repetidas durante 3 noches, señal validada: solicitar estudio sueño si clínicamente apropiado
- **ENTONCES:** Verificar con oxímetro clínico y valorar estudio respiratorio/sueño según proceda.
- **Variables:** spo2_nocturna;spo2_calidad; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CRIBADO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AASM_SLEEPMED — https://aasm.org/resources/clinicalguidelines/diagnostic-testing-osa.pdf.
- **Pasaje breve relacionado:** S09; **ubicación:** AASM 2017, Good Practice Statements / Recommendations 1–2.
- **Clasificación original:** EXPERIMENTAL_NO_VALIDADA; **revisión v04:** SOLO_INVESTIGACION_DESACTIVADA.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** oxímetro puede producir errores; diagnóstico de SAOS exige estudio | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_EPISODIOS; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0478: Posible AOS con obesidad (Respiratorio)

- **SI:** IMC≥30 + desaturación nocturna repetida, no diagnóstico; solicitar evaluación sueño
- **ENTONCES:** Verificar con oxímetro clínico y valorar estudio respiratorio/sueño según proceda.
- **Variables:** imc;spo2_nocturna; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CRIBADO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AASM_SLEEPMED — https://aasm.org/resources/clinicalguidelines/diagnostic-testing-osa.pdf.
- **Pasaje breve relacionado:** S09; **ubicación:** AASM 2017, Good Practice Statements / Recommendations 1–2.
- **Clasificación original:** EXPERIMENTAL_NO_VALIDADA; **revisión v04:** SOLO_INVESTIGACION_DESACTIVADA.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** oxímetro puede producir errores; diagnóstico de SAOS exige estudio | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0479: Posible AOS con HTA nocturna (Respiratorio)

- **SI:** ABPM noche≥120/70 y desaturaciones nocturnas recurrentes
- **ENTONCES:** Verificar con oxímetro clínico y valorar estudio respiratorio/sueño según proceda.
- **Variables:** pa_abpm_noche;spo2_nocturna; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CRIBADO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AASM_SLEEPMED — https://aasm.org/resources/clinicalguidelines/diagnostic-testing-osa.pdf.
- **Pasaje breve relacionado:** S09; **ubicación:** AASM 2017, Good Practice Statements / Recommendations 1–2.
- **Clasificación original:** EXPERIMENTAL_NO_VALIDADA; **revisión v04:** SOLO_INVESTIGACION_DESACTIVADA.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** oxímetro puede producir errores; diagnóstico de SAOS exige estudio | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0480: Nocturna sin patrón apnea demostrable (Respiratorio)

- **SI:** Oximetría nocturna sola insuficiente para diagnosticar AOS o calcular IAH
- **ENTONCES:** Verificar con oxímetro clínico y valorar estudio respiratorio/sueño según proceda.
- **Variables:** spo2_nocturna; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AASM_SLEEPMED — https://aasm.org/resources/clinicalguidelines/diagnostic-testing-osa.pdf.
- **Pasaje breve relacionado:** S09; **ubicación:** AASM 2017, Good Practice Statements / Recommendations 1–2.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** oxímetro puede producir errores; diagnóstico de SAOS exige estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0481: Sin datos frecuencia respiratoria (Respiratorio)

- **SI:** No disponible FR ni calidad sueño: no calcular NEWS2 ni AHI
- **ENTONCES:** Verificar con oxímetro clínico y valorar estudio respiratorio/sueño según proceda.
- **Variables:** fr;datos_sueño; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AASM_SLEEPMED — https://aasm.org/resources/clinicalguidelines/diagnostic-testing-osa.pdf.
- **Pasaje breve relacionado:** S09; **ubicación:** AASM 2017, Good Practice Statements / Recommendations 1–2.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** oxímetro puede producir errores; diagnóstico de SAOS exige estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0482: Enfermedad pulmonar + saturación baja (Respiratorio)

- **SI:** EPOC previo + SpO2<90 nueva; clínica decide nivel de intervención
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** epoc_previa;spo2_clinica;spo2_baseline; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ATS_OXYGEN — https://academic.oup.com/ajrccm/article/202/10/e121/8495596.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** oxímetro puede producir errores; diagnóstico de SAOS exige estudio | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0483: Altitud cambiante confunde SpO2 (Respiratorio)

- **SI:** Nueva estancia altitud >500 m superior basal coincide con caída SpO2: contextualizar
- **ENTONCES:** Verificar con oxímetro clínico y valorar estudio respiratorio/sueño según proceda.
- **Variables:** altitud_historial;spo2_baseline; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ATS_OXYGEN — https://academic.oup.com/ajrccm/article/202/10/e121/8495596.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** EXPERIMENTAL_NO_VALIDADA; **revisión v04:** SOLO_INVESTIGACION_DESACTIVADA.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** oxímetro puede producir errores; diagnóstico de SAOS exige estudio | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** DELTA_M; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0484: Desaturación y FC altas en reposo (Respiratorio)

- **SI:** SpO2 clínica<90 + FC>110: valorar patología respiratoria/cardiaca
- **ENTONCES:** Solicitar valoración médica prioritaria; confirmar medida sin demorar atención cuando exista riesgo clínico.
- **Variables:** spo2_clinica;fc_reposo; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** URGENTE; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ATS_OXYGEN — https://academic.oup.com/ajrccm/article/202/10/e121/8495596.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** oxímetro puede producir errores; diagnóstico de SAOS exige estudio | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_FACTORES; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0485: Caída SpO2 4pp basal (Respiratorio)

- **SI:** SpO2 clínica desciende≥4 puntos de basal estable y se confirma
- **ENTONCES:** Verificar con oxímetro clínico y valorar estudio respiratorio/sueño según proceda.
- **Variables:** spo2_clinica;spo2_baseline; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ATS_OXYGEN — https://academic.oup.com/ajrccm/article/202/10/e121/8495596.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** EXPERIMENTAL_NO_VALIDADA; **revisión v04:** SOLO_INVESTIGACION_DESACTIVADA.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** oxímetro puede producir errores; diagnóstico de SAOS exige estudio | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** DELTA_PP; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0486: SpO2 durante ejercicio no comparable (Respiratorio)

- **SI:** SpO2 de ejercicio no usar umbral reposo sin protocolo específico
- **ENTONCES:** Verificar con oxímetro clínico y valorar estudio respiratorio/sueño según proceda.
- **Variables:** spo2;actividad; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ATS_OXYGEN — https://academic.oup.com/ajrccm/article/202/10/e121/8495596.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** oxímetro puede producir errores; diagnóstico de SAOS exige estudio | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0487: Oximetría saturada al 100 no descarta problemas (Respiratorio)

- **SI:** SpO2≈100% no descarta anemia, hipoventilación ni hipercapnia
- **ENTONCES:** Verificar con oxímetro clínico y valorar estudio respiratorio/sueño según proceda.
- **Variables:** spo2_clinica; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ATS_OXYGEN — https://academic.oup.com/ajrccm/article/202/10/e121/8495596.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** oxímetro puede producir errores; diagnóstico de SAOS exige estudio | combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0488: SpO2 piel no validada (Respiratorio)

- **SI:** Oximetría no clínica de pulsera no equivalente a finger probe validado
- **ENTONCES:** Verificar con oxímetro clínico y valorar estudio respiratorio/sueño según proceda.
- **Variables:** spo2_dispositivo;spo2_calidad; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** FDA_SPO2 — https://www.fda.gov/medical-devices/products-and-medical-procedures/pulse-oximeters.
- **Pasaje breve relacionado:** S10; **ubicación:** FDA Pulse Oximeters, February 2021 safety communication.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** oxímetro puede producir errores; diagnóstico de SAOS exige estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0489: Antecedente de infarto -> prevención secundaria (Seguridad clínica)

- **SI:** Infarto documentado en historial; no usar PREVENT primaria
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** infarto_previo; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACC_LIP26 — https://www.jacc.org/doi/10.1016/j.jacc.2025.11.016.
- **Pasaje breve relacionado:** S12; **ubicación:** ACC/AHA Dyslipidemia 2026, Section 4.2.3.7.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0490: Ictus previo -> prevención secundaria (Seguridad clínica)

- **SI:** Ictus isquémico previo documentado; no usar PREVENT primaria
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** ictus_previo; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACC_LIP26 — https://www.jacc.org/doi/10.1016/j.jacc.2025.11.016.
- **Pasaje breve relacionado:** S12; **ubicación:** ACC/AHA Dyslipidemia 2026, Section 4.2.3.7.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0491: Trasplante renal -> seguimiento específico (Seguridad clínica)

- **SI:** Trasplante renal previo: eGFR/ACR con umbrales y monitorización adaptados
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** trasplante_renal_previo; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** KDIGO24 — https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf.
- **Pasaje breve relacionado:** S05; **ubicación:** KDIGO 2024 ERC, Practice Point 2.2.1, página S156.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0492: Dializado excluido KFRE (Seguridad clínica)

- **SI:** Diálisis actual: no estimar primer fallo renal por KFRE
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** dialisis_actual; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** KDIGO24 — https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf.
- **Pasaje breve relacionado:** S05; **ubicación:** KDIGO 2024 ERC, Practice Point 2.2.1, página S156.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0493: Portador de marcapasos y bradicardia (Seguridad clínica)

- **SI:** Marcapasos documentado: pulso PPG requiere interpretación específica
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** marcapasos_previo;fc_ppg; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CONSULTA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ESC_AF — https://academic.oup.com/eurheartj/article/45/36/3314/7738779.
- **Pasaje breve relacionado:** S21; **ubicación:** ESC 2024 AF guideline, key message 10.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0494: Enfermedad hematológica y Hb (Seguridad clínica)

- **SI:** Anemia hemolítica/hemoglobinopatía: HbA1c puede ser engañosa
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** hemoglobinopatia_previa;hba1c; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_DX26 — https://pmc.ncbi.nlm.nih.gov/articles/PMC12690183/.
- **Pasaje breve relacionado:** S01; **ubicación:** ADA Standards of Care 2026, Section 2 / Table 2.1.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0495: Amputación afecta IMC (Seguridad clínica)

- **SI:** Amputación mayor: peso e IMC no equiparables a referencia ordinaria
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** amputacion_previa;peso_kg; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** WHO_BMI — https://www.cdc.gov/bmi/adult-calculator/bmi-categories.html.
- **Pasaje breve relacionado:** S27; **ubicación:** CDC Adult BMI categories.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0496: Embarazo y score cardiaco no validado (Seguridad clínica)

- **SI:** Embarazo confirmado: abstener PREVENT/HBPM estándar sin adaptación
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** embarazo_confirmado; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AHA_PREVENT — https://professional.heart.org/en/guidelines-and-statements/prevent-calculator.
- **Pasaje breve relacionado:** S30; **ubicación:** AHA Professional PREVENT calculator.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0497: Datos familiares insuficientes (Seguridad clínica)

- **SI:** No inferir antecedente familiar negativo cuando no está registrado
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** historia_familiar_estado; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ADA_DX26 — https://pmc.ncbi.nlm.nih.gov/articles/PMC12690183/.
- **Pasaje breve relacionado:** S01; **ubicación:** ADA Standards of Care 2026, Section 2 / Table 2.1.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0498: Etnicidad no proxy biológico (Seguridad clínica)

- **SI:** Origen étnico sin justificación científica específica no modifica arbitrariamente riesgos
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** origen_etnico; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AHA_PREVENT — https://professional.heart.org/en/guidelines-and-statements/prevent-calculator.
- **Pasaje breve relacionado:** S30; **ubicación:** AHA Professional PREVENT calculator.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0499: Alertas repetidas sin nueva información (Seguridad clínica)

- **SI:** Misma condición vigente: agrupar episodios, no disparar por cada muestra
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** episodios_activos; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NUM_EPISODIOS; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0500: Dos hipótesis no suman riesgo (Seguridad clínica)

- **SI:** Una misma taquicardia compartida por varias enfermedades no sumar probabilidades
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** alertas_solapadas; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0501: No automedicación en crisis (Seguridad clínica)

- **SI:** Cualquier alerta crítica no debe generar dosificación automáticamente
- **ENTONCES:** Solicitar evaluación médica inmediata; no administrar tratamientos automáticamente.
- **Variables:** alertas_criticas; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** CRITICA; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0502: Sin síntomas no excluir emergencia (Seguridad clínica)

- **SI:** Ausencia de síntomas registrados es dato faltante, no negación de síntomas
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** sintomas_estado; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0503: Ventana de datos insuficiente (Seguridad clínica)

- **SI:** Se exige criterio 14d y faltan días/cobertura para inferir normalidad
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** calidad_serie;dias_serie; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ISPAD_CGM24 — https://pmc.ncbi.nlm.nih.gov/articles/PMC11854985/.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0504: Sensor sin sincronización temporal (Seguridad clínica)

- **SI:** FC, PA, glucosa y SpO2 no alineados: no unir como evento simultáneo
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** timestamps_sensores; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_SEPSIS — https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk.
- **Pasaje breve relacionado:** S06; **ubicación:** NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo).
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0505: No predecir FA con HRV solamente (Seguridad clínica)

- **SI:** HRV baja sin ECG no permite probabilidad específica de FA
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** hrv;ecg_interpretado; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ESC_AF — https://academic.oup.com/eurheartj/article/45/36/3314/7738779.
- **Pasaje breve relacionado:** S21; **ubicación:** ESC 2024 AF guideline, key message 10.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0506: Sin hemograma no excluir anemia (Seguridad clínica)

- **SI:** Hemoglobina opcional ausente: no se puede emitir normalidad hemática
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** hb; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** WHO_HB24 — https://www.ncbi.nlm.nih.gov/books/NBK602183/table/fm-ch1.tab2/.
- **Pasaje breve relacionado:** S08; **ubicación:** OMS 2024, Table 3: Haemoglobin cutoffs / anaemia severity.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0507: Sin perfil tiroideo no excluir tiroides (Seguridad clínica)

- **SI:** TSH ausente: FC o peso no descartan patología tiroidea
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** tsh; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NICE_TSH — https://www.nice.org.uk/guidance/ng145/chapter/recommendations.
- **Pasaje breve relacionado:** S19; **ubicación:** NICE NG145, recommendation 1.2.8.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0508: Sin ACR no calcular KFRE (Seguridad clínica)

- **SI:** eGFR conocida, ACR ausente: probabilidades KFRE no calculables
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** egfr;acr_orina; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** KFRE_TANGRI16 — https://jamanetwork.com/journals/jama/fullarticle/2481005.
- **Pasaje breve relacionado:** SIN_EXTRACTO_VERIFICADO; **ubicación:** PENDIENTE.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0509: Sin colesterol no calcular PREVENT (Seguridad clínica)

- **SI:** No hay colesterol total y HDL: PREVENT no calculable
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** colesterol_total;hdl; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AHA_PREVENT — https://professional.heart.org/en/guidelines-and-statements/prevent-calculator.
- **Pasaje breve relacionado:** S30; **ubicación:** AHA Professional PREVENT calculator.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0510: Sin sexo usado en fórmula (Seguridad clínica)

- **SI:** No inventar coeficiente sexo en eGFR/PREVENT/KFRE si no hay campo adecuado
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** sexo_modelo; disponibilidad BASE.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** NIDDK_EGFR — https://www.niddk.nih.gov/research-funding/research-programs/kidney-clinical-research-epidemiology/laboratory/glomerular-filtration-rate-equations/adults.
- **Pasaje breve relacionado:** S13; **ubicación:** NIDDK, eGFR Equations for Adults / 2021 CKD-EPI.
- **Clasificación original:** UMBRAL_GUIA; **revisión v04:** CANDIDATA_GUIA_VERIFICAR_CRITERIO_COMPLETO.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** confirmar que indicador, protocolo y población coinciden exactamente con la fuente.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0511: Sin contexto de edad/gestación (Seguridad clínica)

- **SI:** Adulto/embarazo no confirmado: abstener rangos específicos hasta aclarar
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** edad;embarazo_estado; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** ACOG_PREE — https://www.acog.org/womens-health/faqs/preeclampsia-and-high-blood-pressure-during-pregnancy.
- **Pasaje breve relacionado:** S22; **ubicación:** ACC/AHA 2025, Table 21, hypertension pregnancy.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.

## R0512: Origen étnico sensible (Seguridad clínica)

- **SI:** No usar origen étnico para aumentar urgencia sin validación de equidad
- **ENTONCES:** Abstenerse de inferencia específica y solicitar el dato o medición pertinente.
- **Variables:** origen_etnico;validacion_equidad; disponibilidad BASE+OPCIONAL.
- **Ventana:** Según la condición (episodio, serie o laboratorio) indicada en criterio; **Población:** Adultos; aplicar restricciones descritas en el criterio.
- **Prioridad:** SEGUIMIENTO; **Naturaleza:** PATRON_RIESGO.
- **Confirmación necesaria:** Control mediante técnica clínica validada; según el criterio.
- **Fuente declarada v03:** AHA_PREVENT — https://professional.heart.org/en/guidelines-and-statements/prevent-calculator.
- **Pasaje breve relacionado:** S30; **ubicación:** AHA Professional PREVENT calculator.
- **Clasificación original:** DERIVADA_NO_VALIDADA; **revisión v04:** REGLA_DERIVADA_PENDIENTE_VALIDACION.
- **Por qué se considera la regla:** el patrón o umbral seleccionado puede fundamentar una recomendación de confirmación o monitorización según la población; NO demuestra una probabilidad individual por sí mismo.
- **Supuestos que deben comprobarse:** combinación NO validada: manténgase apagada hasta estudio.
- **Qué se decide ante datos ausentes:** NO_EVALUABLE: abstenerse cuando falten variables o validación instrumental.
- **Riesgo cuantitativo reportable:** NINGUNA; horizonte: No aplicable; porcentaje calibrado: false.
- **Razón para no usarlo como porcentaje:** una regla booleana sin muestra con desenlaces no proporciona P(enfermedad | biometría). Las mediciones de exposición solo cuantifican magnitud/duración.
- **Alternativa:** aplicar un modelo de probabilidad específico validado cuando exista y estén todos sus predictores; de lo contrario informar sólo severidad/urgencia/confirmación.
- **Decisión para producción:** NO hasta revisión de criterio, pruebas y comité clínico.
