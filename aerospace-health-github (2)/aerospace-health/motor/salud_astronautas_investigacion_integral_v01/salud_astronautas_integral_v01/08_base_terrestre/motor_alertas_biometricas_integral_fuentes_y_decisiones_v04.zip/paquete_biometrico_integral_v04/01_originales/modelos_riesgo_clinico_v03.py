"""Cálculos de referencia de investigación, NO autorizados para decisiones médicas autónomas.

Riesgo absoluto únicamente para modelos publicados con predictores completos.
El sistema falla cerrado por datos faltantes, población fuera de rango o indicadores no fiables.
Fuentes: AHA PREVENT 2024, JAMA NwO supp eTable 1 (2024), JAMA 2016 KFRE, NIDDK CKD-EPI 2021.
"""
from __future__ import annotations
import math
from typing import Optional, Mapping, Any

class NoCalculable(ValueError):
    """Entrada ausente, medición no validada o población fuera de alcance."""

def require_float(v, name, lo=None, hi=None):
    if v is None or isinstance(v,bool):raise NoCalculable(f'{name}: dato numérico obligatorio ausente')
    try: n=float(v)
    except (TypeError,ValueError):raise NoCalculable(f'{name}: no numérico')
    if not math.isfinite(n):raise NoCalculable(f'{name}: no finito')
    if (lo is not None and n<lo) or (hi is not None and n>hi):
        raise NoCalculable(f'{name}: fuera rango de aplicación [{lo},{hi}]')
    return n

def require_bool(v,name):
    if type(v) is not bool:raise NoCalculable(f'{name}: indicador booleano explícito obligatorio (no inferir no)')
    return int(v)

def require_sex(v):
    if v not in ('F','M'):raise NoCalculable('sexo_modelo: especificar F o M usado por la ecuación validada, o abstenerse')
    return v

def ckdepi2021(*, edad, creatinina_mg_dl, sexo_modelo):
    a=require_float(edad,'edad',18,120)
    scr=require_float(creatinina_mg_dl,'creatinina_mg_dl',0.1,30)
    sx=require_sex(sexo_modelo)
    k,alpha=(0.7,-0.241) if sx=='F' else (0.9,-0.302)
    return 142*min(scr/k,1)**alpha*max(scr/k,1)**(-1.2)*0.9938**a*(1.012 if sx=='F' else 1)

def fib4(*,edad,ast_u_l,alt_u_l,plaquetas_10e9_l, contexto_masld=True, enfermedad_aguda=False):
    a=require_float(edad,'edad',18,120)
    ast=require_float(ast_u_l,'ast_u_l',1,20000)
    alt=require_float(alt_u_l,'alt_u_l',1,20000)
    pl=require_float(plaquetas_10e9_l,'plaquetas_10e9_l',1,2000)
    if enfermedad_aguda:raise NoCalculable('FIB-4 no interpretable durante enfermedad aguda')
    if not contexto_masld:raise NoCalculable('interpretación del corte FIB-4 sólo definida para población objetivo')
    if a<35:raise NoCalculable('FIB-4 con bajo desempeño en menores de 35')
    score=a*ast/(pl*math.sqrt(alt))
    if a>=65:
        label='bajo' if score<2 else 'elevado (requiere pruebas secundarias)'
    else:
        label='bajo' if score<1.3 else ('intermedio' if score<=2.67 else 'alto')
    return {'modelo':'FIB4','valor':round(score,4),'tipo':'PUNTUACION_NO_PROBABILIDAD', 'nivel':label,'umbral_bajo_edad':2.0 if a>=65 else 1.3}

def kfre4(*, edad, sexo_modelo, egfr, acr_mg_g, erc_g3_g5_confirmada, dialisis=False, region='no_norteamerica'):
    a=require_float(edad,'edad',18,120);sx=require_sex(sexo_modelo)
    eg=require_float(egfr,'egfr',1,59.999999)
    acr=require_float(acr_mg_g,'acr_mg_g',0.01,100000)
    if type(erc_g3_g5_confirmada) is not bool or not erc_g3_g5_confirmada:
        raise NoCalculable('KFRE requiere ERC G3–G5 confirmada; eGFR aislada no basta')
    if dialisis:raise NoCalculable('KFRE inaplicable a personas en diálisis')
    if region not in ('no_norteamerica','norteamerica'):
        raise NoCalculable('KFRE: seleccionar calibración regional explícita')
    male=int(sx=='M')
    lp=-0.2201*(a/10-7.036)+0.2467*(male-0.5642)-0.5567*(eg/5-7.222)+0.4510*(math.log(acr)-5.137)
    s2,s5=((0.9832,0.9365) if region=='no_norteamerica' else (0.9751,0.9240))
    result={'modelo':'KFRE_4V','tipo':'PROBABILIDAD_ABSOLUTA','region_ecuacion':region,
            'riesgo_2_anios_pct':100*(1-s2**math.exp(lp)),
            'riesgo_5_anios_pct':100*(1-s5**math.exp(lp)),
            'estado_calibracion_mexico':'NO_VALIDADO_LOCALMENTE',
            'fuente':'Tangri et al JAMA 2016; KDIGO 2024'}
    return result

# Coeficientes de modelos base PREVENT 10y publicados (NO modelos opcionales ni 30y).
# Orden CV/ASCVD (20 términos): age, nonhdl, hdl, sbp1, sbp2, diab, smoke, egfr1,
# egfr2, antihtn, statin, sbp2*antihtn, nonhdl*statin, age*nonhdl, age*hdl,
# age*sbp2, age*diab, age*smoke, age*egfr1, intercepto.
_PREVENT_COEFF={
 'F':{
  'CVD':[0.7939329,0.0305239,-0.1606857,-0.2394003,0.360078,0.8667604,0.5360739,0.6045917,0.0433769,0.3151672,-0.1477655,-0.0663612,0.1197879,-0.0819715,0.0306769,-0.0946348,-0.27057,-0.078715,-0.1637806,-3.307728],
  'ASCVD':[0.7198830247,0.1176967025,-0.1511850059,-0.0835357979,0.3592852056,0.8348584771,0.4831078053,0.4864619076,0.039777901,0.2265308946,-0.0592373982,-0.0395761989,0.0844423026,-0.0567838997,0.0325691998,-0.1035984978,-0.241754204,-0.0791141987,-0.167149201,-3.819974899],
  'HF':[0.8998234868,-0.4559771121,0.3576504886,1.038346052,0.5839160085,-0.0072293999,0.2997705936,0.7451637983,0.0557086989,0.3534441888,-0.0981511027,-0.0946663022,-0.3581041098,-0.1159453019,-0.003878,-0.1884288937,-4.310409069]},
 'M':{
  'CVD':[0.7688528,0.0736174,-0.0954431,-0.4347345,0.3362658,0.7692857,0.4386871,0.5378979,0.0164827,0.288879,-0.1337349,-0.0475924,0.150273,-0.0517874,0.0191169,-0.1049477,-0.2251948,-0.0895067,-0.1543702,-3.031168],
  'ASCVD':[0.7099847198,0.1658663005,-0.1144284979,-0.2837212086,0.3239977062,0.7189596891,0.3956972957,0.369007498,0.0203619003,0.2036522031,-0.0865581036,-0.0322915986,0.1145630032,-0.0300005004,0.0232746992,-0.0927024037,-0.2018525004,-0.0970527008,-0.1217081025,-3.500654936],
  'HF':[0.8972641826,-0.6811466217,0.3634460866,0.9237759709,0.5023735762,-0.0485840999,0.3726929128,0.6926916838,0.0251826998,0.2980921865,-0.0497731008,-0.1289200932,-0.3040924072,-0.140168801,0.0068126,-0.179777801,-3.946391106]}
}

def prevent_10y_base(*, edad, sexo_modelo, pas_mmhg,colesterol_total_mg_dl,hdl_mg_dl,
                     egfr,imc, diabetes_confirmada, fuma_actual, toma_estatina,
                     toma_antihipertensivos, ecv_previa):
    age=require_float(edad,'edad',30,79)
    sex=require_sex(sexo_modelo)
    sbp=require_float(pas_mmhg,'pas_mmhg',90,200)
    tc=require_float(colesterol_total_mg_dl,'colesterol_total_mg_dl',130,320)
    hdl=require_float(hdl_mg_dl,'hdl_mg_dl',20,100)
    egfr=require_float(egfr,'egfr',15,140)
    bmi=require_float(imc,'imc',18.5,39.9)
    if tc<=hdl:raise NoCalculable('HDL no puede superar colesterol total')
    if type(ecv_previa) is not bool:raise NoCalculable('ecv_previa: debe constar verdadero/falso, no asumirse')
    if ecv_previa:raise NoCalculable('PREVENT sólo prevención primaria sin ECV previa')
    diab=require_bool(diabetes_confirmada,'diabetes_confirmada')
    smoke=require_bool(fuma_actual,'fuma_actual')
    statin=require_bool(toma_estatina,'toma_estatina')
    anti=require_bool(toma_antihipertensivos,'toma_antihipertensivos')
    a=(age-55)/10
    nonhdl=(tc-hdl)*0.02586 -3.5
    h=(hdl*0.02586-1.3)/0.3
    s1=(min(sbp,110)-110)/20
    s2=(max(sbp,110)-130)/20
    g1=(min(egfr,60)-60)/-15
    g2=(max(egfr,60)-90)/-15
    bm1=(min(bmi,30)-25)/5
    bm2=(max(bmi,30)-30)/5
    feat_cvd=[a,nonhdl,h,s1,s2,diab,smoke,g1,g2,anti,statin,s2*anti,nonhdl*statin,a*nonhdl,a*h,a*s2,a*diab,a*smoke,a*g1,1]
    feat_hf=[a,s1,s2,diab,smoke,bm1,bm2,g1,g2,anti,s2*anti,a*s2,a*diab,a*smoke,a*bm2,a*g1,1]
    res={'modelo':'PREVENT_BASE_10Y','tipo':'PROBABILIDAD_ABSOLUTA','horizonte_anios':10,'poblacion':'EUA 30-79 sin ECV',
         'calibracion_mexico':'PENDIENTE','ecuaciones_opcionales':'NO INCLUIDAS'}
    for outcome in ('CVD','ASCVD','HF'):
        c=_PREVENT_COEFF[sex][outcome]; feat=feat_hf if outcome=='HF' else feat_cvd
        lp=sum(x*y for x,y in zip(feat,c))
        res['riesgo_'+outcome.lower()+'_10y_pct']=100/(1+math.exp(-lp))
    return res

def cha2ds2_va(*, fa_confirmada,edad,insuficiencia_cardiaca,hipertension,diabetes,ictus_ait_embolia_previa,enfermedad_vascular):
    if fa_confirmada is not True:raise NoCalculable('Se exige fibrilación auricular ECG confirmada')
    age=require_float(edad,'edad',18,120)
    inputs=[require_bool(v,n) for n,v in [('IC',insuficiencia_cardiaca),('HTA',hipertension),('DM',diabetes),('ictus',ictus_ait_embolia_previa),('vascular',enfermedad_vascular)]]
    points=inputs[0]+inputs[1]+(2 if age>=75 else 1 if age>=65 else 0)+inputs[2]+2*inputs[3]+inputs[4]
    return {'modelo':'CHA2DS2_VA','puntos':points,'tipo':'PUNTUACION_NO_PROBABILIDAD','escenario':'anticoagulación: decisión clínica según ESC 2024'}

def cgm_metrics(samples, *, diabetes_confirmada, minimo_horas=14*24, min_cobertura=0.70):
    """samples: [(timestamp_horas,glucosa_mg_dl,calidad_valida_bool), ...].
    Interpolación de retención hasta muestra siguiente, nunca se rellenan lagunas >15min.
    Se computa cobertura temporal real y TIR/TBR/TAR; no calculo diagnóstico.
    """
    if type(diabetes_confirmada) is not bool:raise NoCalculable('diabetes_confirmada falta')
    if not isinstance(samples,list) or len(samples)<2:raise NoCalculable('serie insuficiente')
    s=sorted(samples,key=lambda t:t[0]); window=s[-1][0]-s[0][0]
    if window<minimo_horas:raise NoCalculable('ventana CGM menor a 14 días')
    valid_time=0.0; buckets={'below54':0.,'below70':0.,'range70_180':0.,'above180':0.,'above250':0.}
    for (t,g,q),(tn,gn,qn) in zip(s,s[1:]):
        dt=tn-t
        if dt<=0 or dt>0.25 or q is not True or qn is not True:continue
        glucose=require_float(g,'glucosa_cgm',20,600)
        valid_time+=dt
        if glucose<54:buckets['below54']+=dt
        if glucose<70:buckets['below70']+=dt
        if 70<=glucose<=180:buckets['range70_180']+=dt
        if glucose>180:buckets['above180']+=dt
        if glucose>250:buckets['above250']+=dt
    coverage=valid_time/window
    if coverage<min_cobertura:raise NoCalculable(f'Cobertura CGM {coverage:.1%} <70%')
    return {'modelo':'CGM_TIR','tipo':'EXPOSICION_NO_PROBABILIDAD','cobertura_pct':100*coverage,
            'ventana_dias':window/24,'diabetes_confirmada':diabetes_confirmada,
            'metricas_pct':{k:100*v/valid_time for k,v in buckets.items()},
            'nota':'Objetivos de TIR se aplican principalmente con diabetes; no diagnósticos para población sin diabetes.'}

if __name__=='__main__':
    import json
    demo={}
    p=prevent_10y_base(edad=50,sexo_modelo='F',pas_mmhg=160,colesterol_total_mg_dl=240,hdl_mg_dl=55,egfr=90,imc=35,diabetes_confirmada=False,fuma_actual=False,toma_estatina=False,toma_antihipertensivos=True,ecv_previa=False)
    assert abs(p['riesgo_cvd_10y_pct']-5.4)<0.3,p
    assert abs(p['riesgo_ascvd_10y_pct']-3.6)<0.3,p
    assert abs(p['riesgo_hf_10y_pct']-2.5)<0.3,p
    demo['PREVENT_ejemplo_publicado_mujer50']=p
    demo['PREVENT_ejemplo_publicado_mujer50_fumadora']=prevent_10y_base(edad=50,sexo_modelo='F',pas_mmhg=160,colesterol_total_mg_dl=240,hdl_mg_dl=55,egfr=90,imc=35,diabetes_confirmada=False,fuma_actual=True,toma_estatina=False,toma_antihipertensivos=True,ecv_previa=False)
    assert abs(demo['PREVENT_ejemplo_publicado_mujer50_fumadora']['riesgo_cvd_10y_pct']-9.3)<0.4
    demo['KFRE_ejemplo_hipotetico']=kfre4(edad=65,sexo_modelo='M',egfr=35,acr_mg_g=600,erc_g3_g5_confirmada=True)
    demo['FIB4_ejemplo_hipotetico']=fib4(edad=50,ast_u_l=30,alt_u_l=25,plaquetas_10e9_l=160)
    demo['eGFR_ejemplo_hipotetico']=ckdepi2021(edad=55,sexo_modelo='F',creatinina_mg_dl=1.2)
    demo['CHA2DS2_VA_ejemplo']=cha2ds2_va(fa_confirmada=True,edad=77,insuficiencia_cardiaca=False,hipertension=True,diabetes=True,ictus_ait_embolia_previa=False,enfermedad_vascular=False)
    try:prevent_10y_base(edad=50,sexo_modelo='F',pas_mmhg=160,colesterol_total_mg_dl=240,hdl_mg_dl=55,egfr=90,imc=35,diabetes_confirmada=False,fuma_actual=None,toma_estatina=False,toma_antihipertensivos=True,ecv_previa=False)
    except NoCalculable as exc:demo['PREVENT_sin_tabaquismo']='NO_CALCULABLE: '+str(exc)
    else:raise AssertionError('Debería abstenerse sin tabaquismo')
    try:kfre4(edad=65,sexo_modelo='M',egfr=75,acr_mg_g=600,erc_g3_g5_confirmada=True)
    except NoCalculable as exc:demo['KFRE_fuera_de_G3G5']='NO_CALCULABLE: '+str(exc)
    else:raise AssertionError('Debería abstenerse fuera de G3-G5')
    with open('/mnt/data/ejemplos_cuantificacion_v03.json','w') as f:json.dump(demo,f,indent=2,ensure_ascii=False)
    print(json.dumps(demo,indent=2,ensure_ascii=False))
