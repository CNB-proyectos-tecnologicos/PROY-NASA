import json,csv,collections,re,pathlib,os,hashlib,zipfile,subprocess
P=pathlib.Path('/mnt/data/paquete_biometrico_integral_v04')
x=json.load(open(P/'01_originales/motor_alertas_catalogo_v03.json',encoding='utf8'))
y=json.load(open(P/'01_originales/motor_alertas_catalogo_v02.json',encoding='utf8'))
rs=x['reglas']; src={r['id']:r for r in x['fuentes']}
errors=[]; warnings=[]; rows=[]
for r in rs:
 flags=[]
 if r.get('fuente_id') not in src:flags.append('FUENTE_ID_AUSENTE')
 if r.get('fuente_id') in src and r.get('fuente_url')!=src[r['fuente_id']]['url']: flags.append('URL_DISCORDANTE_REGISTRO')
 if re.search(r'Según la condición',r.get('ventana',''),re.I):flags.append('VENTANA_GENERICA_NO_OPERATIVA')
 if r.get('estado_evidencia')=='UMBRAL_GUIA' and r.get('riesgo_formato')=='NUM_FACTORES':flags.append('UMBRAL_GUIA_APARENTE_PUNTAJE_DE_FACTORES')
 if r.get('estado_evidencia')=='EXPERIMENTAL_NO_VALIDADA':flags.append('EXPERIMENTAL_DESACTIVADA')
 if r.get('estado_evidencia')=='DERIVADA_NO_VALIDADA':flags.append('REGLA_DERIVADA_SIN_VALIDACION')
 if r.get('dominio') in ('Infecciones','Deterioro sistémico') and r.get('fuente_id')=='NICE_SEPSIS':flags.append('FALTA_SOSPECHA_INFECCION_PARA_ALGORITMO_DE_SEPSIS')
 if r.get('dominio')=='Ritmo cardiaco':flags.append('COMPROBAR_ECG_PARA_DIAGNOSTICO_DE_FA')
 if r.get('dominio')=='Respiratorio':flags.append('COMPROBAR_VALIDACION_OXIMETRO_ESTUDIO_SAOS')
 if r.get('dominio') in ('Presión arterial','Embarazo'):flags.append('COMPROBAR_DISPOSITIVO_PA_Y_EMBARAZO')
 if r.get('fuente_id')=='KFRE_RECAL':flags.append('RECALIBRACION_REFERENCIA_SECUNDARIA_NO_PRIMARIA')
 if r.get('fuente_id')=='ESC_HF26':flags.append('REVISAR_EXISTENCIA_EDICION_2026_Y_UMBRAL')
 if r.get('fuente_id')=='IDSA_NEUTRO':flags.append('PROTOCOLO_LOCAL_2017_NO_GUIDELINE_ACTUAL')
 if r.get('es_probabilidad_calibrada') and r.get('riesgo_formato','').startswith('PROBABILIDAD') is False:flags.append('INCONSISTENCIA_INDICADOR_PROBABILIDAD')
 rows.append({'id':r['id'],'dominio':r['dominio'],'evidencia':r['estado_evidencia'],'flags':' | '.join(flags),'n_flags':len(flags)})
with open(P/'08_auditoria/AUDITORIA_AUTOMATICA_512.csv','w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
counts=collections.Counter(r['estado_evidencia'] for r in rs)
flags=collections.Counter(k for r in rows for k in r['flags'].split(' | ') if k)
uniqueurls=len(set(r['url'] for r in x['fuentes']))
report=f'''# Auditoría automática de consistencia (no equivalente a revisión médica)

Fecha 2026-11-14.

- Catálogo v02: **{len(y['reglas'])}** reglas; v03: **{len(rs)}**.
- Fuente heredadas v03: **{len(x['fuentes'])}** IDs, **{uniqueurls}** URLs distintas (existen alias y duplicados).
- Número de dominios: **{len(set(r['dominio'] for r in rs))}**.
- UMBrales vinculados según etiquetado heredado: **{counts['UMBRAL_GUIA']}**.
- Derivadas sin validar: **{counts['DERIVADA_NO_VALIDADA']}**.
- Experimentales sin validar: **{counts['EXPERIMENTAL_NO_VALIDADA']}**.
- Referencia de extracto revisado temáticamente en anexo: **437 de 512**; restantes **75** tienen sólo referencia heredada sin extracto; asociación NO valida cada regla.
- Se verificó que las IDs de las 512 reglas son únicas: **{len(set(r['id'] for r in rs))==512}**.
- Sin referencia ID heredada en tabla fuentes: **{sum(1 for r in rs if r['fuente_id'] not in {z['id'] for z in x['fuentes']})}**.

## Indicadores de revisión automática

| Indicador | Conteo | Interpretación |
|---|---:|---|
'''
for flag,n in flags.most_common():report+=f'| `{flag}` | {n} | Inspección manual y test específico antes de activación. |\n'
report+='''
**Importante:** indicadores superpuestos. No deben sumarse los conteos. Un valor bajo de «discordancias de URL» solamente comprueba igualdad entre dos campos del mismo catálogo; NO comprueba que la web contenga realmente el criterio citado. Las pruebas automatizadas tampoco sustituyen revisión clínica.

## Hallazgos de riesgo a corregir antes de ejecución real

1. **Ventanas temporales genéricas:** las reglas v03 incluyen ventanas como «según la condición», no deterministas. Antes de compilar, cada regla necesita ventana exacta (duración, número de lecturas, límites de huecos, unidad y reloj).
2. **Atribución excesiva a guías:** etiqueta `UMBRAL_GUIA` puede referirse sólo al valor base, no a la combinación multivariada o prioridad automatizada. Se exige cita individual de apartado de guía.
3. **No se dispone de cohortes locales:** probabilidades PREVENT/KFRE sin evaluación mexicana; los demás cortes no son probabilidades y carecen de sensibilidad/especificidad de su implementación como sistema.
4. **FIB-4 edad 65:** código heredado `>=65` vs fuente que expresa `>65`; la discrepancia fronteriza necesita dictamen.
5. **Proveniencia de fuentes:** se conservan guías antiguas, obras duplicadas, registros secundarios; el anexo de 30 pasajes revisados no implica 61 verificaciones exhaustivas.
6. **Código demo vs reglas JSON:** el demo implementa sólo un subconjunto y no carga las 512 reglas de forma programática.
7. **Métodos obligatorios iniciales:** «PA continua» sólo se interpreta diagnósticamente si es una modalidad clínicamente validada para el uso indicado, algo que no se infiere de tener una serie temporal.
8. **Interpretación de A1c y hemoglobina:** aplicar exclusiones fisiológicas, gestacionales, analíticas y de población antes de emitir criterio.

## Cómo subsanar

Revisión de fuente de nivel regla (`rule_id`, criterio textual, página/sección, configuración del sensor, validador clínico, fecha y firma) -> DSL ejecutable -> pruebas unitarias (valores antes, igual, después del umbral) -> evaluación prospectiva -> aprobación regulatoria -> activación gradual.
'''
(P/'08_auditoria/INFORME_AUDITORIA.md').write_text(report,encoding='utf8')
with open(P/'08_auditoria/ESTADISTICAS_CATALOGO.json','w') as f:
 json.dump({'reglas_v02':len(y['reglas']),'reglas_v03':len(rs),'dominios':dict(collections.Counter(r['dominio'] for r in rs)),'evidencia':dict(counts),'fuentes_ids':len(x['fuentes']),'fuentes_urls_unicas':uniqueurls,'flags':dict(flags)},f,indent=2,ensure_ascii=False)
print('Stats',len(rs),len(x['fuentes']),uniqueurls,flags)
