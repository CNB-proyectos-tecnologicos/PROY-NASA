# Esquema para convertir criterios escritos en reglas ejecutables

**Precaución:** el catálogo v03 posee 512 reglas escritas como criterios en lenguaje natural. No es un conjunto de 512 predicados informáticos validados y probados. Este documento propone cómo transformar una regla seleccionada mediante revisión clínica, sin ejecutar el lenguaje natural arbitrariamente.

## Modelo canónico de regla

```json
{
  "rule_id": "EJEMPLO_BP_AMBULATORIA_001",
  "version": "0.1.0-investigacion",
  "estado": "DESACTIVADA_PENDIENTE_REVISION_CLINICA",
  "guideline_profile": "NICE_NG136",
  "fuente": {
    "url": "https://www.nice.org.uk/guidance/ng136/chapter/Recommendations",
    "section": "1.2.7–1.2.8",
    "year": 2026
  },
  "poblacion": {"min_age_years": 18, "pregnancy": "no_aplica_a_ruta_obstetrica"},
  "entradas": ["sbp_mean_mmhg", "dbp_mean_mmhg", "bp_method", "bp_protocol_valid"],
  "quality_gates": {"cuffless": false, "validated_cuff": true, "multi_day_protocol": true},
  "if": {
    "all": [
      {"field": "bp_method", "operator": "eq", "value": "HBPM"},
      {"field": "bp_protocol_valid", "operator": "eq", "value": true},
      {"any": [
        {"field": "sbp_mean_mmhg", "operator": "gte", "value": 135},
        {"field": "dbp_mean_mmhg", "operator": "gte", "value": 85}
      ]}
    ]
  },
  "then": {
    "classification": "CRIBADO_CONFIRMACION",
    "action": "Valoracion clinica de hipertension segun contexto y protocolo",
    "diagnosis_autonomous": false,
    "absolute_probability_pct": null
  },
  "on_missing": "NO_EVALUABLE",
  "on_invalid_sensor": "NO_EVALUABLE",
  "on_outside_population": "NO_APLICA",
  "test_status": "PENDIENTE"
}
```

**No usar esta regla como diagnóstico aislado:** el flujo NICE incorpora presión de consulta y HBPM/ABPM; se necesita documentar el primer paso del algoritmo y otros criterios. No atribuir erróneamente la rama aislada a una recomendación de diagnóstico autónomo.

## Evaluación en tres valores

`EVAL(rule,inputs)` debe devolver `TRUE | FALSE | UNKNOWN` para cada predicado; `UNKNOWN` se produce por fuente no fiable, falta de predictor, unidades incongruentes o valor obsoleto. En agregación ternaria, una conjunción con algún FALSE puede ser FALSE; una disyunción con algún TRUE puede ser TRUE; para todo el resto desconocido se aplica UNKNOWN. Las restricciones obligatorias de seguridad (estado gestacional, credenciales de sensor, población) NO se eliminan aunque un predicado clínico sea TRUE.

## Pipeline

1. Ingesta con tipado, tiempos y unidades.
2. Validación instrumental + plausibilidad + detección de artefactos.
3. Derivación autorizada de variables (p. ej. IMC, media PA, TIR).
4. Evaluación de exclusiones, población y contraindicaciones.
5. Evaluación con lógica ternaria.
6. Cálculo de riesgo validado si todos los predictores están presentes, o score/exposición si no procede una probabilidad.
7. Deduplicación por condición, episodio y ventana.
8. Priorización por severidad, certidumbre de señal y confiabilidad de fuente.
9. Registro inmutable de fuente, versión, unidad y valores que dispararon la decisión.
10. Presentación de recomendación y prueba confirmatoria con evaluación clínica humana.

## No combinar reglas ingenuamente

Una regla `glucosa elevada + IMC alto` no puede añadir 10 puntos porcentuales de riesgo de DM, porque la probabilidad conjunta depende de prevalencia, correlación, tratamientos y sesgo de selección. Tampoco se pueden multiplicar factores relativos extraídos de estudios distintos sin estimar interacciones y recalibrar. Las variables de etnicidad no se usarán como corrección instrumental ni como factor causal sin una razón clínica y evidencia específica.

## Salida auditada

```json
{
  "event_id": "anon-event-0001",
  "status": "NO_EVALUABLE",
  "reason_codes": ["MISSING_TOBACCO_STATUS", "MISSING_CURRENT_STATIN_USE"],
  "risk": {"type": "ABSOLUTE_PROBABILITY", "value": null, "model": "PREVENT_BASE_10Y"},
  "required_next_data": ["tabaquismo_actual", "estatina_actual"],
  "clinical_action": "Solicitar datos faltantes; no calcular porcentaje",
  "audit": {"model_version": "v03", "source_review": "PENDIENTE_VALIDACION_MEXICO"}
}
```
