# Extractos literales breves y valoración de evidencia

**Fecha de consulta:** 14-11-2026. Se conserva un fragmento literal verificable por obra (máximo 25 palabras), su ubicación, URL, interpretación y motivo de inclusión. El acceso a los párrafos completos se hace mediante URL y localizador. Los criterios resumidos NO reemplazan el texto de la guía.

Los fragmentos están en el idioma original del documento; no se hacen pasar traducciones por citas literales. No se han descargado ni redistribuido íntegramente obras protegidas.

## S01. ADA_DX26 — ADA Standards of Care 2026, Section 2 / Table 2.1

**Fuente:** https://diabetesjournals.org/care/article/49/Supplement_1/S27/163926
**Cita literal breve:** “A1C ≥6.5% (≥48 mmol/mol).”

**Qué aporta:** Prueba de laboratorio certificada; ausencia de hiperglucemia inequívoca exige confirmación.

**Justificación de incorporación:** CGM nunca sustituye la glucosa plasmática o HbA1c de diagnóstico.

**Alternativas/confirmación:** A1C vs glucemia en ayunas vs OGTT; analizar interferencias de A1C.

**Verificación:** fuente y pasaje identificados, pero no implica que cada variante derivada del catálogo reproduzca literalmente la guía.

## S02. ADA_GLY26 — ADA Standards of Care 2026, Section 6 / Table 6.2

**Fuente:** https://doi.org/10.2337/dc26-s006
**Cita literal breve:** “70% of time active out of 14 days”

**Qué aporta:** Mínimo de cobertura para evaluación de patrones CGM; los objetivos TIR/TBR tienen subpoblaciones distintas.

**Justificación de incorporación:** No inferir diabetes en personas sin diagnóstico previo; verificar datos faltantes y precisión del sensor.

**Alternativas/confirmación:** HbA1c para control promedio; HbA1c no reproduce variabilidad ni hipoglucemia.

**Verificación:** fuente y pasaje identificados, pero no implica que cada variante derivada del catálogo reproduzca literalmente la guía.

## S03. AHA_BP25 — ACC/AHA 2025 hipertensión, categorías PA, Table 4

**Fuente:** https://www.ahajournals.org/doi/10.1161/CIR.0000000000001356
**Cita literal breve:** “stage 1 hypertension as 130 to 139 mm Hg systolic”

**Qué aporta:** Cifras para categorías en adultos, promediadas con protocolo; no extrapolar a PA continua no validada.

**Justificación de incorporación:** NICE maneja otro umbral confirmatorio fuera de consulta; separar jurisdicciones.

**Alternativas/confirmación:** NICE NG136: HBPM promedio ≥135/85 tras PA de consulta elevada.

**Verificación:** fuente y pasaje identificados, pero no implica que cada variante derivada del catálogo reproduzca literalmente la guía.

## S04. NICE_BP — NICE NG136, 1.2.7–1.2.8

**Fuente:** https://www.nice.org.uk/guidance/ng136/chapter/Recommendations
**Cita literal breve:** “blood pressure recording continues for at least 4 days, ideally for 7 days.”

**Qué aporta:** Promediar HBPM tras descartar el primer día; confirmar con técnica apropiada.

**Justificación de incorporación:** No mezclar 135/85 en HBPM con 130/80 como si representaran idéntico método.

**Alternativas/confirmación:** AHA/ACC 2025 para clasificación por otro protocolo.

**Verificación:** fuente y pasaje identificados, pero no implica que cada variante derivada del catálogo reproduzca literalmente la guía.

## S05. KDIGO24 — KDIGO 2024 ERC, Practice Point 2.2.1, página S156

**Fuente:** https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf
**Cita literal breve:** “A 5-year kidney failure risk of 3%–5% can be used to determine need for nephrology referral”

**Qué aporta:** Sólo usar KFRE con ERC G3–G5 establecida y ACR urinaria válida.

**Justificación de incorporación:** Distinción entre derivación (3–5 % a 5 años) y preparación para TRR (horizontes diferentes).

**Alternativas/confirmación:** eGFR y albuminuria; ecuaciones específicas de enfermedad en IgA o ADPKD.

**Verificación:** fuente y pasaje identificados, pero no implica que cada variante derivada del catálogo reproduzca literalmente la guía.

## S06. NICE_SEPSIS — NICE NG253, Evaluating risk, Table 1 (adultos >16, no embarazo)

**Fuente:** https://www.nice.org.uk/guidance/ng253/chapter/Evaluating-risk
**Cita literal breve:** “Raised heart rate: more than 130 beats per minute”

**Qué aporta:** El cuadro es de SEPSIS SOSPECHADA, no un diagnóstico por FC aislada.

**Justificación de incorporación:** Prioridad ante deterioro general; síntomas, foco infeccioso, conciencia y FR no siempre disponibles.

**Alternativas/confirmación:** NEWS2 donde exista frecuencia respiratoria, oxígeno suplementario y estado de conciencia.

**Verificación:** fuente y pasaje identificados, pero no implica que cada variante derivada del catálogo reproduzca literalmente la guía.

## S07. UKKA_K26 — UK Kidney Association 2026, Introduction / Hyperkalaemia severity

**Fuente:** https://guidelines.ukkidney.org/hyperkalaemia/
**Cita literal breve:** “mild (5.5-5.9 mmol/l), moderate (6.0-6.4 mmol/l) or severe (≥ 6.5 mmol/l)”

**Qué aporta:** K sérico requiere muestra válida, verificar hemólisis; ECG y evaluación clínica si urgencia.

**Justificación de incorporación:** No usar K intersticial inexistente; evolución renal y medicamentos importan.

**Alternativas/confirmación:** Niveles comunitarios y hospitalarios, individualizar por manifestaciones clínicas.

**Verificación:** fuente y pasaje identificados, pero no implica que cada variante derivada del catálogo reproduzca literalmente la guía.

## S08. WHO_HB24 — OMS 2024, Table 3: Haemoglobin cutoffs / anaemia severity

**Fuente:** https://www.ncbi.nlm.nih.gov/books/NBK602183/table/fm-ch1.tab2/
**Cita literal breve:** “Adults, 15–65 years, nonpregnant women”

**Qué aporta:** Los cortes dependen de población, embarazo, trimestre y a veces altitud.

**Justificación de incorporación:** No extrapolar sin ajuste a embarazo o menores ni confundir anemia con etiología.

**Alternativas/confirmación:** Investigación de ferropenia/hemólisis/deficiencias según hemograma y clínica.

**Verificación:** fuente y pasaje identificados, pero no implica que cada variante derivada del catálogo reproduzca literalmente la guía.

## S09. AASM_OSA — AASM 2017, Good Practice Statements / Recommendations 1–2

**Fuente:** https://pmc.ncbi.nlm.nih.gov/articles/PMC5337595/
**Cita literal breve:** “Polysomnography is the standard diagnostic test for the diagnosis of OSA”

**Qué aporta:** Desaturación nocturna de reloj orienta estudio; no confirma apnea.

**Justificación de incorporación:** La saturación tiene artefactos; medir apnea-hipopnea requiere estudio validado.

**Alternativas/confirmación:** Polisomnografía o prueba domiciliaria técnicamente adecuada.

**Verificación:** fuente y pasaje identificados, pero no implica que cada variante derivada del catálogo reproduzca literalmente la guía.

## S10. FDA_SPO2 — FDA Pulse Oximeters, February 2021 safety communication

**Fuente:** https://www.fda.gov/medical-devices/products-and-medical-procedures/pulse-oximeters
**Cita literal breve:** “poor circulation, skin pigmentation, skin thickness, skin temperature, current tobacco use, and use of fingernail polish”

**Qué aporta:** Los valores límite de SpO2 no son totalmente transportables entre dispositivos.

**Justificación de incorporación:** No usar origen étnico como sustituto de pigmentación ni compensación clínica arbitraria.

**Alternativas/confirmación:** Repetir medición clínicamente fiable; gasometría si procede.

**Verificación:** fuente y pasaje identificados, pero no implica que cada variante derivada del catálogo reproduzca literalmente la guía.

## S11. AHA_PREVENT — AHA PREVENT original model (2024), base equations

**Fuente:** https://pmc.ncbi.nlm.nih.gov/articles/PMC10910659/
**Cita literal breve:** “Predicting Risk of CVD Events”

**Qué aporta:** Probabilidad de desenlace cardiovascular en horizonte concreto, modelo estadounidense no necesariamente calibrado en México.

**Justificación de incorporación:** No se puede calcular sin tabaquismo, dislipidemia, medicación y función renal; no imputar negativos.

**Alternativas/confirmación:** SCORE2/SCORE2-OP europeo; QRISK3 Reino Unido; recalibración propia local.

**Verificación:** fuente y pasaje identificados, pero no implica que cada variante derivada del catálogo reproduzca literalmente la guía.

## S12. ACC_LIP26 — ACC/AHA Dyslipidemia 2026, Section 4.2.3.7

**Fuente:** https://www.jacc.org/doi/10.1016/j.jacc.2025.11.016
**Cita literal breve:** “Low (<3%) Estimated 10-Year ASCVD Risk”

**Qué aporta:** Categorías sólo para PREVENT-ASCVD, no para PREVENT-HF o CVD-total.

**Justificación de incorporación:** No crear decisiones terapéuticas automáticas sin revisión médica.

**Alternativas/confirmación:** Prevención primaria con LDL y preferencias clínico-paciente.

**Verificación:** fuente y pasaje identificados, pero no implica que cada variante derivada del catálogo reproduzca literalmente la guía.

## S13. NIDDK_EGFR — NIDDK, eGFR Equations for Adults / 2021 CKD-EPI

**Fuente:** https://www.niddk.nih.gov/research-funding/research-programs/kidney-clinical-research-epidemiology/laboratory/glomerular-filtration-rate-equations/adults
**Cita literal breve:** “eGFR = 142 × min(SCr/κ,1)”

**Qué aporta:** Utilizar creatinina sérica calibrada (IDMS), y variable de sexo definida por el modelo.

**Justificación de incorporación:** La fórmula sin raza no es una probabilidad y su precisión varía con la fisiología.

**Alternativas/confirmación:** CKD-EPI creatinina+cistatina C, o mGFR si decisión exige mayor precisión.

**Verificación:** fuente y pasaje identificados, pero no implica que cada variante derivada del catálogo reproduzca literalmente la guía.

## S14. NICE_WHTR — NICE NG246, 1.9.14–1.9.15

**Fuente:** https://www.nice.org.uk/guidance/ng246/chapter/Identifying-and-assessing-overweight-obesity-and-central-adiposity
**Cita literal breve:** “keep their waist to less than half their height”

**Qué aporta:** Razón cintura/estatura <0.5 como referencia de adiposidad central (BMI<35 para esta clasificación).

**Justificación de incorporación:** No sustituye medición de grasa visceral ni diagnóstico metabólico.

**Alternativas/confirmación:** Perímetro cintura y otras medidas corporales; curvas pediátricas distintas.

**Verificación:** fuente y pasaje identificados, pero no implica que cada variante derivada del catálogo reproduzca literalmente la guía.

## S15. AASLD_FIB4 — AASLD Practice Guidance 2023 (update MASLD 2024), Figure 2

**Fuente:** https://pmc.ncbi.nlm.nih.gov/articles/PMC10735173/
**Cita literal breve:** “FIB-4 should not be used in acutely ill patients.”

**Qué aporta:** FIB-4 es triage de fibrosis, no probabilidad individual; >65 requiere otro corte inferior.

**Justificación de incorporación:** Menores de 35 con baja precisión; ALT/AST agudas alteran el score.

**Alternativas/confirmación:** EASL 2024 considera elastografía o intervención metabólica + repetición.

**Verificación:** fuente y pasaje identificados, pero no implica que cada variante derivada del catálogo reproduzca literalmente la guía.

## S16. EASL_FIB4 — EASL-EASD-EASO 2024 MASLD, Recommended strategy

**Fuente:** https://pmc.ncbi.nlm.nih.gov/articles/PMC11299976/
**Cita literal breve:** “FIB-4 will miss around 10% of individuals with advanced fibrosis”

**Qué aporta:** Evitar interpretar FIB-4 bajo como exclusión infalible; prevalencia importa.

**Justificación de incorporación:** No usar porcentajes individuales a partir de las tasas agregadas.

**Alternativas/confirmación:** Elastografía VCTE, ELF, MRE, evaluación hepática.

**Verificación:** fuente y pasaje identificados, pero no implica que cada variante derivada del catálogo reproduzca literalmente la guía.

## S17. NICE_B12_24 — NICE NG239, Table 1 total or active B12

**Fuente:** https://www.nice.org.uk/guidance/ng239/chapter/recommendations
**Cita literal breve:** “Less than 180 nanograms (133 pmol) per litre”

**Qué aporta:** B12 total <180 ng/L indica deficiencia bajo contexto y analítica compatible; 180–350 indeterminado.

**Justificación de incorporación:** Cortes válidos para el método especificado; embarazo, dieta y síntomas alteran ruta.

**Alternativas/confirmación:** B12 activa, ácido metilmalónico cuando corresponde.

**Verificación:** fuente y pasaje identificados, pero no implica que cada variante derivada del catálogo reproduzca literalmente la guía.

## S18. AGA_IRON20 — AGA 2020 Guideline, Recommendations point 1

**Fuente:** https://gastro.org/clinical-guidance/gastrointestinal-evaluation-of-iron-deficiency-anemia/
**Cita literal breve:** “cutoff of 45 ng/mL over 15 ng/mL”

**Qué aporta:** Ferritina <45 ng/mL se interpreta dentro de ANEMIA y evaluación de ferropenia.

**Justificación de incorporación:** La inflamación puede elevar ferritina; otros marcadores pueden ser necesarios.

**Alternativas/confirmación:** Saturación transferrina, PCR, hierro sérico según contexto.

**Verificación:** fuente y pasaje identificados, pero no implica que cada variante derivada del catálogo reproduzca literalmente la guía.

## S19. NICE_TSH — NICE NG145, recommendation 1.2.8

**Fuente:** https://www.nice.org.uk/guidance/ng145/chapter/recommendations
**Cita literal breve:** “if the TSH is above the reference range, measure free thyroxine (FT4) in the same sample”

**Qué aporta:** El diagnóstico requiere laboratorio, no FC, temperatura o ciclo por sí solos.

**Justificación de incorporación:** La biotina puede interferir con inmunoensayos.

**Alternativas/confirmación:** FT4/FT3 según TSH y sospecha de enfermedad hipofisaria.

**Verificación:** fuente y pasaje identificados, pero no implica que cada variante derivada del catálogo reproduzca literalmente la guía.

## S20. PCOS_GUIDE23 — PCOS International Guideline 2023, diagnostic criteria

**Fuente:** https://academic.oup.com/jcem/article/108/10/2447/7242360
**Cita literal breve:** “Serum AMH should not be used as a single test for the diagnosis of PCOS.”

**Qué aporta:** Fase ovulatoria sola no diagnostica SOP; exige patrón, hiperandrogenismo y excluir otras causas.

**Justificación de incorporación:** Adolescentes tienen criterios distintos, AMH no recomendado para diagnóstico.

**Alternativas/confirmación:** Rotterdam revisado con ecografía o AMH en adultos seleccionados.

**Verificación:** fuente y pasaje identificados, pero no implica que cada variante derivada del catálogo reproduzca literalmente la guía.

## S21. ESC_AF — ESC 2024 AF guideline, key message 10

**Fuente:** https://academic.oup.com/eurheartj/article/45/36/3314/7738779
**Cita literal breve:** “CHA₂DS₂-VA ≥2 anticoagulation recommended”

**Qué aporta:** Aplicar únicamente si FA está confirmada; score NO ofrece probabilidad calibrada por sí solo.

**Justificación de incorporación:** PPG no diagnostica FA; decisión de anticoagulación es médica.

**Alternativas/confirmación:** CHA₂DS₂-VASc, herramientas locales validadas y riesgo hemorrágico.

**Verificación:** fuente y pasaje identificados, pero no implica que cada variante derivada del catálogo reproduzca literalmente la guía.

## S22. AHA_PREG — ACC/AHA 2025, Table 21, hypertension pregnancy

**Fuente:** https://www.jacc.org/doi/10.1016/j.jacc.2025.05.007
**Cita literal breve:** “Severe-range hypertension SBP ≥160 mm Hg”

**Qué aporta:** Ruta obstétrica independiente, requiere estado de embarazo y semana gestacional.

**Justificación de incorporación:** No inferir embarazo a partir de fase ovulatoria.

**Alternativas/confirmación:** ACOG preeclampsia: PA, proteinuria o disfunción orgánica, cronología.

**Verificación:** fuente y pasaje identificados, pero no implica que cada variante derivada del catálogo reproduzca literalmente la guía.

## S23. NOM241_MX — NOM-241-SSA1-2025, numerales 3.118, 11.16

**Fuente:** https://sidof.segob.gob.mx/notas/docFuente/5754074
**Cita literal breve:** “Software como dispositivo médico (ScDM)”

**Qué aporta:** El uso previsto de alertas de salud puede activar obligaciones regulatorias.

**Justificación de incorporación:** No asuma que etiquetar la app como bienestar evita el régimen sanitario.

**Alternativas/confirmación:** Consulta regulatoria COFEPRIS, evaluación de clasificación y expediente técnico.

**Verificación:** fuente y pasaje identificados, pero no implica que cada variante derivada del catálogo reproduzca literalmente la guía.

## S24. NOM137_MX — NOM-137-SSA1-2025, numeral 6.3

**Fuente:** https://sidof.segob.gob.mx/notas/docFuente/5787790
**Cita literal breve:** “Software como dispositivo médico (ScDM)”

**Qué aporta:** Versionado, identificación e instrucciones de uso en producto final, según procedencia.

**Justificación de incorporación:** No atribuir vigencia sin comprobar Diario Oficial y entrada en vigor.

**Alternativas/confirmación:** Mecanismos de etiquetado electrónico, avisos y control de versiones.

**Verificación:** fuente y pasaje identificados, pero no implica que cada variante derivada del catálogo reproduzca literalmente la guía.

## S25. PROBAST_AI — PROBAST+AI 2025, four domains

**Fuente:** https://www.bmj.com/content/388/bmj-2024-082505
**Cita literal breve:** “participants, predictors, outcome, and analysis”

**Qué aporta:** La precisión de un modelo no implica ausencia de sesgo o aplicabilidad.

**Justificación de incorporación:** Validación independiente por centros, sensores, grupos demográficos y sexo.

**Alternativas/confirmación:** TRIPOD+AI para reporte; evaluación de sesgo PROBAST+AI.

**Verificación:** fuente y pasaje identificados, pero no implica que cada variante derivada del catálogo reproduzca literalmente la guía.

## S26. FDA_GMLP — FDA Good Machine Learning Practice / 10 principles

**Fuente:** https://www.fda.gov/medical-devices/artificial-intelligence-enabled-medical-devices/good-machine-learning-practice-medical-device-development-guiding-principles
**Cita literal breve:** “safe, effective, and high-quality medical devices”

**Qué aporta:** Validación del ciclo de vida: monitorización de deriva, control cambios, humana supervisión.

**Justificación de incorporación:** La implementación de reglas no reduce automáticamente obligaciones de seguridad.

**Alternativas/confirmación:** Registro de decisión y control de versiones.

**Verificación:** fuente y pasaje identificados, pero no implica que cada variante derivada del catálogo reproduzca literalmente la guía.

## S27. CDC_BMI24 — CDC Adult BMI categories

**Fuente:** https://www.cdc.gov/bmi/adult-calculator/bmi-categories.html
**Cita literal breve:** “Adult BMI Categories”

**Qué aporta:** El IMC indica categoría antropométrica, no composición corporal ni enfermedad diagnosticada.

**Justificación de incorporación:** No aplicar puntos de corte de adulto a menores o embarazo.

**Alternativas/confirmación:** Cintura-talla, circunferencia y valoración funcional.

**Verificación:** fuente y pasaje identificados, pero no implica que cada variante derivada del catálogo reproduzca literalmente la guía.

## S28. NKF_EGFR_CYS — NKF CKD-EPI creatinine-cystatin 2021

**Fuente:** https://www.kidney.org/professionals/ckd-epi-creatinine-cystatin-equation-2021
**Cita literal breve:** “CKD-EPI Creatinine-Cystatin Equation (2021)”

**Qué aporta:** Al añadir cistatina C se dispone de estimación renal alternativa en contexto adecuado.

**Justificación de incorporación:** No intercambiar unidades mg/L de cistatina C y mg/dL de creatinina.

**Alternativas/confirmación:** mGFR o panel renal ampliado si hay alta incertidumbre.

**Verificación:** fuente y pasaje identificados, pero no implica que cada variante derivada del catálogo reproduzca literalmente la guía.

## S29. PCOS_NORDIC — PCOS Nordic 2023 diagnostic review, adult and adolescent differences

**Fuente:** https://obgyn.onlinelibrary.wiley.com/doi/10.1111/aogs.14725
**Cita literal breve:** “In adolescents, both ovulatory dysfunction and hyperandrogenism are mandatory.”

**Qué aporta:** Separa criterios adultos y adolescentes; los usuarios sin datos de síntomas requieren abstención.

**Justificación de incorporación:** No usar supuesta ovulación como sustituto de pruebas endocrinas.

**Alternativas/confirmación:** Confirmar con clínica, laboratorios y exclusiones.

**Verificación:** fuente y pasaje identificados, pero no implica que cada variante derivada del catálogo reproduzca literalmente la guía.

## S30. PREVENT_AHA — AHA Professional PREVENT calculator

**Fuente:** https://professional.heart.org/en/guidelines-and-statements/prevent-calculator
**Cita literal breve:** “PREVENT”

**Qué aporta:** En prevención primaria se debe comparar implementación local con calculadora oficial en múltiples casos.

**Justificación de incorporación:** No dar porcentajes si faltan predictores; recalibrar para población mexicana.

**Alternativas/confirmación:** Versiones con predictores adicionales y horizontes alternativos según disponibilidad.

**Verificación:** fuente y pasaje identificados, pero no implica que cada variante derivada del catálogo reproduzca literalmente la guía.
